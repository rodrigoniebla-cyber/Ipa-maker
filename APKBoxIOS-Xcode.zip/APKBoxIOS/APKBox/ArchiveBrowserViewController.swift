import UIKit

/// Directory browser over decoded APK entries. Tapping a file "launches"
/// it in the file viewer; directories push another browser level.
final class ArchiveBrowserViewController: UIViewController {
    private let decoder: APKDecoder
    private let directoryPath: String
    private var entries: [APKEntry] = []

    private var tableView: UITableView!
    private var searchController: UISearchController!
    private var filtered: [APKEntry]?

    init(decoder: APKDecoder, directoryPath: String) {
        self.decoder = decoder
        self.directoryPath = directoryPath
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.background

        if directoryPath.isEmpty {
            title = "Contents"
        } else {
            let trimmed = directoryPath.hasSuffix("/") ? String(directoryPath.dropLast()) : directoryPath
            title = (trimmed as NSString).lastPathComponent
        }
        navigationItem.largeTitleDisplayMode = .never

        entries = decoder.children(ofDirectory: directoryPath)

        tableView = UITableView(frame: view.bounds, style: .insetGrouped)
        tableView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tableView.backgroundColor = Theme.background
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.rowHeight = 56
        view.addSubview(tableView)

        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = directoryPath.isEmpty ? "Filter all files" : "Filter folder"
        searchController.searchBar.barStyle = .black
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true

        if directoryPath.isEmpty {
            navigationItem.rightBarButtonItem = UIBarButtonItem(
                title: "All files",
                style: .plain,
                target: self,
                action: #selector(showFlatList)
            )
        }
    }

    @objc private func showFlatList() {
        let all = decoder.allEntries.filter { !$0.isDirectory }
        let list = FlatEntryListViewController(decoder: decoder, entries: all)
        navigationController?.pushViewController(list, animated: true)
    }

    private var displayed: [APKEntry] {
        filtered ?? entries
    }

    private func open(_ entry: APKEntry) {
        if entry.isDirectory {
            let next = ArchiveBrowserViewController(decoder: decoder, directoryPath: entry.path)
            navigationController?.pushViewController(next, animated: true)
        } else {
            let preview = FilePreviewViewController(decoder: decoder, entry: entry)
            navigationController?.pushViewController(preview, animated: true)
        }
    }
}

extension ArchiveBrowserViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        displayed.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let entry = displayed[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = entry.name
        content.textProperties.color = Theme.textPrimary
        content.textProperties.font = .systemFont(ofSize: 16, weight: .medium)

        if entry.isDirectory {
            content.secondaryText = "Folder"
        } else {
            content.secondaryText = "\(entry.kind.rawValue) · \(entry.uncompressedSize.apkByteString)"
        }
        content.secondaryTextProperties.color = Theme.textSecondary
        content.image = UIImage(systemName: entry.kind.systemImage)
        content.imageProperties.tintColor = entry.kind.tint
        content.imageProperties.preferredSymbolConfiguration = .init(pointSize: 18, weight: .semibold)
        cell.contentConfiguration = content
        cell.backgroundColor = Theme.card
        cell.accessoryType = entry.isDirectory ? .disclosureIndicator : .disclosureIndicator
        cell.selectionStyle = .default
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        open(displayed[indexPath.row])
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let entry = displayed[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            guard let self, !entry.isDirectory else {
                return UIMenu(children: [])
            }
            let save = UIAction(title: "Save to container", image: UIImage(systemName: "arrow.down.doc")) { _ in
                self.quickSave(entry)
            }
            let share = UIAction(title: "Share…", image: UIImage(systemName: "square.and.arrow.up")) { _ in
                self.quickShare(entry)
            }
            return UIMenu(children: [save, share])
        }
    }

    private func quickSave(_ entry: APKEntry) {
        do {
            let folder = APKLibrary.shared.savedFolder(for: decoder.package)
            let dest = try decoder.saveEntry(entry.path, to: folder)
            let alert = UIAlertController(title: "Saved", message: dest.lastPathComponent, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        } catch {
            let alert = UIAlertController(title: "Save failed", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

    private func quickShare(_ entry: APKEntry) {
        do {
            let data = try decoder.data(for: entry.path)
            let temp = FileManager.default.temporaryDirectory.appendingPathComponent(entry.name)
            try data.write(to: temp, options: .atomic)
            let activity = UIActivityViewController(activityItems: [temp], applicationActivities: nil)
            present(activity, animated: true)
        } catch {
            let alert = UIAlertController(title: "Share failed", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}

extension ArchiveBrowserViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        let query = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty {
            filtered = nil
        } else if directoryPath.isEmpty {
            // Global filter across the whole archive when searching at root.
            filtered = decoder.allEntries.filter {
                !$0.isDirectory && $0.path.localizedCaseInsensitiveContains(query)
            }
        } else {
            filtered = entries.filter {
                $0.name.localizedCaseInsensitiveContains(query) || $0.path.localizedCaseInsensitiveContains(query)
            }
        }
        tableView.reloadData()
    }
}

// MARK: - Flat list

final class FlatEntryListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    private let decoder: APKDecoder
    private let entries: [APKEntry]
    private var filtered: [APKEntry]?
    private var tableView: UITableView!

    init(decoder: APKDecoder, entries: [APKEntry]) {
        self.decoder = decoder
        self.entries = entries
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "All files (\(entries.count))"
        view.backgroundColor = Theme.background
        navigationItem.largeTitleDisplayMode = .never

        tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tableView.backgroundColor = Theme.background
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(tableView)

        let search = UISearchController(searchResultsController: nil)
        search.searchResultsUpdater = self
        search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = "Filter path"
        search.searchBar.barStyle = .black
        navigationItem.searchController = search
    }

    private var displayed: [APKEntry] { filtered ?? entries }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { displayed.count }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let entry = displayed[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = entry.path
        content.textProperties.color = Theme.textPrimary
        content.textProperties.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        content.secondaryText = entry.uncompressedSize.apkByteString
        content.secondaryTextProperties.color = Theme.textSecondary
        content.image = UIImage(systemName: entry.kind.systemImage)
        content.imageProperties.tintColor = entry.kind.tint
        cell.contentConfiguration = content
        cell.backgroundColor = Theme.background
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let preview = FilePreviewViewController(decoder: decoder, entry: displayed[indexPath.row])
        navigationController?.pushViewController(preview, animated: true)
    }

    func updateSearchResults(for searchController: UISearchController) {
        let q = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        filtered = q.isEmpty ? nil : entries.filter { $0.path.localizedCaseInsensitiveContains(q) }
        tableView.reloadData()
    }
}
