import UIKit

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        guard let windowScene = scene as? UIWindowScene else { return }

        let window = UIWindow(windowScene: windowScene)
        let root = LibraryViewController()
        let nav = UINavigationController(rootViewController: root)
        nav.navigationBar.prefersLargeTitles = true
        nav.overrideUserInterfaceStyle = .dark
        window.rootViewController = nav
        window.tintColor = Theme.accent
        window.backgroundColor = Theme.background
        self.window = window
        window.makeKeyAndVisible()

        // Open APKs shared into the app (Files / AirDrop / "Open in…").
        handleIncoming(connectionOptions.urlContexts)
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        handleIncoming(URLContexts)
    }

    private func handleIncoming(_ contexts: Set<UIOpenURLContext>) {
        for context in contexts {
            let url = context.url
            do {
                _ = try APKLibrary.shared.importAPK(from: url, copy: true)
                NotificationCenter.default.post(name: .apkLibraryDidChange, object: nil)
            } catch {
                print("APKBox import failed: \(error)")
            }
        }
    }
}
