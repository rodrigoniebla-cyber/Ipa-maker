import UIKit
import UniformTypeIdentifiers

/// Home screen: list of APK packages stored in the container + import controls.
final class LibraryViewController: UIViewController {
    private var collectionView: UICollectionView!
    private var dataSource: UICollectionViewDiffableDataSource<Section, APKPackage>!
    private var emptyLabel: UILabel!
    private var packages: [APKPackage] = []

    private enum Section { case main }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.background
        title = "APKBox"
        navigationController?.navigationBar.largeTitleTextAttributes = [
            .foregroundColor: Theme.textPrimary
        ]
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Theme.textPrimary
        ]
        navigationController?.navigationBar.barStyle = .black

        configureNavBar()
        configureCollection()
        configureEmptyState()
        configureDataSource()

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(reload),
            name: .apkLibraryDidChange,
            object: nil
        )
        reload()
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func configureNavBar() {
        let add = UIBarButtonItem(
            image: UIImage(systemName: "plus.circle.fill"),
            style: .plain,
            target: self,
            action: #selector(importTapped)
        )
        add.accessibilityLabel = "Import APK"
        let files = UIBarButtonItem(
            image: UIImage(systemName: "folder.badge.gearshape"),
            style: .plain,
            target: self,
            action: #selector(showContainerInfo)
        )
        files.accessibilityLabel = "Container info"
        navigationItem.rightBarButtonItems = [add, files]
    }

    private func configureCollection() {
        var config = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
        config.backgroundColor = Theme.background
        config.trailingSwipeActionsConfigurationProvider = { [weak self] indexPath in
            guard let self,
                  let item = self.dataSource.itemIdentifier(for: indexPath) else { return nil }
            let delete = UIContextualAction(style: .destructive, title: "Delete") { _, _, done in
                self.confirmDelete(item)
                done(true)
            }
            return UISwipeActionsConfiguration(actions: [delete])
        }

        let layout = UICollectionViewCompositionalLayout.list(using: config)
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
        collectionView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        collectionView.delegate = self
        collectionView.backgroundColor = Theme.background
        view.addSubview(collectionView)
    }

    private func configureEmptyState() {
        emptyLabel = UILabel()
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = Theme.textSecondary
        emptyLabel.font = .systemFont(ofSize: 16, weight: .regular)
        emptyLabel.text = "No APKs yet\n\nTap + to import an Android package.\nAPKBox decodes the archive, lets you open individual files, and saves extracted data in the app container (visible in Files)."
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyLabel)
        NSLayoutConstraint.activate([
            emptyLabel.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),
            emptyLabel.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    private func configureDataSource() {
        let registration = UICollectionView.CellRegistration<UICollectionViewListCell, APKPackage> { cell, _, package in
            var content = UIListContentConfiguration.subtitleCell()
            content.text = package.displayName
            content.textProperties.color = Theme.textPrimary
            content.textProperties.font = .systemFont(ofSize: 17, weight: .semibold)

            var parts: [String] = []
            if let pkg = package.packageName { parts.append(pkg) }
            if let ver = package.versionName {
                parts.append("v\(ver)")
            } else if let code = package.versionCode {
                parts.append("vc\(code)")
            }
            parts.append(package.fileSize.apkByteString)
            if package.entryCount > 0 {
                parts.append("\(package.entryCount) files")
            }
            content.secondaryText = parts.joined(separator: " · ")
            content.secondaryTextProperties.color = Theme.textSecondary
            content.secondaryTextProperties.numberOfLines = 2

            if let icon = APKLibrary.shared.icon(for: package) {
                content.image = icon
                content.imageProperties.cornerRadius = 10
                content.imageProperties.maximumSize = CGSize(width: 44, height: 44)
                content.imageProperties.reservedLayoutSize = CGSize(width: 44, height: 44)
            } else {
                let symbol = UIImage(systemName: "shippingbox.fill")
                content.image = symbol
                content.imageProperties.tintColor = Theme.accent
                content.imageProperties.preferredSymbolConfiguration = .init(pointSize: 24, weight: .semibold)
                content.imageProperties.maximumSize = CGSize(width: 44, height: 44)
                content.imageProperties.reservedLayoutSize = CGSize(width: 44, height: 44)
            }
            cell.contentConfiguration = content

            var bg = UIBackgroundConfiguration.listGroupedCell()
            bg.backgroundColor = Theme.card
            cell.backgroundConfiguration = bg
            cell.accessories = [.disclosureIndicator(options: .init(tintColor: Theme.textSecondary))]
        }

        dataSource = UICollectionViewDiffableDataSource(collectionView: collectionView) { collectionView, indexPath, item in
            collectionView.dequeueConfiguredReusableCell(using: registration, for: indexPath, item: item)
        }
    }

    @objc private func reload() {
        packages = APKLibrary.shared.allPackages()
        var snapshot = NSDiffableDataSourceSnapshot<Section, APKPackage>()
        snapshot.appendSections([.main])
        snapshot.appendItems(packages, toSection: .main)
        dataSource.apply(snapshot, animatingDifferences: true)
        emptyLabel.isHidden = !packages.isEmpty
        collectionView.isHidden = packages.isEmpty
    }

    @objc private func importTapped() {
        let types: [UTType] = [
            UTType(filenameExtension: "apk") ?? .data,
            .zip,
            .data
        ]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.delegate = self
        picker.allowsMultipleSelection = true
        present(picker, animated: true)
    }

    @objc private func showContainerInfo() {
        let lib = APKLibrary.shared
        let message = """
        Container folders (Files app → On My iPhone/iPad → APKBox):

        • APKs/ — imported packages
        • Extracted/ — full decoded trees
        • Saved Files/ — individual exports

        \(packages.count) package(s) in library.

        Path:
        \(lib.documentsURL.path)
        """
        let alert = UIAlertController(title: "APKBox Container", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func confirmDelete(_ package: APKPackage) {
        let alert = UIAlertController(
            title: "Remove \(package.displayName)?",
            message: "Deletes the APK and its extracted data from the container. Files you already copied elsewhere are kept.",
            preferredStyle: .actionSheet
        )
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive) { _ in
            APKLibrary.shared.remove(package)
            self.reload()
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let pop = alert.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(alert, animated: true)
    }
}

extension LibraryViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        guard let package = dataSource.itemIdentifier(for: indexPath) else { return }
        let detail = PackageDetailViewController(package: package)
        navigationController?.pushViewController(detail, animated: true)
    }
}

extension LibraryViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let spinner = UIAlertController(title: nil, message: "Importing…", preferredStyle: .alert)
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        spinner.view.addSubview(indicator)
        NSLayoutConstraint.activate([
            indicator.centerYAnchor.constraint(equalTo: spinner.view.centerYAnchor),
            indicator.leadingAnchor.constraint(equalTo: spinner.view.leadingAnchor, constant: 20),
            spinner.view.heightAnchor.constraint(greaterThanOrEqualToConstant: 80)
        ])
        present(spinner, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var failures: [String] = []
            for url in urls {
                do {
                    _ = try APKLibrary.shared.importAPK(from: url, copy: true)
                } catch {
                    failures.append("\(url.lastPathComponent): \(error.localizedDescription)")
                }
            }
            DispatchQueue.main.async {
                spinner.dismiss(animated: true) {
                    self.reload()
                    if !failures.isEmpty {
                        let alert = UIAlertController(
                            title: "Some imports failed",
                            message: failures.joined(separator: "\n"),
                            preferredStyle: .alert
                        )
                        alert.addAction(UIAlertAction(title: "OK", style: .default))
                        self.present(alert, animated: true)
                    }
                }
            }
        }
    }
}
