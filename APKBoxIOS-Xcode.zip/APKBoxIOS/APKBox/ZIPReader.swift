import Foundation
import zlib

/// Minimal ZIP reader for APK containers (store + deflate).
/// APKs are standard ZIP files; this opens individual entries without
/// needing a full Android runtime.
final class ZIPReader {
    enum ZIPError: LocalizedError {
        case cannotOpen
        case invalidCentralDirectory
        case entryNotFound(String)
        case unsupportedCompression(UInt16)
        case inflateFailed
        case truncatedData

        var errorDescription: String? {
            switch self {
            case .cannotOpen: return "Could not open archive."
            case .invalidCentralDirectory: return "Invalid ZIP central directory."
            case .entryNotFound(let p): return "Entry not found: \(p)"
            case .unsupportedCompression(let m): return "Unsupported compression method: \(m)"
            case .inflateFailed: return "Failed to decompress entry."
            case .truncatedData: return "Truncated archive data."
            }
        }
    }

    struct CentralEntry {
        let path: String
        let compressionMethod: UInt16
        let compressedSize: UInt32
        let uncompressedSize: UInt32
        let localHeaderOffset: UInt32
        let generalPurposeFlag: UInt16

        var isDirectory: Bool { path.hasSuffix("/") }
    }

    private let data: Data
    private(set) var entries: [CentralEntry] = []

    init(fileURL: URL) throws {
        data = try Data(contentsOf: fileURL, options: [.mappedIfSafe])
        try parseCentralDirectory()
    }

    init(data: Data) throws {
        self.data = data
        try parseCentralDirectory()
    }

    func entry(named path: String) -> CentralEntry? {
        entries.first { $0.path == path }
    }

    func readFile(_ path: String) throws -> Data {
        guard let entry = entry(named: path), !entry.isDirectory else {
            throw ZIPError.entryNotFound(path)
        }
        return try read(entry)
    }

    func read(_ entry: CentralEntry) throws -> Data {
        let offset = Int(entry.localHeaderOffset)
        guard offset + 30 <= data.count else { throw ZIPError.truncatedData }

        let sig = readU32(at: offset)
        guard sig == 0x04034b50 else { throw ZIPError.invalidCentralDirectory }

        let nameLen = Int(readU16(at: offset + 26))
        let extraLen = Int(readU16(at: offset + 28))
        let dataStart = offset + 30 + nameLen + extraLen
        let compSize = Int(entry.compressedSize)
        guard dataStart >= 0, dataStart + compSize <= data.count else { throw ZIPError.truncatedData }

        let compressed = data.subdata(in: dataStart ..< (dataStart + compSize))

        switch entry.compressionMethod {
        case 0:
            return compressed
        case 8:
            return try Self.inflateRawDeflate(compressed, expected: Int(entry.uncompressedSize))
        default:
            throw ZIPError.unsupportedCompression(entry.compressionMethod)
        }
    }

    // MARK: - Central directory

    private func parseCentralDirectory() throws {
        guard data.count >= 22 else { throw ZIPError.invalidCentralDirectory }

        var eocd = -1
        let maxScan = min(data.count, 66_000)
        for i in 0 ..< maxScan {
            let pos = data.count - 22 - i
            if pos < 0 { break }
            if readU32(at: pos) == 0x06054b50 {
                eocd = pos
                break
            }
        }
        guard eocd >= 0 else { throw ZIPError.invalidCentralDirectory }

        let totalEntries = Int(readU16(at: eocd + 10))
        let cdSize = Int(readU32(at: eocd + 12))
        let cdOffset = Int(readU32(at: eocd + 16))
        guard cdOffset >= 0, cdOffset + max(cdSize, 0) <= data.count else {
            throw ZIPError.invalidCentralDirectory
        }

        var cursor = cdOffset
        var result: [CentralEntry] = []
        result.reserveCapacity(max(totalEntries, 0))

        for _ in 0 ..< totalEntries {
            guard cursor + 46 <= data.count else { break }
            guard readU32(at: cursor) == 0x02014b50 else { break }

            let gpFlag = readU16(at: cursor + 8)
            let method = readU16(at: cursor + 10)
            let compSize = readU32(at: cursor + 20)
            let uncompSize = readU32(at: cursor + 24)
            let nameLen = Int(readU16(at: cursor + 28))
            let extraLen = Int(readU16(at: cursor + 30))
            let commentLen = Int(readU16(at: cursor + 32))
            let localOffset = readU32(at: cursor + 42)

            let nameStart = cursor + 46
            let nameEnd = nameStart + nameLen
            guard nameEnd <= data.count else { break }

            let nameData = data.subdata(in: nameStart ..< nameEnd)
            let path = String(data: nameData, encoding: .utf8)
                ?? String(data: nameData, encoding: .isoLatin1)
                ?? "entry_\(result.count)"

            result.append(
                CentralEntry(
                    path: path,
                    compressionMethod: method,
                    compressedSize: compSize,
                    uncompressedSize: uncompSize,
                    localHeaderOffset: localOffset,
                    generalPurposeFlag: gpFlag
                )
            )
            cursor = nameEnd + extraLen + commentLen
        }

        entries = result
    }

    // MARK: - Binary helpers

    private func readU16(at offset: Int) -> UInt16 {
        var value: UInt16 = 0
        _ = withUnsafeMutableBytes(of: &value) { dest in
            data.copyBytes(to: dest, from: offset ..< (offset + 2))
        }
        return UInt16(littleEndian: value)
    }

    private func readU32(at offset: Int) -> UInt32 {
        var value: UInt32 = 0
        _ = withUnsafeMutableBytes(of: &value) { dest in
            data.copyBytes(to: dest, from: offset ..< (offset + 4))
        }
        return UInt32(littleEndian: value)
    }

    /// Raw DEFLATE (ZIP method 8) via zlib `inflateInit2(..., -MAX_WBITS)`.
    private static func inflateRawDeflate(_ input: Data, expected: Int) throws -> Data {
        if input.isEmpty { return Data() }

        var stream = z_stream()
        memset(&stream, 0, MemoryLayout<z_stream>.size)

        let windowBits: Int32 = -15 // raw deflate
        let initStatus = inflateInit2_(&stream, windowBits, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size))
        guard initStatus == Z_OK else { throw ZIPError.inflateFailed }
        defer { inflateEnd(&stream) }

        var output = Data()
        if expected > 0 { output.reserveCapacity(expected) }
        let chunkSize = 65_536
        var outBuffer = [UInt8](repeating: 0, count: chunkSize)

        let inputCount = input.count
        let resultStatus: Int32 = input.withUnsafeBytes { (raw: UnsafeRawBufferPointer) -> Int32 in
            guard let base = raw.bindMemory(to: UInt8.self).baseAddress else {
                return Z_ERRNO
            }

            stream.next_in = UnsafeMutablePointer(mutating: base)
            stream.avail_in = uInt(inputCount)

            var status: Int32 = Z_OK
            repeat {
                let produced: Int = outBuffer.withUnsafeMutableBytes { outRaw in
                    guard let outBase = outRaw.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                    stream.next_out = outBase
                    stream.avail_out = uInt(chunkSize)
                    status = inflate(&stream, Z_NO_FLUSH)
                    return chunkSize - Int(stream.avail_out)
                }
                if produced > 0 {
                    output.append(contentsOf: outBuffer.prefix(produced))
                }
                if status == Z_STREAM_END {
                    return Z_STREAM_END
                }
                if status == Z_BUF_ERROR && stream.avail_in == 0 {
                    // All input consumed; some writers omit Z_STREAM_END on entry payloads.
                    return Z_OK
                }
                if status != Z_OK {
                    return status
                }
                if expected > 0 && output.count > expected + chunkSize {
                    return Z_DATA_ERROR
                }
            } while stream.avail_in > 0 || stream.avail_out == 0

            return Z_OK
        }

        guard resultStatus == Z_OK || resultStatus == Z_STREAM_END else {
            throw ZIPError.inflateFailed
        }
        if expected > 0, output.count > expected {
            output.count = expected
        }
        return output
    }
}
