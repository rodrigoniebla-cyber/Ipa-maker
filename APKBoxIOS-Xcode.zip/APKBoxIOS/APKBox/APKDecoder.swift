import Foundation
import UIKit
import ImageIO
import UniformTypeIdentifiers

/// Decodes an APK (ZIP) into browsable entries, extracts files, and
/// recovers useful metadata without running Android code.
final class APKDecoder {
    enum DecoderError: LocalizedError {
        case notAnAPK
        case readFailed(String)
        case writeFailed(String)

        var errorDescription: String? {
            switch self {
            case .notAnAPK: return "File is not a valid APK/ZIP archive."
            case .readFailed(let m): return m
            case .writeFailed(let m): return m
            }
        }
    }

    let package: APKPackage
    let apkURL: URL
    private let reader: ZIPReader

    init(package: APKPackage, apkURL: URL) throws {
        self.package = package
        self.apkURL = apkURL
        do {
            self.reader = try ZIPReader(fileURL: apkURL)
        } catch {
            throw DecoderError.notAnAPK
        }
    }

    var allEntries: [APKEntry] {
        reader.entries.map {
            APKEntry(
                path: $0.path,
                isDirectory: $0.isDirectory,
                uncompressedSize: Int($0.uncompressedSize),
                compressedSize: Int($0.compressedSize)
            )
        }
        .sorted { $0.path.localizedCaseInsensitiveCompare($1.path) == .orderedAscending }
    }

    /// Entries that live directly under `prefix` (one path component deeper).
    func children(ofDirectory prefix: String) -> [APKEntry] {
        let normalized: String
        if prefix.isEmpty {
            normalized = ""
        } else if prefix.hasSuffix("/") {
            normalized = prefix
        } else {
            normalized = prefix + "/"
        }

        var folders = Set<String>()
        var files: [APKEntry] = []

        for entry in allEntries {
            guard entry.path.hasPrefix(normalized) else { continue }
            let rest = String(entry.path.dropFirst(normalized.count))
            guard !rest.isEmpty else { continue }

            if let slash = rest.firstIndex(of: "/") {
                let folderName = String(rest[..<slash])
                let folderPath = normalized + folderName + "/"
                folders.insert(folderPath)
            } else if !entry.isDirectory {
                files.append(entry)
            } else {
                folders.insert(entry.path)
            }
        }

        let folderEntries = folders.sorted().map {
            APKEntry(path: $0, isDirectory: true, uncompressedSize: 0, compressedSize: 0)
        }
        return folderEntries + files.sorted {
            $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    func data(for path: String) throws -> Data {
        do {
            return try reader.readFile(path)
        } catch {
            throw DecoderError.readFailed(error.localizedDescription)
        }
    }

    // MARK: - Manifest / metadata

    func decodeManifestSummary() -> ManifestSummary {
        // Prefer binary AndroidManifest.xml; fall back to any plain-text copy.
        if let data = try? reader.readFile("AndroidManifest.xml") {
            if looksLikeBinaryXML(data) {
                return BinaryXMLScanner.scanManifest(data)
            }
            if let text = String(data: data, encoding: .utf8) {
                return parseTextManifest(text)
            }
        }
        return .empty
    }

    func extractIcon() -> UIImage? {
        // Common launcher icon locations inside APKs.
        let candidates = reader.entries
            .map(\.path)
            .filter { path in
                let lower = path.lowercased()
                guard lower.hasSuffix(".png") || lower.hasSuffix(".webp") else { return false }
                return lower.contains("ic_launcher")
                    || lower.contains("icon")
                    || lower.contains("mipmap")
            }
            .sorted { a, b in
                // Prefer higher-density mipmaps.
                densityScore(a) > densityScore(b)
            }

        for path in candidates.prefix(12) {
            if let data = try? reader.readFile(path),
               let image = decodeImage(data) {
                return image
            }
        }
        return nil
    }

    private func densityScore(_ path: String) -> Int {
        let lower = path.lowercased()
        if lower.contains("xxxhdpi") { return 5 }
        if lower.contains("xxhdpi") { return 4 }
        if lower.contains("xhdpi") { return 3 }
        if lower.contains("hdpi") { return 2 }
        if lower.contains("mdpi") { return 1 }
        return 0
    }

    func decodeImage(_ data: Data) -> UIImage? {
        if let img = UIImage(data: data) { return img }
        // Try ImageIO for webp etc.
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let cg = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            return nil
        }
        return UIImage(cgImage: cg)
    }

    // MARK: - Save / extract

    /// Writes one entry into the package's extract folder and returns the file URL.
    @discardableResult
    func saveEntry(_ path: String, to directory: URL) throws -> URL {
        let entryData = try data(for: path)
        let name = (path as NSString).lastPathComponent
        let safeName = name.isEmpty ? "entry.bin" : name
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let dest = uniqueURL(in: directory, preferredName: safeName)
        try entryData.write(to: dest, options: .atomic)
        return dest
    }

    /// Extracts the full archive tree under `destinationRoot/<package>/`.
    @discardableResult
    func extractAll(to destinationRoot: URL, progress: ((Double) -> Void)? = nil) throws -> URL {
        let root = destinationRoot.appendingPathComponent(package.extractFolderName, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

        let fileEntries = reader.entries.filter { !$0.isDirectory }
        let total = max(fileEntries.count, 1)

        for (idx, entry) in fileEntries.enumerated() {
            let relative = entry.path
            let dest = root.appendingPathComponent(relative)
            let parent = dest.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: parent, withIntermediateDirectories: true)
            let bytes = try reader.read(entry)
            try bytes.write(to: dest, options: .atomic)
            progress?(Double(idx + 1) / Double(total))
        }
        return root
    }

    /// Saves a UTF-8 text rendering of binary XML when possible.
    func textPreview(for path: String, maxBytes: Int = 512_000) throws -> String {
        let raw = try data(for: path)
        let clipped = raw.prefix(maxBytes)

        if path.lowercased().hasSuffix(".xml"), looksLikeBinaryXML(Data(clipped)) {
            let recovered = BinaryXMLScanner.strings(from: Data(clipped))
            if !recovered.isEmpty {
                return recovered.joined(separator: "\n")
            }
            return hexDump(Data(clipped.prefix(4096)))
        }

        if let text = String(data: Data(clipped), encoding: .utf8),
           text.unicodeScalars.contains(where: { !$0.isASCII || $0.isLetter || $0.isDigit || CharacterSet.whitespacesAndNewlines.contains($0) || "!@#$%^&*()_+-=[]{}|;:'\",.<>/?`~\\".contains(Character($0)) }) {
            // Prefer printable UTF-8
            let printableRatio = Double(text.unicodeScalars.filter { $0.isASCII && (!$0.properties.isControl || CharacterSet.whitespacesAndNewlines.contains($0)) }.count) / Double(max(text.unicodeScalars.count, 1))
            if printableRatio > 0.85 {
                return text
            }
        }

        if let latin = String(data: Data(clipped), encoding: .isoLatin1) {
            let printable = latin.filter { ch in
                guard let s = ch.unicodeScalars.first else { return false }
                return !s.properties.isControl || CharacterSet.whitespacesAndNewlines.contains(s)
            }
            if Double(printable.count) / Double(max(latin.count, 1)) > 0.8 {
                return String(printable.prefix(200_000))
            }
        }

        return hexDump(Data(clipped.prefix(8192)))
    }

    // MARK: - Private helpers

    private func looksLikeBinaryXML(_ data: Data) -> Bool {
        guard data.count >= 8 else { return false }
        // Android binary XML magic: 0x00080003
        let magic = data.prefix(4)
        return magic == Data([0x03, 0x00, 0x08, 0x00]) || magic == Data([0x00, 0x08, 0x00, 0x03])
    }

    private func parseTextManifest(_ text: String) -> ManifestSummary {
        var summary = ManifestSummary.empty
        summary.packageName = firstMatch("package\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.versionName = firstMatch("versionName\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.versionCode = firstMatch("versionCode\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.minSDK = firstMatch("minSdkVersion\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.targetSDK = firstMatch("targetSdkVersion\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.label = firstMatch("android:label\\s*=\\s*\"([^\"]+)\"", in: text)

        summary.permissions = allMatches("uses-permission[^>]*android:name\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.activities = allMatches("<activity[^>]*android:name\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.services = allMatches("<service[^>]*android:name\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.receivers = allMatches("<receiver[^>]*android:name\\s*=\\s*\"([^\"]+)\"", in: text)
        summary.providers = allMatches("<provider[^>]*android:name\\s*=\\s*\"([^\"]+)\"", in: text)
        return summary
    }

    private func firstMatch(_ pattern: String, in text: String) -> String? {
        allMatches(pattern, in: text).first
    }

    private func allMatches(_ pattern: String, in text: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else {
            return []
        }
        let range = NSRange(text.startIndex..., in: text)
        return regex.matches(in: text, options: [], range: range).compactMap { match in
            guard match.numberOfRanges > 1,
                  let r = Range(match.range(at: 1), in: text) else { return nil }
            return String(text[r])
        }
    }

    private func hexDump(_ data: Data) -> String {
        var lines: [String] = ["(binary — hex preview)"]
        let bytes = [UInt8](data)
        stride(from: 0, to: bytes.count, by: 16).forEach { start in
            let end = min(start + 16, bytes.count)
            let slice = Array(bytes[start..<end])
            let hexParts = slice.map { String(format: "%02X", $0) }
            let hex = hexParts.joined(separator: " ")
            let paddedHex = hex.padding(toLength: 47, withPad: " ", startingAt: 0)
            let ascii = slice.map { b -> String in
                if (32...126).contains(b), let scalar = UnicodeScalar(Int(b)) {
                    return String(Character(scalar))
                }
                return "."
            }.joined()
            lines.append(String(format: "%08X  %@  %@", start, paddedHex, ascii))
        }
        return lines.joined(separator: "\n")
    }

    private func uniqueURL(in directory: URL, preferredName: String) -> URL {
        var dest = directory.appendingPathComponent(preferredName)
        if !FileManager.default.fileExists(atPath: dest.path) {
            return dest
        }
        let base = (preferredName as NSString).deletingPathExtension
        let ext = (preferredName as NSString).pathExtension
        var i = 2
        while true {
            let name = ext.isEmpty ? "\(base)-\(i)" : "\(base)-\(i).\(ext)"
            dest = directory.appendingPathComponent(name)
            if !FileManager.default.fileExists(atPath: dest.path) {
                return dest
            }
            i += 1
        }
    }
}

// MARK: - Binary XML string scanner

/// Best-effort recovery of human-readable strings from Android binary XML
/// (AndroidManifest.xml, resources.arsc-adjacent XML). Not a full AXML parser —
/// enough to surface package name, permissions, component names, etc.
enum BinaryXMLScanner {
    static func scanManifest(_ data: Data) -> ManifestSummary {
        let strings = strings(from: data)
        var summary = ManifestSummary.empty

        // Package names look like com.example.app
        let packageLike = strings.filter { s in
            s.contains(".") && s.range(of: #"^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$"#, options: .regularExpression) != nil
            && !s.hasPrefix("android.") && !s.hasPrefix("http")
            && s.count < 120
        }
        summary.packageName = packageLike.first

        summary.permissions = strings.filter { $0.hasPrefix("android.permission.") || $0.contains(".permission.") }
        summary.activities = strings.filter { $0.contains("Activity") && $0.contains(".") && !$0.hasPrefix("android.") }
        summary.services = strings.filter { $0.contains("Service") && $0.contains(".") && !$0.hasPrefix("android.") }
        summary.receivers = strings.filter { ($0.contains("Receiver") || $0.contains("receiver")) && $0.contains(".") }
        summary.providers = strings.filter { $0.contains("Provider") && $0.contains(".") && !$0.hasPrefix("android.") }

        // versionName often is a dotted number or short string near "versionName"
        if let idx = strings.firstIndex(of: "versionName"), idx + 1 < strings.count {
            let next = strings[idx + 1]
            if next.count < 40 { summary.versionName = next }
        }
        if summary.versionName == nil {
            summary.versionName = strings.first { $0.range(of: #"^\d+\.\d+(\.\d+)?"#, options: .regularExpression) != nil }
        }

        if let idx = strings.firstIndex(of: "versionCode"), idx + 1 < strings.count {
            let next = strings[idx + 1]
            if next.range(of: #"^\d+$"#, options: .regularExpression) != nil {
                summary.versionCode = next
            }
        }

        if let idx = strings.firstIndex(where: { $0 == "minSdkVersion" || $0 == "minSdk" }),
           idx + 1 < strings.count {
            summary.minSDK = strings[idx + 1]
        }
        if let idx = strings.firstIndex(where: { $0 == "targetSdkVersion" || $0 == "targetSdk" }),
           idx + 1 < strings.count {
            summary.targetSDK = strings[idx + 1]
        }

        // label candidate: short non-resource string
        if let idx = strings.firstIndex(of: "label"), idx + 1 < strings.count {
            let next = strings[idx + 1]
            if !next.hasPrefix("@") && next.count < 60 {
                summary.label = next
            }
        }

        var hints: [String: String] = [:]
        if let p = summary.packageName { hints["package"] = p }
        if let v = summary.versionName { hints["versionName"] = v }
        if let c = summary.versionCode { hints["versionCode"] = c }
        summary.rawHints = hints
        return summary
    }

    static func strings(from data: Data) -> [String] {
        // Strategy 1: walk ResChunk string pool if present.
        var result: [String] = []
        result.append(contentsOf: parseStringPool(data))

        // Strategy 2: scrape UTF-16LE and UTF-8 runs.
        result.append(contentsOf: scrapeUTF16(data))
        result.append(contentsOf: scrapeUTF8(data))

        // Dedupe preserving order
        var seen = Set<String>()
        var unique: [String] = []
        for s in result {
            let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
            guard trimmed.count >= 2, trimmed.count < 300 else { continue }
            if seen.insert(trimmed).inserted {
                unique.append(trimmed)
            }
        }
        return unique
    }

    private static func parseStringPool(_ data: Data) -> [String] {
        // Look for RES_STRING_POOL_TYPE = 0x0001 with headerSize 0x1c
        guard data.count > 28 else { return [] }
        var strings: [String] = []
        let bytes = [UInt8](data)
        var i = 0
        while i + 28 < bytes.count {
            let type = UInt16(bytes[i]) | (UInt16(bytes[i + 1]) << 8)
            let headerSize = UInt16(bytes[i + 2]) | (UInt16(bytes[i + 3]) << 8)
            let chunkSize = Int(UInt32(bytes[i + 4]) | (UInt32(bytes[i + 5]) << 8) | (UInt32(bytes[i + 6]) << 16) | (UInt32(bytes[i + 7]) << 24))

            if type == 0x0001 && headerSize >= 0x1c && chunkSize > headerSize && i + chunkSize <= bytes.count {
                let stringCount = Int(UInt32(bytes[i + 8]) | (UInt32(bytes[i + 9]) << 8) | (UInt32(bytes[i + 10]) << 16) | (UInt32(bytes[i + 11]) << 24))
                let flags = UInt32(bytes[i + 16]) | (UInt32(bytes[i + 17]) << 8) | (UInt32(bytes[i + 18]) << 16) | (UInt32(bytes[i + 19]) << 24)
                let stringsStart = Int(UInt32(bytes[i + 20]) | (UInt32(bytes[i + 21]) << 8) | (UInt32(bytes[i + 22]) << 16) | (UInt32(bytes[i + 23]) << 24))
                let isUTF8 = (flags & (1 << 8)) != 0

                if stringCount > 0 && stringCount < 100_000 && stringsStart > 0 {
                    let offsetsStart = i + Int(headerSize)
                    for sIdx in 0 ..< stringCount {
                        let offPos = offsetsStart + sIdx * 4
                        guard offPos + 4 <= bytes.count else { break }
                        let rel = Int(UInt32(bytes[offPos]) | (UInt32(bytes[offPos + 1]) << 8) | (UInt32(bytes[offPos + 2]) << 16) | (UInt32(bytes[offPos + 3]) << 24))
                        let abs = i + stringsStart + rel
                        guard abs < i + chunkSize else { continue }
                        if isUTF8 {
                            if let s = readUTF8String(bytes, at: abs, limit: i + chunkSize) {
                                strings.append(s)
                            }
                        } else {
                            if let s = readUTF16String(bytes, at: abs, limit: i + chunkSize) {
                                strings.append(s)
                            }
                        }
                    }
                }
                i += max(chunkSize, 1)
                continue
            }
            i += 1
        }
        return strings
    }

    private static func readUTF16String(_ bytes: [UInt8], at start: Int, limit: Int) -> String? {
        guard start + 2 <= limit else { return nil }
        // charlen is u16; if high bit set, 32-bit length follows — keep simple.
        var pos = start
        var charLen = Int(UInt16(bytes[pos]) | (UInt16(bytes[pos + 1]) << 8))
        pos += 2
        if charLen & 0x8000 != 0 {
            guard pos + 2 <= limit else { return nil }
            charLen = ((charLen & 0x7fff) << 16) | Int(UInt16(bytes[pos]) | (UInt16(bytes[pos + 1]) << 8))
            pos += 2
        }
        guard charLen > 0, charLen < 10_000, pos + charLen * 2 <= limit else { return nil }
        var scalars: [UInt16] = []
        scalars.reserveCapacity(charLen)
        for c in 0 ..< charLen {
            let lo = UInt16(bytes[pos + c * 2])
            let hi = UInt16(bytes[pos + c * 2 + 1])
            let unit = lo | (hi << 8)
            if unit == 0 { break }
            scalars.append(unit)
        }
        return String(utf16CodeUnits: scalars, count: scalars.count)
    }

    private static func readUTF8String(_ bytes: [UInt8], at start: Int, limit: Int) -> String? {
        guard start + 2 <= limit else { return nil }
        var pos = start
        // skip charLen then byteLen (each possibly 2 bytes)
        func readLen() -> Int? {
            guard pos < limit else { return nil }
            var v = Int(bytes[pos]); pos += 1
            if v & 0x80 != 0 {
                guard pos < limit else { return nil }
                v = ((v & 0x7f) << 8) | Int(bytes[pos]); pos += 1
            }
            return v
        }
        _ = readLen() // char length
        guard let byteLen = readLen(), byteLen > 0, byteLen < 10_000, pos + byteLen <= limit else {
            return nil
        }
        let slice = Data(bytes[pos ..< (pos + byteLen)])
        return String(data: slice, encoding: .utf8)
    }

    private static func scrapeUTF16(_ data: Data) -> [String] {
        let bytes = [UInt8](data)
        var out: [String] = []
        var i = 0
        while i + 4 < bytes.count {
            // look for sequences of printable UTF-16LE
            var units: [UInt16] = []
            var j = i
            while j + 1 < bytes.count {
                let unit = UInt16(bytes[j]) | (UInt16(bytes[j + 1]) << 8)
                let isPrint = (unit >= 0x20 && unit < 0x7f) || (unit >= 0xa0 && unit < 0x250)
                if isPrint {
                    units.append(unit)
                    j += 2
                } else {
                    break
                }
            }
            if units.count >= 3 {
                let s = String(utf16CodeUnits: units, count: units.count)
                out.append(s)
                i = j
            } else {
                i += 1
            }
        }
        return out
    }

    private static func scrapeUTF8(_ data: Data) -> [String] {
        let bytes = [UInt8](data)
        var out: [String] = []
        var i = 0
        while i < bytes.count {
            if bytes[i] >= 0x20 && bytes[i] < 0x7f {
                var j = i
                while j < bytes.count && bytes[j] >= 0x20 && bytes[j] < 0x7f {
                    j += 1
                }
                if j - i >= 3 {
                    if let s = String(bytes: bytes[i..<j], encoding: .ascii) {
                        out.append(s)
                    }
                }
                i = j
            } else {
                i += 1
            }
        }
        return out
    }
}
