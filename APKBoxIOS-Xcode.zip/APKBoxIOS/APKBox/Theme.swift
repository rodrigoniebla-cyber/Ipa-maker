import UIKit

enum Theme {
    static let background = UIColor(red: 0.07, green: 0.09, blue: 0.12, alpha: 1)
    static let card = UIColor(red: 0.12, green: 0.15, blue: 0.20, alpha: 1)
    static let cardBorder = UIColor(red: 0.20, green: 0.25, blue: 0.32, alpha: 1)
    static let accent = UIColor(red: 0.20, green: 0.80, blue: 0.45, alpha: 1)
    static let accentMuted = UIColor(red: 0.15, green: 0.45, blue: 0.28, alpha: 1)
    static let textPrimary = UIColor(white: 0.95, alpha: 1)
    static let textSecondary = UIColor(white: 0.65, alpha: 1)
    static let danger = UIColor(red: 0.95, green: 0.35, blue: 0.35, alpha: 1)
}
