import UIKit

/// Overview of one imported APK: metadata, open decoder, extract-all, save actions.
final class PackageDetailViewController: UIViewController {
    private var package: APKPackage
    private var decoder: APKDecoder?
    private var summary: ManifestSummary = .empty

    private let scrollView = UIScrollView()
    private let contentStack = UIStackView()
    private let iconView = UIImageView()
    private let progressView = UIProgressView(progressViewStyle: .bar)

    init(package: APKPackage) {
        self.package = package
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.background
        title = package.displayName
        navigationItem.largeTitleDisplayMode = .never

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "square.and.arrow.up"),
            style: .plain,
            target: self,
            action: #selector(shareAPK)
        )

        buildLayout()
        loadDecoder()
    }

    private func buildLayout() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        contentStack.axis = .vertical
        contentStack.spacing = 16
        contentStack.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentStack)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentStack.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor, constant: 16),
            contentStack.leadingAnchor.constraint(equalTo: scrollView.frameLayoutGuide.leadingAnchor, constant: 16),
            contentStack.trailingAnchor.constraint(equalTo: scrollView.frameLayoutGuide.trailingAnchor, constant: -16),
            contentStack.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor, constant: -32),
            contentStack.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor, constant: -32)
        ])

        // Header card
        let header = cardView()
        iconView.contentMode = .scaleAspectFit
        iconView.layer.cornerRadius = 16
        iconView.clipsToBounds = true
        iconView.backgroundColor = Theme.accentMuted
        iconView.translatesAutoresizingMaskIntoConstraints = false
        iconView.widthAnchor.constraint(equalToConstant: 72).isActive = true
        iconView.heightAnchor.constraint(equalToConstant: 72).isActive = true
        if let icon = APKLibrary.shared.icon(for: package) {
            iconView.image = icon
        } else {
            iconView.image = UIImage(systemName: "shippingbox.fill")
            iconView.tintColor = Theme.accent
        }

        let titleLabel = UILabel()
        titleLabel.text = package.displayName
        titleLabel.font = .systemFont(ofSize: 22, weight: .bold)
        titleLabel.textColor = Theme.textPrimary
        titleLabel.numberOfLines = 2

        let fileLabel = UILabel()
        fileLabel.text = package.originalFileName
        fileLabel.font = .systemFont(ofSize: 13, weight: .regular)
        fileLabel.textColor = Theme.textSecondary
        fileLabel.numberOfLines = 1

        let titleStack = UIStackView(arrangedSubviews: [titleLabel, fileLabel])
        titleStack.axis = .vertical
        titleStack.spacing = 4

        let headerRow = UIStackView(arrangedSubviews: [iconView, titleStack])
        headerRow.axis = .horizontal
        headerRow.spacing = 14
        headerRow.alignment = .center
        headerRow.translatesAutoresizingMaskIntoConstraints = false

        header.addSubview(headerRow)
        NSLayoutConstraint.activate([
            headerRow.topAnchor.constraint(equalTo: header.topAnchor, constant: 16),
            headerRow.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 16),
            headerRow.trailingAnchor.constraint(equalTo: header.trailingAnchor, constant: -16),
            headerRow.bottomAnchor.constraint(equalTo: header.bottomAnchor, constant: -16)
        ])
        contentStack.addArrangedSubview(header)

        // Actions
        contentStack.addArrangedSubview(sectionTitle("Launch decoder"))
        contentStack.addArrangedSubview(actionButton(
            title: "Open Package Contents",
            subtitle: "Browse and open individual files inside the APK",
            systemImage: "folder.badge.gearshape",
            action: #selector(openBrowser)
        ))
        contentStack.addArrangedSubview(actionButton(
            title: "Extract All & Save",
            subtitle: "Decode the full archive into Extracted/\(package.extractFolderName)",
            systemImage: "arrow.down.doc.fill",
            action: #selector(extractAll)
        ))
        contentStack.addArrangedSubview(actionButton(
            title: "View Saved Data",
            subtitle: "Open the package’s Saved Files folder",
            systemImage: "tray.full.fill",
            action: #selector(openSaved)
        ))

        progressView.isHidden = true
        progressView.progressTintColor = Theme.accent
        progressView.trackTintColor = Theme.cardBorder
        progressView.translatesAutoresizingMaskIntoConstraints = false
        progressView.heightAnchor.constraint(equalToConstant: 4).isActive = true
        contentStack.addArrangedSubview(progressView)

        // Metadata (filled after decode)
        contentStack.addArrangedSubview(sectionTitle("Package info"))
        let metaCard = cardView()
        metaCard.tag = 9001
        contentStack.addArrangedSubview(metaCard)

        contentStack.addArrangedSubview(sectionTitle("Components & permissions"))
        let componentsCard = cardView()
        componentsCard.tag = 9002
        contentStack.addArrangedSubview(componentsCard)
    }

    private func loadDecoder() {
        let url = APKLibrary.shared.apkURL(for: package)
        do {
            let dec = try APKDecoder(package: package, apkURL: url)
            decoder = dec
            summary = dec.decodeManifestSummary()
            package = APKLibrary.shared.refreshMetadata(for: package)
            if let icon = dec.extractIcon() {
                iconView.image = icon
                iconView.tintColor = nil
            }
            populateMetadata()
        } catch {
            populateError(error.localizedDescription)
        }
    }

    private func populateMetadata() {
        guard let metaCard = view.viewWithTag(9001) else { return }
        metaCard.subviews.forEach { $0.removeFromSuperview() }

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        metaCard.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: metaCard.topAnchor, constant: 14),
            stack.leadingAnchor.constraint(equalTo: metaCard.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: metaCard.trailingAnchor, constant: -14),
            stack.bottomAnchor.constraint(equalTo: metaCard.bottomAnchor, constant: -14)
        ])

        let rows: [(String, String?)] = [
            ("Package", package.packageName ?? summary.packageName),
            ("Label", package.label ?? summary.label),
            ("Version", package.versionName ?? summary.versionName),
            ("Version code", package.versionCode ?? summary.versionCode),
            ("Min SDK", package.minSDK ?? summary.minSDK),
            ("Target SDK", package.targetSDK ?? summary.targetSDK),
            ("Size", package.fileSize.apkByteString),
            ("Entries", package.entryCount > 0 ? "\(package.entryCount)" : (decoder.map { "\($0.allEntries.filter { !$0.isDirectory }.count)" } ?? "—")),
            ("Imported", Self.dateFormatter.string(from: package.importedAt))
        ]
        for (label, value) in rows {
            stack.addArrangedSubview(metaRow(label, value ?? "—"))
        }

        // Components card
        guard let compCard = view.viewWithTag(9002) else { return }
        compCard.subviews.forEach { $0.removeFromSuperview() }
        let cstack = UIStackView()
        cstack.axis = .vertical
        cstack.spacing = 12
        cstack.translatesAutoresizingMaskIntoConstraints = false
        compCard.addSubview(cstack)
        NSLayoutConstraint.activate([
            cstack.topAnchor.constraint(equalTo: compCard.topAnchor, constant: 14),
            cstack.leadingAnchor.constraint(equalTo: compCard.leadingAnchor, constant: 14),
            cstack.trailingAnchor.constraint(equalTo: compCard.trailingAnchor, constant: -14),
            cstack.bottomAnchor.constraint(equalTo: compCard.bottomAnchor, constant: -14)
        ])

        cstack.addArrangedSubview(bulletSection("Permissions", summary.permissions))
        cstack.addArrangedSubview(bulletSection("Activities", summary.activities))
        cstack.addArrangedSubview(bulletSection("Services", summary.services))
        cstack.addArrangedSubview(bulletSection("Receivers", summary.receivers))
        cstack.addArrangedSubview(bulletSection("Providers", summary.providers))
    }

    private func populateError(_ message: String) {
        guard let metaCard = view.viewWithTag(9001) else { return }
        metaCard.subviews.forEach { $0.removeFromSuperview() }
        let label = UILabel()
        label.text = message
        label.textColor = Theme.danger
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        metaCard.addSubview(label)
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: metaCard.topAnchor, constant: 14),
            label.leadingAnchor.constraint(equalTo: metaCard.leadingAnchor, constant: 14),
            label.trailingAnchor.constraint(equalTo: metaCard.trailingAnchor, constant: -14),
            label.bottomAnchor.constraint(equalTo: metaCard.bottomAnchor, constant: -14)
        ])
    }

    // MARK: - Actions

    @objc private func openBrowser() {
        guard let decoder else {
            presentAlert("Decoder unavailable", message: "Could not open this APK.")
            return
        }
        let browser = ArchiveBrowserViewController(decoder: decoder, directoryPath: "")
        navigationController?.pushViewController(browser, animated: true)
    }

    @objc private func extractAll() {
        guard let decoder else { return }
        progressView.isHidden = false
        progressView.progress = 0
        view.isUserInteractionEnabled = false

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let root = try decoder.extractAll(to: APKLibrary.shared.extractedURL) { p in
                    DispatchQueue.main.async { self.progressView.progress = Float(p) }
                }
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    self.progressView.isHidden = true
                    self.presentAlert(
                        "Extracted",
                        message: "Full package saved to:\n\(root.lastPathComponent)\n\nOpen it from Files → APKBox → Extracted."
                    )
                }
            } catch {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    self.progressView.isHidden = true
                    self.presentAlert("Extract failed", message: error.localizedDescription)
                }
            }
        }
    }

    @objc private func openSaved() {
        let folder = APKLibrary.shared.savedFolder(for: package)
        let browser = SavedFilesViewController(rootURL: folder, titleText: "Saved · \(package.displayName)")
        navigationController?.pushViewController(browser, animated: true)
    }

    @objc private func shareAPK() {
        let url = APKLibrary.shared.apkURL(for: package)
        let activity = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let pop = activity.popoverPresentationController {
            pop.barButtonItem = navigationItem.rightBarButtonItem
        }
        present(activity, animated: true)
    }

    // MARK: - UI helpers

    private func cardView() -> UIView {
        let v = UIView()
        v.backgroundColor = Theme.card
        v.layer.cornerRadius = 14
        v.layer.borderWidth = 1
        v.layer.borderColor = Theme.cardBorder.cgColor
        return v
    }

    private func sectionTitle(_ text: String) -> UILabel {
        let l = UILabel()
        l.text = text.uppercased()
        l.font = .systemFont(ofSize: 12, weight: .semibold)
        l.textColor = Theme.textSecondary
        return l
    }

    private func actionButton(title: String, subtitle: String, systemImage: String, action: Selector) -> UIButton {
        var config = UIButton.Configuration.filled()
        config.baseBackgroundColor = Theme.card
        config.baseForegroundColor = Theme.textPrimary
        config.cornerStyle = .medium
        config.image = UIImage(systemName: systemImage)
        config.imagePlacement = .leading
        config.imagePadding = 12
        config.contentInsets = NSDirectionalEdgeInsets(top: 14, leading: 14, bottom: 14, trailing: 14)
        config.title = title
        config.subtitle = subtitle
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var out = incoming
            out.font = .systemFont(ofSize: 16, weight: .semibold)
            return out
        }
        config.subtitleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var out = incoming
            out.font = .systemFont(ofSize: 12, weight: .regular)
            out.foregroundColor = Theme.textSecondary
            return out
        }

        let button = UIButton(configuration: config)
        button.addTarget(self, action: action, for: .touchUpInside)
        button.layer.cornerRadius = 14
        button.layer.borderWidth = 1
        button.layer.borderColor = Theme.cardBorder.cgColor
        button.clipsToBounds = true
        return button
    }

    private func metaRow(_ label: String, _ value: String) -> UIView {
        let l = UILabel()
        l.text = label
        l.font = .systemFont(ofSize: 13, weight: .medium)
        l.textColor = Theme.textSecondary
        l.setContentHuggingPriority(.required, for: .horizontal)
        l.widthAnchor.constraint(equalToConstant: 110).isActive = true

        let v = UILabel()
        v.text = value
        v.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        v.textColor = Theme.textPrimary
        v.numberOfLines = 0
        v.lineBreakMode = .byCharWrapping

        let row = UIStackView(arrangedSubviews: [l, v])
        row.axis = .horizontal
        row.spacing = 8
        row.alignment = .top
        return row
    }

    private func bulletSection(_ title: String, _ items: [String]) -> UIView {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 4

        let t = UILabel()
        t.text = "\(title) (\(items.count))"
        t.font = .systemFont(ofSize: 14, weight: .semibold)
        t.textColor = Theme.accent
        stack.addArrangedSubview(t)

        if items.isEmpty {
            let empty = UILabel()
            empty.text = "None detected"
            empty.font = .systemFont(ofSize: 13)
            empty.textColor = Theme.textSecondary
            stack.addArrangedSubview(empty)
        } else {
            for item in items.prefix(40) {
                let l = UILabel()
                l.text = "• \(item)"
                l.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
                l.textColor = Theme.textPrimary
                l.numberOfLines = 0
                stack.addArrangedSubview(l)
            }
            if items.count > 40 {
                let more = UILabel()
                more.text = "…and \(items.count - 40) more"
                more.font = .systemFont(ofSize: 12)
                more.textColor = Theme.textSecondary
                stack.addArrangedSubview(more)
            }
        }
        return stack
    }

    private func presentAlert(_ title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f
    }()
}
