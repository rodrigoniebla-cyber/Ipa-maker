import Foundation
import UIKit

extension Notification.Name {
    static let apkLibraryDidChange = Notification.Name("apkLibraryDidChange")
}

/// Metadata for one imported APK package sitting in the app container.
struct APKPackage: Codable, Equatable, Identifiable {
    var id: String
    var displayName: String
    var originalFileName: String
    var importedAt: Date
    var fileSize: Int64
    var packageName: String?
    var versionName: String?
    var versionCode: String?
    var minSDK: String?
    var targetSDK: String?
    var label: String?
    var entryCount: Int
    var hasIcon: Bool

    var apkFileName: String { "\(id).apk" }
    var extractFolderName: String { id }
}

/// One entry inside a decoded APK (ZIP) archive.
struct APKEntry: Equatable, Identifiable {
    var id: String { path }
    var path: String
    var isDirectory: Bool
    var uncompressedSize: Int
    var compressedSize: Int

    var name: String {
        if path.hasSuffix("/") {
            return (path as NSString).lastPathComponent.isEmpty
                ? path
                : String(path.dropLast()).components(separatedBy: "/").last ?? path
        }
        return (path as NSString).lastPathComponent
    }

    var fileExtension: String {
        (name as NSString).pathExtension.lowercased()
    }

    var kind: EntryKind {
        if isDirectory { return .directory }
        switch fileExtension {
        case "xml": return .xml
        case "png", "jpg", "jpeg", "webp", "gif", "bmp": return .image
        case "txt", "md", "json", "properties", "csv", "log", "html", "htm", "css", "js", "kt", "java", "smali": return .text
        case "dex": return .dex
        case "so": return .nativeLib
        case "arsc": return .resources
        case "mf", "sf", "rsa", "dsa", "ec": return .signature
        default: return .binary
        }
    }
}

enum EntryKind: String {
    case directory, xml, image, text, dex, nativeLib, resources, signature, binary

    var systemImage: String {
        switch self {
        case .directory: return "folder.fill"
        case .xml: return "doc.text"
        case .image: return "photo"
        case .text: return "doc.plaintext"
        case .dex: return "cpu"
        case .nativeLib: return "shippingbox"
        case .resources: return "square.stack.3d.up"
        case .signature: return "checkmark.seal"
        case .binary: return "doc"
        }
    }

    var tint: UIColor {
        switch self {
        case .directory: return Theme.accent
        case .xml: return UIColor.systemTeal
        case .image: return UIColor.systemPurple
        case .text: return UIColor.systemYellow
        case .dex: return UIColor.systemOrange
        case .nativeLib: return UIColor.systemBlue
        case .resources: return UIColor.systemIndigo
        case .signature: return UIColor.systemGreen
        case .binary: return Theme.textSecondary
        }
    }
}

/// Lightweight Android binary-XML / manifest summary.
struct ManifestSummary {
    var packageName: String?
    var versionName: String?
    var versionCode: String?
    var minSDK: String?
    var targetSDK: String?
    var label: String?
    var permissions: [String]
    var activities: [String]
    var services: [String]
    var receivers: [String]
    var providers: [String]
    var rawHints: [String: String]

    static var empty: ManifestSummary {
        ManifestSummary(
            packageName: nil,
            versionName: nil,
            versionCode: nil,
            minSDK: nil,
            targetSDK: nil,
            label: nil,
            permissions: [],
            activities: [],
            services: [],
            receivers: [],
            providers: [],
            rawHints: [:]
        )
    }
}
