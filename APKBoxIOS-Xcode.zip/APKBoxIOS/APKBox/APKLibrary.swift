import Foundation
import UIKit

/// Owns the on-disk APK container:
///   Documents/APKs/           — imported .apk binaries
///   Documents/Extracted/      — fully extracted trees
///   Documents/Saved Files/    — individual files the user saved
///   Documents/library.json    — package index
///
/// UIFileSharingEnabled + LSSupportsOpeningDocumentsInPlace expose these
/// folders in the Files app so data survives and can be copied out.
final class APKLibrary {
    static let shared = APKLibrary()

    private let fileManager = FileManager.default
    private let ioQueue = DispatchQueue(label: "ai.arena.apkbox.library", qos: .userInitiated)

    private var packages: [APKPackage] = []

    private init() {
        ensureDirectories()
        loadIndex()
        reconcileWithDisk()
    }

    // MARK: - Paths

    var documentsURL: URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    var apksURL: URL {
        documentsURL.appendingPathComponent("APKs", isDirectory: true)
    }

    var extractedURL: URL {
        documentsURL.appendingPathComponent("Extracted", isDirectory: true)
    }

    var savedFilesURL: URL {
        documentsURL.appendingPathComponent("Saved Files", isDirectory: true)
    }

    private var indexURL: URL {
        documentsURL.appendingPathComponent("library.json")
    }

    func ensureDirectories() {
        for url in [apksURL, extractedURL, savedFilesURL] {
            try? fileManager.createDirectory(at: url, withIntermediateDirectories: true)
        }
        // Drop a helpful README the first time.
        let readme = documentsURL.appendingPathComponent("README.txt")
        if !fileManager.fileExists(atPath: readme.path) {
            let text = """
            APKBox container folders
            ========================
            APKs/          Imported Android packages (.apk)
            Extracted/     Full decoded trees (one folder per package)
            Saved Files/   Individual files you saved from the decoder

            Everything here is visible in the iOS Files app (On My iPhone/iPad → APKBox).
            """
            try? text.data(using: .utf8)?.write(to: readme)
        }
    }

    // MARK: - Queries

    func allPackages() -> [APKPackage] {
        packages.sorted { $0.importedAt > $1.importedAt }
    }

    func package(id: String) -> APKPackage? {
        packages.first { $0.id == id }
    }

    func apkURL(for package: APKPackage) -> URL {
        apksURL.appendingPathComponent(package.apkFileName)
    }

    func extractRoot(for package: APKPackage) -> URL {
        extractedURL.appendingPathComponent(package.extractFolderName, isDirectory: true)
    }

    func savedFolder(for package: APKPackage) -> URL {
        let url = savedFilesURL.appendingPathComponent(package.displayName, isDirectory: true)
        try? fileManager.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    // MARK: - Import

    @discardableResult
    func importAPK(from sourceURL: URL, copy: Bool = true) throws -> APKPackage {
        ensureDirectories()

        let accessed = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if accessed { sourceURL.stopAccessingSecurityScopedResource() }
        }

        let originalName = sourceURL.lastPathComponent
        let id = UUID().uuidString.lowercased()
        let dest = apksURL.appendingPathComponent("\(id).apk")

        if copy {
            if fileManager.fileExists(atPath: dest.path) {
                try fileManager.removeItem(at: dest)
            }
            try fileManager.copyItem(at: sourceURL, to: dest)
        } else {
            try fileManager.moveItem(at: sourceURL, to: dest)
        }

        let attrs = try fileManager.attributesOfItem(atPath: dest.path)
        let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0

        var package = APKPackage(
            id: id,
            displayName: (originalName as NSString).deletingPathExtension,
            originalFileName: originalName,
            importedAt: Date(),
            fileSize: size,
            packageName: nil,
            versionName: nil,
            versionCode: nil,
            minSDK: nil,
            targetSDK: nil,
            label: nil,
            entryCount: 0,
            hasIcon: false
        )

        // Decode metadata up-front so the library list is informative.
        if let decoder = try? APKDecoder(package: package, apkURL: dest) {
            let summary = decoder.decodeManifestSummary()
            package.packageName = summary.packageName
            package.versionName = summary.versionName
            package.versionCode = summary.versionCode
            package.minSDK = summary.minSDK
            package.targetSDK = summary.targetSDK
            package.label = summary.label
            package.entryCount = decoder.allEntries.filter { !$0.isDirectory }.count

            if let label = summary.label, !label.isEmpty, !label.hasPrefix("@") {
                package.displayName = label
            } else if let pkg = summary.packageName, !pkg.isEmpty {
                package.displayName = pkg.components(separatedBy: ".").last ?? package.displayName
            }

            if let icon = decoder.extractIcon() {
                package.hasIcon = true
                let iconURL = apksURL.appendingPathComponent("\(id).png")
                if let png = icon.pngData() {
                    try? png.write(to: iconURL)
                }
            }
        }

        packages.removeAll { $0.id == id }
        packages.append(package)
        saveIndex()
        return package
    }

    func remove(_ package: APKPackage) {
        packages.removeAll { $0.id == package.id }
        saveIndex()
        let apk = apkURL(for: package)
        let icon = apksURL.appendingPathComponent("\(package.id).png")
        let extracted = extractRoot(for: package)
        try? fileManager.removeItem(at: apk)
        try? fileManager.removeItem(at: icon)
        try? fileManager.removeItem(at: extracted)
    }

    func refreshMetadata(for package: APKPackage) -> APKPackage {
        guard let idx = packages.firstIndex(where: { $0.id == package.id }) else { return package }
        var updated = packages[idx]
        let url = apkURL(for: updated)
        if let decoder = try? APKDecoder(package: updated, apkURL: url) {
            let summary = decoder.decodeManifestSummary()
            updated.packageName = summary.packageName ?? updated.packageName
            updated.versionName = summary.versionName ?? updated.versionName
            updated.versionCode = summary.versionCode ?? updated.versionCode
            updated.minSDK = summary.minSDK ?? updated.minSDK
            updated.targetSDK = summary.targetSDK ?? updated.targetSDK
            updated.label = summary.label ?? updated.label
            updated.entryCount = decoder.allEntries.filter { !$0.isDirectory }.count
            if let icon = decoder.extractIcon(), let png = icon.pngData() {
                updated.hasIcon = true
                try? png.write(to: apksURL.appendingPathComponent("\(updated.id).png"))
            }
        }
        packages[idx] = updated
        saveIndex()
        return updated
    }

    func icon(for package: APKPackage) -> UIImage? {
        let iconURL = apksURL.appendingPathComponent("\(package.id).png")
        guard let data = try? Data(contentsOf: iconURL) else { return nil }
        return UIImage(data: data)
    }

    // MARK: - Index persistence

    private func loadIndex() {
        guard let data = try? Data(contentsOf: indexURL) else {
            packages = []
            return
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        packages = (try? decoder.decode([APKPackage].self, from: data)) ?? []
    }

    private func saveIndex() {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(packages) else { return }
        try? data.write(to: indexURL, options: .atomic)
    }

    private func reconcileWithDisk() {
        // Drop index rows whose apk file vanished; pick up orphan apks.
        packages = packages.filter {
            fileManager.fileExists(atPath: apkURL(for: $0).path)
        }

        let known = Set(packages.map { $0.apkFileName })
        if let files = try? fileManager.contentsOfDirectory(at: apksURL, includingPropertiesForKeys: nil) {
            for file in files where file.pathExtension.lowercased() == "apk" {
                let name = file.lastPathComponent
                if known.contains(name) { continue }
                // Orphan apk — register it.
                let id = (name as NSString).deletingPathExtension
                let attrs = try? fileManager.attributesOfItem(atPath: file.path)
                let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                let pkg = APKPackage(
                    id: id,
                    displayName: id,
                    originalFileName: name,
                    importedAt: (attrs?[.creationDate] as? Date) ?? Date(),
                    fileSize: size,
                    packageName: nil,
                    versionName: nil,
                    versionCode: nil,
                    minSDK: nil,
                    targetSDK: nil,
                    label: nil,
                    entryCount: 0,
                    hasIcon: fileManager.fileExists(atPath: apksURL.appendingPathComponent("\(id).png").path)
                )
                packages.append(pkg)
            }
        }
        saveIndex()
    }
}

extension Int64 {
    var apkByteString: String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        return formatter.string(fromByteCount: self)
    }
}

extension Int {
    var apkByteString: String {
        Int64(self).apkByteString
    }
}
