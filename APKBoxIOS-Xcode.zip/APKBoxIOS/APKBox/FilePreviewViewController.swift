import UIKit

/// Opens a single APK entry: images render natively, text/XML/hex in a
/// monospaced viewer, other binaries get a metadata + hex preview.
/// Always offers Save into the container and Share.
final class FilePreviewViewController: UIViewController {
    private let decoder: APKDecoder
    private let entry: APKEntry

    private var textView: UITextView?
    private var imageView: UIImageView?
    private var scrollView: UIScrollView?
    private var statusLabel: UILabel!
    private var rawData: Data?

    init(decoder: APKDecoder, entry: APKEntry) {
        self.decoder = decoder
        self.entry = entry
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.background
        title = entry.name
        navigationItem.largeTitleDisplayMode = .never

        let save = UIBarButtonItem(
            image: UIImage(systemName: "arrow.down.doc.fill"),
            style: .plain,
            target: self,
            action: #selector(saveTapped)
        )
        let share = UIBarButtonItem(
            image: UIImage(systemName: "square.and.arrow.up"),
            style: .plain,
            target: self,
            action: #selector(shareTapped)
        )
        navigationItem.rightBarButtonItems = [share, save]

        statusLabel = UILabel()
        statusLabel.textAlignment = .center
        statusLabel.textColor = Theme.textSecondary
        statusLabel.font = .systemFont(ofSize: 14)
        statusLabel.numberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),
            statusLabel.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor)
        ])
        statusLabel.text = "Opening…"

        // Path breadcrumb under nav title via prompt-like label
        let pathLabel = UILabel()
        pathLabel.text = entry.path
        pathLabel.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        pathLabel.textColor = Theme.textSecondary
        pathLabel.numberOfLines = 2
        pathLabel.textAlignment = .center
        navigationItem.prompt = nil

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.loadContent()
        }
    }

    private func loadContent() {
        do {
            let data = try decoder.data(for: entry.path)
            rawData = data

            switch entry.kind {
            case .image:
                if let image = decoder.decodeImage(data) {
                    DispatchQueue.main.async { self.showImage(image, info: self.infoLine(data.count)) }
                    return
                }
                fallthrough
            case .text, .xml, .signature:
                let text = try decoder.textPreview(for: entry.path)
                DispatchQueue.main.async { self.showText(text, info: self.infoLine(data.count)) }
            case .dex, .nativeLib, .resources, .binary, .directory:
                // Try text first; otherwise hex.
                if let text = try? decoder.textPreview(for: entry.path),
                   !text.hasPrefix("(binary") || data.count < 64 {
                    DispatchQueue.main.async { self.showText(text, info: self.infoLine(data.count)) }
                } else {
                    let text = try decoder.textPreview(for: entry.path)
                    DispatchQueue.main.async { self.showText(text, info: self.infoLine(data.count)) }
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.statusLabel.text = "Could not open file:\n\(error.localizedDescription)"
            }
        }
    }

    private func infoLine(_ byteCount: Int) -> String {
        "\(entry.path)\n\(entry.kind.rawValue) · \(byteCount.apkByteString)"
    }

    private func showImage(_ image: UIImage, info: String) {
        statusLabel.isHidden = true
        let scroll = UIScrollView(frame: view.bounds)
        scroll.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scroll.backgroundColor = Theme.background
        scroll.minimumZoomScale = 0.25
        scroll.maximumZoomScale = 6
        scroll.delegate = self
        view.addSubview(scroll)
        scrollView = scroll

        let iv = UIImageView(image: image)
        iv.contentMode = .scaleAspectFit
        iv.frame = CGRect(origin: .zero, size: image.size)
        scroll.addSubview(iv)
        scroll.contentSize = image.size
        imageView = iv

        // Fit initially
        view.layoutIfNeeded()
        let scale = min(scroll.bounds.width / max(image.size.width, 1),
                        scroll.bounds.height / max(image.size.height, 1),
                        1)
        scroll.zoomScale = scale
        centerImage()

        navigationItem.prompt = "\(Int(image.size.width))×\(Int(image.size.height)) · \(info.components(separatedBy: "\n").last ?? "")"
    }

    private func showText(_ text: String, info: String) {
        statusLabel.isHidden = true
        let tv = UITextView(frame: view.bounds)
        tv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tv.backgroundColor = Theme.background
        tv.textColor = Theme.textPrimary
        tv.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        tv.isEditable = false
        tv.isSelectable = true
        tv.text = text
        tv.textContainerInset = UIEdgeInsets(top: 12, left: 10, bottom: 24, right: 10)
        tv.alwaysBounceVertical = true
        view.addSubview(tv)
        textView = tv

        let short = info.components(separatedBy: "\n").last ?? info
        navigationItem.prompt = short
    }

    private func centerImage() {
        guard let scroll = scrollView, let imageView else { return }
        let boundsSize = scroll.bounds.size
        var frame = imageView.frame
        if frame.size.width < boundsSize.width {
            frame.origin.x = (boundsSize.width - frame.size.width) / 2
        } else {
            frame.origin.x = 0
        }
        if frame.size.height < boundsSize.height {
            frame.origin.y = (boundsSize.height - frame.size.height) / 2
        } else {
            frame.origin.y = 0
        }
        imageView.frame = frame
    }

    // MARK: - Save / Share

    @objc private func saveTapped() {
        let sheet = UIAlertController(title: "Save file", message: entry.name, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Save to package folder", style: .default) { _ in
            self.save(to: APKLibrary.shared.savedFolder(for: self.decoder.package))
        })
        sheet.addAction(UIAlertAction(title: "Save to Saved Files root", style: .default) { _ in
            self.save(to: APKLibrary.shared.savedFilesURL)
        })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let pop = sheet.popoverPresentationController {
            pop.barButtonItem = navigationItem.rightBarButtonItems?.last
        }
        present(sheet, animated: true)
    }

    private func save(to directory: URL) {
        do {
            let dest = try decoder.saveEntry(entry.path, to: directory)
            let alert = UIAlertController(
                title: "Saved",
                message: "Wrote \(dest.lastPathComponent)\n\nFiles → APKBox → Saved Files",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        } catch {
            let alert = UIAlertController(title: "Save failed", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

    @objc private func shareTapped() {
        do {
            let data = try rawData ?? decoder.data(for: entry.path)
            let temp = FileManager.default.temporaryDirectory.appendingPathComponent(entry.name)
            try data.write(to: temp, options: .atomic)
            let activity = UIActivityViewController(activityItems: [temp], applicationActivities: nil)
            if let pop = activity.popoverPresentationController {
                pop.barButtonItem = navigationItem.rightBarButtonItems?.first
            }
            present(activity, animated: true)
        } catch {
            let alert = UIAlertController(title: "Share failed", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}

extension FilePreviewViewController: UIScrollViewDelegate {
    func viewForZooming(in scrollView: UIScrollView) -> UIView? { imageView }
    func scrollViewDidZoom(_ scrollView: UIScrollView) { centerImage() }
}

// MARK: - Saved files browser (on-disk container data)

final class SavedFilesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let rootURL: URL
    private let titleText: String
    private var items: [URL] = []
    private var tableView: UITableView!

    init(rootURL: URL, titleText: String) {
        self.rootURL = rootURL
        self.titleText = titleText
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = titleText
        view.backgroundColor = Theme.background
        navigationItem.largeTitleDisplayMode = .never

        tableView = UITableView(frame: view.bounds, style: .insetGrouped)
        tableView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tableView.backgroundColor = Theme.background
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(tableView)

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .refresh,
            target: self,
            action: #selector(reload)
        )
        reload()
    }

    @objc private func reload() {
        try? FileManager.default.createDirectory(at: rootURL, withIntermediateDirectories: true)
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: rootURL,
            includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        )) ?? []
        items = urls.sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
        tableView.reloadData()

        if items.isEmpty {
            let empty = UILabel()
            empty.text = "No saved files yet.\nOpen a file in the decoder and tap Save."
            empty.textAlignment = .center
            empty.textColor = Theme.textSecondary
            empty.numberOfLines = 0
            empty.font = .systemFont(ofSize: 15)
            tableView.backgroundView = empty
        } else {
            tableView.backgroundView = nil
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { items.count }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let url = items[indexPath.row]
        var isDir: ObjCBool = false
        FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
        var content = cell.defaultContentConfiguration()
        content.text = url.lastPathComponent
        content.textProperties.color = Theme.textPrimary
        if isDir.boolValue {
            content.secondaryText = "Folder"
            content.image = UIImage(systemName: "folder.fill")
            content.imageProperties.tintColor = Theme.accent
        } else {
            let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
            content.secondaryText = size.apkByteString
            content.image = UIImage(systemName: "doc.fill")
            content.imageProperties.tintColor = Theme.textSecondary
        }
        content.secondaryTextProperties.color = Theme.textSecondary
        cell.contentConfiguration = content
        cell.backgroundColor = Theme.card
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let url = items[indexPath.row]
        var isDir: ObjCBool = false
        FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
        if isDir.boolValue {
            let next = SavedFilesViewController(rootURL: url, titleText: url.lastPathComponent)
            navigationController?.pushViewController(next, animated: true)
        } else {
            let preview = OnDiskFileViewController(fileURL: url)
            navigationController?.pushViewController(preview, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let url = items[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: "Delete") { [weak self] _, _, done in
            try? FileManager.default.removeItem(at: url)
            self?.reload()
            done(true)
        }
        return UISwipeActionsConfiguration(actions: [delete])
    }
}

final class OnDiskFileViewController: UIViewController {
    private let fileURL: URL
    private var textView: UITextView!

    init(fileURL: URL) {
        self.fileURL = fileURL
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = fileURL.lastPathComponent
        view.backgroundColor = Theme.background
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "square.and.arrow.up"),
            style: .plain,
            target: self,
            action: #selector(share)
        )

        textView = UITextView(frame: view.bounds)
        textView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        textView.backgroundColor = Theme.background
        textView.textColor = Theme.textPrimary
        textView.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        textView.isEditable = false
        view.addSubview(textView)

        if let data = try? Data(contentsOf: fileURL) {
            if let image = UIImage(data: data) {
                let iv = UIImageView(image: image)
                iv.contentMode = .scaleAspectFit
                iv.frame = view.bounds
                iv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                iv.backgroundColor = Theme.background
                view.addSubview(iv)
                textView.isHidden = true
            } else if let text = String(data: data, encoding: .utf8) {
                textView.text = text
            } else {
                textView.text = "Binary file · \(data.count) bytes\n\nUse Share to export."
            }
        } else {
            textView.text = "Could not read file."
        }
    }

    @objc private func share() {
        let activity = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        present(activity, animated: true)
    }
}
