# APKBox

iOS/iPadOS **APK container + decoder**. Not an Android emulator — it opens
`.apk` packages (ZIP archives), lets you browse and open individual files,
and saves extracted data inside the app container (visible in the Files app).

Built as a plain Xcode project so it can be compiled into an **unsigned IPA**
with [Ipa-maker](https://github.com/rodrigoniebla-cyber/Ipa-maker).

## Features

- **Import APKs** via document picker, Files, AirDrop, or “Open in APKBox”
- **Decode** the package (ZIP central directory + deflate)
- **Package info** recovered from `AndroidManifest.xml` (package name,
  version, SDK levels, permissions, activities, services, …)
- **Browse** the archive tree or a flat file list with search
- **Open** individual files:
  - images (png/jpg/webp) rendered natively
  - text / recovered binary-XML strings in a monospaced viewer
  - other binaries as a hex preview
- **Save data** into the app container:
  - `Documents/APKs/` — imported packages
  - `Documents/Extracted/<id>/` — full extracted trees
  - `Documents/Saved Files/` — single-file exports
- **Share** any entry or the original APK
- Files app sharing enabled (`UIFileSharingEnabled`)

## Requirements

- iOS / iPadOS 16.0+
- Xcode 15+ (Ipa-maker’s macOS runners work out of the box)

## Build with Ipa-maker

### Option A — upload this zip

1. Zip the `APKBoxIOS` folder (the one that contains `APKBox.xcodeproj`).
2. Push the zip into `uploads/` on the Ipa-maker repo (or use the GitHub
   “Upload files” UI).
3. The **Build Unsigned IPA** workflow runs automatically, or trigger it
   manually with `zip_path` set to your file.
4. Grab `builds/APKBox.ipa` when the run finishes.

### Option B — point at a git repo

If this project lives in its own GitHub repo:

1. Actions → **Build Unsigned IPA** → Run workflow
2. `repo_url` = your repo URL
3. `scheme` = `APKBox` (optional; auto-detect usually works)
4. Leave `project_subpath` empty if `APKBox.xcodeproj` is at the repo root,
   or set it to the folder that contains the `.xcodeproj`.

## Local Xcode build

```bash
xcodebuild archive \
  -project APKBox.xcodeproj \
  -scheme APKBox \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath build/APKBox.xcarchive \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM=""

# Package Payload/*.ipa
mkdir -p build/Payload
cp -R build/APKBox.xcarchive/Products/Applications/APKBox.app build/Payload/
(cd build && zip -r APKBox.ipa Payload)
```

## Notes

- This does **not** run Android apps or DEX bytecode. It is a file container
  and decoder for inspecting and extracting APK contents on iOS.
- Binary `AndroidManifest.xml` parsing is best-effort string recovery, not a
  full AXML/ARSC resource table walker.
- The unsigned IPA from Ipa-maker needs your own signing/resigning step before
  it will install on a device.
