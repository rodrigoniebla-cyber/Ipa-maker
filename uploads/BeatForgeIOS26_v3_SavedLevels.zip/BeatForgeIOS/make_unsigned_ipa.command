#!/bin/bash
set -uo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
DERIVED="$ROOT/.build-ios26"
APP="$DERIVED/Build/Products/Release-iphoneos/BeatForge.app"
IPA="$ROOT/BeatForge-iOS26-v3-unsigned.ipa"
PAYLOAD="$ROOT/Payload"
LOG="$ROOT/BeatForge-build.log"

cd "$ROOT" || exit 1
rm -rf "$DERIVED" "$PAYLOAD" "$IPA" "$LOG"
/usr/bin/xattr -cr "$ROOT" 2>/dev/null || true
/usr/bin/find "$ROOT/BeatForge/Assets.xcassets" -type f -name '*.png' -exec /bin/chmod 0644 {} +

# A common source of exit 65 is xcode-select pointing at CommandLineTools
# instead of the complete Xcode application.
if [ -d "/Applications/Xcode.app/Contents/Developer" ]; then
  export DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERROR: Full Xcode 26 or newer is required (not only Command Line Tools)." | tee "$LOG"
  read -r -p "Press Return to close..."
  exit 1
fi

XCODE_VERSION="$(xcodebuild -version | head -n 1 | awk '{print $2}')"
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version 2>/dev/null || true)"
SDK_MAJOR="${SDK_VERSION%%.*}"

echo "BeatForge iOS 26 build" | tee "$LOG"
echo "Xcode: ${XCODE_VERSION:-unknown}" | tee -a "$LOG"
echo "iPhoneOS SDK: ${SDK_VERSION:-not found}" | tee -a "$LOG"

if [ -z "$SDK_VERSION" ] || ! [[ "$SDK_MAJOR" =~ ^[0-9]+$ ]] || [ "$SDK_MAJOR" -lt 26 ]; then
  echo "ERROR: The selected Xcode does not contain the iOS 26 SDK." | tee -a "$LOG"
  echo "Install Xcode 26+, open it once, then run: sudo xcode-select -s /Applications/Xcode.app" | tee -a "$LOG"
  read -r -p "Press Return to close..."
  exit 1
fi

echo | tee -a "$LOG"
echo "Compiling an unsigned ARM64 device build..." | tee -a "$LOG"

set +e
xcodebuild \
  -project "$ROOT/BeatForge.xcodeproj" \
  -scheme BeatForge \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  clean build 2>&1 | tee -a "$LOG"
BUILD_STATUS=${PIPESTATUS[0]}
set -e

if [ "$BUILD_STATUS" -ne 0 ]; then
  echo | tee -a "$LOG"
  echo "BUILD FAILED (xcodebuild exit $BUILD_STATUS)." | tee -a "$LOG"
  echo "The complete diagnostic output is in BeatForge-build.log." | tee -a "$LOG"
  echo "First try Product > Clean Build Folder in Xcode, then run this script again." | tee -a "$LOG"
  open "$LOG" 2>/dev/null || true
  read -r -p "Press Return to close..."
  exit "$BUILD_STATUS"
fi

if [ ! -d "$APP" ]; then
  echo "ERROR: Xcode reported success, but BeatForge.app was not found at $APP" | tee -a "$LOG"
  read -r -p "Press Return to close..."
  exit 1
fi

mkdir -p "$PAYLOAD"
cp -R "$APP" "$PAYLOAD/"
/usr/bin/zip -qry "$IPA" Payload
rm -rf "$PAYLOAD"

if [ ! -f "$IPA" ]; then
  echo "ERROR: IPA packaging did not complete." | tee -a "$LOG"
  exit 1
fi

SIZE="$(du -h "$IPA" | awk '{print $1}')"
echo | tee -a "$LOG"
echo "BUILD SUCCEEDED" | tee -a "$LOG"
echo "Created: $IPA ($SIZE)" | tee -a "$LOG"
echo "Use AltStore/AltServer or Sideloadly to sign and install it." | tee -a "$LOG"
open -R "$IPA" 2>/dev/null || true
exit 0
