import UIKit
import WebKit

/// Native host for the completely local BeatForge interface.
///
/// The project targets iOS/iPadOS 26 and uses the scene-based life cycle.
/// WKWebView handles HTML file inputs with the system document picker on iOS;
/// the macOS-only WKOpenPanelParameters API is intentionally not used here.
final class ViewController: UIViewController {
    private var webView: WKWebView!
    private let levelLibrary = BeatForgeLevelLibrary()
    private var downloadDestinations: [ObjectIdentifier: URL] = [:]

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    override func loadView() {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = [.audio]
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.websiteDataStore = .default()
        configuration.userContentController.add(levelLibrary, name: "beatforgeLibrary")

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 7/255, green: 11/255, blue: 16/255, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.keyboardDismissMode = .interactive
        webView.allowsBackForwardNavigationGestures = false

        #if DEBUG
        if #available(iOS 16.4, *) {
            webView.isInspectable = true
        }
        #endif

        self.webView = webView
        levelLibrary.attach(to: webView)
        self.view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(appDidBecomeActive), name: UIApplication.didBecomeActiveNotification, object: nil)
        loadBeatForge()
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "beatforgeLibrary")
    }

    @objc private func appDidBecomeActive() {
        levelLibrary.sendLibraryToWeb()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIApplication.shared.isIdleTimerDisabled = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    private func loadBeatForge() {
        guard let fileURL = Bundle.main.url(
            forResource: "beatforge_studio",
            withExtension: "html"
        ) else {
            showError(title: "BeatForge could not start", message: "The bundled HTML interface is missing.")
            return
        }

        let readAccessURL = fileURL.deletingLastPathComponent()
        webView.loadFileURL(fileURL, allowingReadAccessTo: readAccessURL)
    }

    private func showError(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func shareExportedFile(_ url: URL) {
        let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        share.completionWithItemsHandler = { _, _, _, _ in
            try? FileManager.default.removeItem(at: url)
        }
        if let popover = share.popoverPresentationController {
            popover.sourceView = view
            popover.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 40, width: 1, height: 1)
            popover.permittedArrowDirections = []
        }
        present(share, animated: true)
    }

    private func safeTemporaryURL(suggestedFilename: String) -> URL {
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|")
        let cleanName = suggestedFilename
            .components(separatedBy: invalid)
            .joined(separator: "-")
        let finalName = cleanName.lowercased().hasSuffix(".bforge") ? cleanName : cleanName + ".bforge"
        let folder = FileManager.default.temporaryDirectory
            .appendingPathComponent("BeatForgeExports", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let destination = folder.appendingPathComponent(finalName)
        try? FileManager.default.removeItem(at: destination)
        return destination
    }
}

extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        levelLibrary.sendLibraryToWeb()
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationResponse: WKNavigationResponse,
        decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void
    ) {
        let response = navigationResponse.response
        let isBeatForge = response.suggestedFilename?.lowercased().hasSuffix(".bforge") == true
            || response.mimeType == "application/octet-stream"
            || response.mimeType == "application/x-beatforge-level"

        decisionHandler(isBeatForge ? .download : .allow)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        let nsError = error as NSError
        if nsError.code != NSURLErrorCancelled {
            showError(title: "Page error", message: error.localizedDescription)
        }
    }
}

extension ViewController: WKDownloadDelegate {
    func download(
        _ download: WKDownload,
        decideDestinationUsing response: URLResponse,
        suggestedFilename: String,
        completionHandler: @escaping (URL?) -> Void
    ) {
        let filename = suggestedFilename.isEmpty ? "BeatForge-Level.bforge" : suggestedFilename
        let destination = safeTemporaryURL(suggestedFilename: filename)
        downloadDestinations[ObjectIdentifier(download)] = destination
        completionHandler(destination)
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let destination = downloadDestinations.removeValue(forKey: ObjectIdentifier(download)) else { return }
        DispatchQueue.main.async { [weak self] in
            self?.shareExportedFile(destination)
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloadDestinations.removeValue(forKey: ObjectIdentifier(download))
        DispatchQueue.main.async { [weak self] in
            self?.showError(title: "Export failed", message: error.localizedDescription)
        }
    }
}

// WKWebView provides the iOS document picker for <input type="file">.
// WKOpenPanelParameters is a macOS-only API and must not be implemented by an
// iOS target; doing so was the source of a compiler failure in the older build.
extension ViewController: WKUIDelegate {}
