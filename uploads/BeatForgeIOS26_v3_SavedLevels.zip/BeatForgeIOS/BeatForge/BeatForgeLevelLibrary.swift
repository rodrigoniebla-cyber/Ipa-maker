import Foundation
import WebKit

/// Persists editable BeatForge packages in the app's Documents/Saved Levels
/// directory. UIFileSharingEnabled exposes that directory in the Files app.
final class BeatForgeLevelLibrary: NSObject, WKScriptMessageHandler {
    weak var webView: WKWebView?

    private struct SaveSession {
        let handle: FileHandle
        let temporaryURL: URL
        let finalURL: URL
    }

    private var saveSessions: [String: SaveSession] = [:]
    private let fileManager = FileManager.default
    private let bridgeName = "beatforgeLibrary"
    private let chunkSize = 192 * 1024

    private var documentsURL: URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private var libraryURL: URL {
        let url = documentsURL.appendingPathComponent("Saved Levels", isDirectory: true)
        try? fileManager.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    func attach(to webView: WKWebView) {
        self.webView = webView
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == bridgeName,
              let body = message.body as? [String: Any],
              let action = body["action"] as? String else { return }

        switch action {
        case "list":
            sendLibraryToWeb()
        case "saveBegin":
            beginSave(body)
        case "saveChunk":
            appendSaveChunk(body)
        case "saveEnd":
            finishSave(body)
        case "open":
            if let filename = body["filename"] as? String { openLevel(filename: filename) }
        case "delete":
            if let filename = body["filename"] as? String { deleteLevel(filename: filename) }
        default:
            break
        }
    }

    func sendLibraryToWeb() {
        migrateLooseLevels()
        let files = (try? fileManager.contentsOfDirectory(
            at: libraryURL,
            includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        )) ?? []

        let items = files
            .filter { $0.pathExtension.lowercased() == "bforge" }
            .compactMap { self.levelSummary(at: $0) }
            .sorted { ($0["modifiedAt"] as? Double ?? 0) > ($1["modifiedAt"] as? Double ?? 0) }

        guard let json = jsonString(items) else { return }
        evaluate("window.BeatForgeNative && window.BeatForgeNative.receiveLibrary(\(json));")
    }

    private func migrateLooseLevels() {
        // Files may place a document at the app's top-level Documents directory.
        // Move those packages into the visible Saved Levels folder automatically.
        let loose = (try? fileManager.contentsOfDirectory(
            at: documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []

        for source in loose where source.pathExtension.lowercased() == "bforge" {
            let destination = libraryURL.appendingPathComponent(safeFilename(source.lastPathComponent))
            if source.standardizedFileURL == destination.standardizedFileURL { continue }
            if fileManager.fileExists(atPath: destination.path) { try? fileManager.removeItem(at: destination) }
            try? fileManager.moveItem(at: source, to: destination)
        }
    }

    private func beginSave(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let requestedName = body["filename"] as? String else { return }

        if let old = saveSessions.removeValue(forKey: id) {
            try? old.handle.close()
            try? fileManager.removeItem(at: old.temporaryURL)
        }

        let filename = safeFilename(requestedName)
        let finalURL = libraryURL.appendingPathComponent(filename)
        let temporaryURL = libraryURL.appendingPathComponent(".incoming-\(UUID().uuidString)")
        _ = fileManager.createFile(atPath: temporaryURL.path, contents: nil)

        do {
            let handle = try FileHandle(forWritingTo: temporaryURL)
            saveSessions[id] = SaveSession(handle: handle, temporaryURL: temporaryURL, finalURL: finalURL)
        } catch {
            sendSaveFailure(id: id, message: error.localizedDescription)
        }
    }

    private func appendSaveChunk(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let encoded = body["data"] as? String,
              let data = Data(base64Encoded: encoded),
              let session = saveSessions[id] else { return }

        do {
            try session.handle.write(contentsOf: data)
        } catch {
            cancelSave(id: id, message: error.localizedDescription)
        }
    }

    private func finishSave(_ body: [String: Any]) {
        guard let id = body["id"] as? String,
              let session = saveSessions.removeValue(forKey: id) else { return }
        try? session.handle.close()

        guard isBeatForgeFile(session.temporaryURL) else {
            try? fileManager.removeItem(at: session.temporaryURL)
            sendSaveFailure(id: id, message: "The completed file is not a valid .bforge package.")
            return
        }

        do {
            if fileManager.fileExists(atPath: session.finalURL.path) {
                try fileManager.removeItem(at: session.finalURL)
            }
            try fileManager.moveItem(at: session.temporaryURL, to: session.finalURL)
            let result: [String: Any] = ["id": id, "filename": session.finalURL.lastPathComponent]
            if let json = jsonString(result) {
                evaluate("window.BeatForgeNative && window.BeatForgeNative.onSaved(\(json));")
            }
            sendLibraryToWeb()
        } catch {
            try? fileManager.removeItem(at: session.temporaryURL)
            sendSaveFailure(id: id, message: error.localizedDescription)
        }
    }

    private func cancelSave(id: String, message: String) {
        if let session = saveSessions.removeValue(forKey: id) {
            try? session.handle.close()
            try? fileManager.removeItem(at: session.temporaryURL)
        }
        sendSaveFailure(id: id, message: message)
    }

    private func sendSaveFailure(id: String, message: String) {
        let result: [String: Any] = ["id": id, "message": message]
        if let json = jsonString(result) {
            evaluate("window.BeatForgeNative && window.BeatForgeNative.onSaveFailed(\(json));")
        }
    }

    private func openLevel(filename: String) {
        let cleanName = safeFilename(filename)
        let url = libraryURL.appendingPathComponent(cleanName)
        guard url.deletingLastPathComponent().standardizedFileURL == libraryURL.standardizedFileURL,
              isBeatForgeFile(url) else {
            sendOpenFailure("The selected saved level is missing or invalid.")
            return
        }

        do {
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])
            let transferID = "open-\(UUID().uuidString)"
            let totalChunks = max(1, Int(ceil(Double(data.count) / Double(chunkSize))))
            guard let idJSON = jsonString(transferID),
                  let nameJSON = jsonString(cleanName) else { return }
            let begin = "window.BeatForgeNative && window.BeatForgeNative.receiveOpenBegin(\(idJSON),\(nameJSON),\(totalChunks),\(data.count));"
            webView?.evaluateJavaScript(begin) { [weak self] _, error in
                if let error { self?.sendOpenFailure(error.localizedDescription); return }
                self?.sendOpenChunk(data: data, transferID: transferID, index: 0, totalChunks: totalChunks)
            }
        } catch {
            sendOpenFailure(error.localizedDescription)
        }
    }

    private func sendOpenChunk(data: Data, transferID: String, index: Int, totalChunks: Int) {
        if index >= totalChunks {
            guard let idJSON = jsonString(transferID) else { return }
            evaluate("window.BeatForgeNative && window.BeatForgeNative.receiveOpenEnd(\(idJSON));")
            return
        }

        let start = index * chunkSize
        let end = min(data.count, start + chunkSize)
        let encoded = data.subdata(in: start..<end).base64EncodedString()
        guard let idJSON = jsonString(transferID),
              let dataJSON = jsonString(encoded) else { return }
        let script = "window.BeatForgeNative && window.BeatForgeNative.receiveOpenChunk(\(idJSON),\(index),\(dataJSON));"
        webView?.evaluateJavaScript(script) { [weak self] _, error in
            if let error { self?.sendOpenFailure(error.localizedDescription); return }
            self?.sendOpenChunk(data: data, transferID: transferID, index: index + 1, totalChunks: totalChunks)
        }
    }

    private func sendOpenFailure(_ message: String) {
        guard let value = jsonString(message) else { return }
        evaluate("window.BeatForgeNative && window.BeatForgeNative.onOpenFailed(\(value));")
    }

    private func deleteLevel(filename: String) {
        let cleanName = safeFilename(filename)
        let url = libraryURL.appendingPathComponent(cleanName)
        guard url.deletingLastPathComponent().standardizedFileURL == libraryURL.standardizedFileURL else { return }
        try? fileManager.removeItem(at: url)
        if let value = jsonString(cleanName) {
            evaluate("window.BeatForgeNative && window.BeatForgeNative.onDeleted(\(value));")
        }
        sendLibraryToWeb()
    }

    private func levelSummary(at url: URL) -> [String: Any]? {
        guard let metadata = readMetadata(at: url),
              let level = metadata["level"] as? [String: Any],
              let chart = metadata["chart"] as? [String: Any],
              let audio = metadata["audio"] as? [String: Any] else { return nil }

        let notes = ((chart["notes"] as? [NSNumber])?.map(\.doubleValue) ?? []).sorted()
        let average = (chart["averageGapMs"] as? NSNumber)?.doubleValue ?? averageGap(milliseconds: notes)
        let difficulty = (chart["difficulty"] as? String)
            ?? (level["difficulty"] as? String)
            ?? difficultyForGap(average)
        let values = try? url.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])

        return [
            "filename": url.lastPathComponent,
            "title": level["title"] as? String ?? url.deletingPathExtension().lastPathComponent,
            "artist": level["artist"] as? String ?? "",
            "difficulty": difficulty,
            "averageGapMs": average ?? NSNull(),
            "noteCount": notes.count,
            "duration": (audio["duration"] as? NSNumber)?.doubleValue ?? 0,
            "size": values?.fileSize ?? 0,
            "modifiedAt": (values?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000
        ]
    }

    private func readMetadata(at url: URL) -> [String: Any]? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        do {
            guard let header = try handle.read(upToCount: 12),
                  header.count == 12,
                  String(data: header.prefix(8), encoding: .utf8) == "BFORGE1\n" else { return nil }

            let lengthBytes = Array(header.suffix(4))
            let metadataLength = Int(lengthBytes[0]) | (Int(lengthBytes[1]) << 8) | (Int(lengthBytes[2]) << 16) | (Int(lengthBytes[3]) << 24)
            guard metadataLength > 1, metadataLength < 16 * 1024 * 1024,
                  let metadataData = try handle.read(upToCount: metadataLength),
                  metadataData.count == metadataLength,
                  let object = try JSONSerialization.jsonObject(with: metadataData) as? [String: Any] else { return nil }
            return object
        } catch {
            return nil
        }
    }

    private func isBeatForgeFile(_ url: URL) -> Bool {
        guard fileManager.fileExists(atPath: url.path),
              let handle = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? handle.close() }
        do {
            guard let data = try handle.read(upToCount: 8) else { return false }
            return String(data: data, encoding: .utf8) == "BFORGE1\n"
        } catch {
            return false
        }
    }

    private func averageGap(milliseconds: [Double]) -> Double? {
        guard milliseconds.count > 1 else { return nil }
        var total = 0.0
        for index in 1..<milliseconds.count { total += max(0, milliseconds[index] - milliseconds[index - 1]) }
        return total / Double(milliseconds.count - 1)
    }

    private func difficultyForGap(_ gap: Double?) -> String {
        guard let gap else { return "Easy" }
        if gap >= 450 { return "Easy" }
        if gap >= 300 { return "Medium" }
        if gap > 120 { return "Hard" }
        return "Insane"
    }

    private func safeFilename(_ requested: String) -> String {
        let last = URL(fileURLWithPath: requested).lastPathComponent
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|")
        var clean = last.components(separatedBy: invalid).joined(separator: "-")
        clean = clean.trimmingCharacters(in: .whitespacesAndNewlines)
        if clean.isEmpty { clean = "BeatForge-Level" }
        if clean.lowercased().hasSuffix(".bforge") { clean = String(clean.dropLast(7)) }
        clean = String(clean.prefix(112)).trimmingCharacters(in: .whitespacesAndNewlines)
        return (clean.isEmpty ? "BeatForge-Level" : clean) + ".bforge"
    }

    private func jsonString(_ value: Any) -> String? {
        guard JSONSerialization.isValidJSONObject(value),
              let data = try? JSONSerialization.data(withJSONObject: value),
              let string = String(data: data, encoding: .utf8) else { return nil }
        return string
    }

    private func jsonString(_ value: String) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
              let string = String(data: data, encoding: .utf8) else { return nil }
        return string
    }

    private func evaluate(_ script: String) {
        DispatchQueue.main.async { [weak self] in
            self?.webView?.evaluateJavaScript(script)
        }
    }
}
