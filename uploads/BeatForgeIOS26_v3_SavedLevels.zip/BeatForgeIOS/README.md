# BeatForge for iOS 26+

BeatForge 3.0 is a native iPhone/iPad wrapper around the fully local rhythm editor. It targets **iOS/iPadOS 26.0 or newer** and must be built with **Xcode 26 or newer**.

The complete game is bundled in `BeatForge/Resources/beatforge_studio.html`. Music editing, rhythm mapping, gameplay, and `.bforge` project handling remain local to the device.

## iOS 26 corrections in this version

- The deprecated `UIRequiresFullScreen` property was removed completely from the app's Info.plist.
- All four interface orientations are declared for both iPhone and iPad.
- The responsive interface supports iPad multitasking, resizable windows, Stage Manager, and iPadOS 26 windowing.
- The app uses the scene-based UIKit life cycle and `UIWindow(windowScene:)`.
- The minimum deployment target is iOS 26.0.
- The old wrapper incorrectly implemented `WKOpenPanelParameters`, which is a macOS open-panel API. That implementation was removed from the iOS target. WKWebView uses iOS's built-in picker for HTML file inputs.
- The build script now checks the selected Xcode and SDK, writes a complete build log, and packages only after Xcode reports a successful device build.

## BeatForge 3.0 features

- The app creates `On My iPhone/iPad › BeatForge › Saved Levels` and stores completed `.bforge` exports there.
- Files copied into that folder appear automatically under **Saved Levels** in the app.
- Loose `.bforge` files placed in BeatForge's top-level Files folder are moved into Saved Levels automatically.
- Saved levels can be opened or deleted from the in-app library.
- Editor playback supports 1×, 0.5×, and 0.25× speeds without changing mapped song timestamps.
- Difficulty is calculated from average note spacing: Easy ≥450ms, Medium 300–449ms, Hard 121–299ms, and Insane ≤120ms.
- Difficulty and average gap are embedded in every newly saved `.bforge` file.

## Included behavior

- Touch input is enabled automatically on iPhone and iPad.
- The mapper includes a large touchscreen note pad and a Touch Input On/Off control.
- Play mode accepts touchscreen taps or a hardware-keyboard spacebar.
- HTML file inputs invoke the iOS picker for music and `.bforge` projects.
- `.bforge` exports invoke a native iOS share/save sheet.
- The app supports notches, the Home indicator, rotation, split-screen layouts, and dynamic window resizing.
- A complete universal iPhone/iPad app-icon set is included.

## Create an unsigned IPA for AltStore or Sideloadly

1. Install **Xcode 26 or newer** on a Mac.
2. Open Xcode once so it can install its required components.
3. Extract this ZIP.
4. Double-click `make_unsigned_ipa.command`.
5. After a successful build, use `BeatForge-iOS26-v3-unsigned.ipa` with AltStore, AltServer, or Sideloadly.

The script creates `BeatForge-build.log`. If Xcode returns a nonzero status, the script opens that log instead of hiding the underlying compiler message.

## Build and run directly in Xcode

1. Open `BeatForge.xcodeproj` in Xcode 26+.
2. Select the **BeatForge** target.
3. Open **Signing & Capabilities**.
4. Select your Apple development team.
5. If required, replace the bundle identifier `ai.arena.beatforge` with your own unique identifier.
6. Connect and trust an iPhone or iPad running iOS/iPadOS 26+.
7. Select that device and press **Run**.

## Fix for the AppIcon code-signing failure

Version 3.0 retains the fix for the reported `code object is not signed at all` failure involving `AppIcon60x60@2x.png` in three ways:

1. The HTML is now copied as one normal resource instead of embedding a blue `Resources` folder in the application bundle.
2. A final Xcode build phase removes extended attributes from the built app and normalizes PNG/HTML permissions before Xcode signs it.
3. `fix_codesign.command` removes downloaded-file metadata and deletes only BeatForge's contaminated Derived Data.

After replacing the old project with this one, double-click `fix_codesign.command` once. Then open Xcode, choose **Product > Clean Build Folder**, and Archive again. Do not merge the corrected project into the old folder; extract it into a fresh directory.

## If Xcode itself returns exit 65

Exit 65 is a general Xcode failure status, not a specific BeatForge error. Check `BeatForge-build.log` for the first line containing `error:`. Common environment fixes are:

```bash
sudo xcode-select -s /Applications/Xcode.app
sudo xcodebuild -license accept
xcodebuild -runFirstLaunch
```

Then remove `.build-ios26` and run `make_unsigned_ipa.command` again. The script already removes that directory at the beginning of each build.

## Privacy

The wrapper contains no analytics, advertisements, cloud storage, or added network requests. Selected audio and pattern data stay in the application until you explicitly share an exported `.bforge` file.
