#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "Preparing BeatForge resources for Xcode code signing..."

# Downloads and ZIP extraction can attach quarantine/Finder metadata to PNGs.
# Apple code signing rejects those attributes when they reach the .app bundle.
/usr/bin/xattr -cr "$ROOT" 2>/dev/null || true
/usr/bin/find "$ROOT/BeatForge/Assets.xcassets" -type f -name '*.png' -exec /bin/chmod 0644 {} +
/usr/bin/find "$ROOT/BeatForge/Resources" -type f -exec /bin/chmod 0644 {} +

# Remove only BeatForge's cached products, including the previously contaminated
# AppIcon60x60@2x.png that appeared in the reported archive failure.
/usr/bin/find "$HOME/Library/Developer/Xcode/DerivedData" -maxdepth 1 -type d -name 'BeatForge-*' -exec /bin/rm -rf {} + 2>/dev/null || true

rm -rf "$ROOT/.build-ios26" "$ROOT/Payload"

echo "Done. Reopen BeatForge.xcodeproj, choose Product > Clean Build Folder, and Archive again."
read -r -p "Press Return to close..."
