#!/bin/bash
# Invoked automatically by Xcode. No Terminal setup is required.
set -euo pipefail
export PATH="$HOME/.cargo/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
ROOT="${SRCROOT:-$(cd "$(dirname "$0")" && pwd)}"

if ! command -v cargo >/dev/null 2>&1 || ! command -v rustup >/dev/null 2>&1; then
  echo "Installing the minimal Rust toolchain required by iOS 27 pairing…"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
  export PATH="$HOME/.cargo/bin:$PATH"
fi

case "${PLATFORM_NAME:-iphoneos}" in
  iphoneos) RUST_TARGET="aarch64-apple-ios" ;;
  iphonesimulator) RUST_TARGET="aarch64-apple-ios-sim" ;;
  *) echo "Unsupported platform: ${PLATFORM_NAME:-unknown}" >&2; exit 1 ;;
esac

rustup target add "$RUST_TARGET"
cd "$ROOT/PairingFFI/rust"
cargo build --release --locked --target "$RUST_TARGET"
mkdir -p "$ROOT/Generated/${PLATFORM_NAME}"
cp "target/$RUST_TARGET/release/libstikpair_ffi.a" "$ROOT/Generated/${PLATFORM_NAME}/libstikpair_ffi.a"
