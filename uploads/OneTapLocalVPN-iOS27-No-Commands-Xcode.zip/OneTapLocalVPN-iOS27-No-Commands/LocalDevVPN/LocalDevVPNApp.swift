import SwiftUI

@main
struct LocalDevVPNApp: App {
    init() {
        PairingController.shared.registerBackgroundTask()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
