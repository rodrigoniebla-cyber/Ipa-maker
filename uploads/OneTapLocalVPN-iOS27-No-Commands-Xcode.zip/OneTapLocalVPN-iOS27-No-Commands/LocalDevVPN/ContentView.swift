//
//  ContentView.swift
//  LocalDevVPN
//
//  Created by Stossy11 on 28/03/2025.
//

import Foundation
import NetworkExtension
import SwiftUI
import UIKit


extension Bundle {
    var shortVersion: String { object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "0.0.0" }
    var tunnelBundleID: String { bundleIdentifier!.appending(".TunnelProv") }
}

// MARK: - Logging Utility

class VPNLogger: ObservableObject {
    @Published var logs: [String] = []

    static var shared = VPNLogger()

    private init() {}

    func log(_ message: Any, file: String = #file, function: String = #function, line: Int = #line) {
        #if DEBUG
            let fileName = (file as NSString).lastPathComponent
            print("[\(fileName):\(line)] \(function): \(message)")
        #endif

        logs.append("\(message)")
    }
}

// MARK: - Tunnel Manager

struct TunnelAddresses {
    let interfaceIP: String
    let peerIP: String
}

class TunnelManager: ObservableObject {
    @Published var hasLocalDeviceSupport = false
    @Published var tunnelStatus: TunnelStatus = .disconnected

    static var shared = TunnelManager()

    @Published var waitingOnSettings: Bool = false
    @Published var vpnManager: NETunnelProviderManager?
    private var vpnObserver: NSObjectProtocol?
    private var isProcessingStatusChange = false
    private var pendingStartAddresses: TunnelAddresses?
    private let isSimulator: Bool = {
        #if targetEnvironment(simulator)
            return true
        #else
            return false
        #endif
    }()

    private var tunnelIfaceIP: String {
        UserDefaults.standard.string(forKey: "TunnelIfaceIP") ?? TunnelConstants.defaultIfaceIP
    }

    private var tunnelPeerIP: String {
        UserDefaults.standard.string(forKey: "TunnelPeerIP") ?? TunnelConstants.defaultPeerIP
    }

    var configuredAddresses: TunnelAddresses {
        TunnelAddresses(interfaceIP: tunnelIfaceIP, peerIP: tunnelPeerIP)
    }

    private var tunnelBundleId: String {
        Bundle.main.bundleIdentifier!.appending(".TunnelProv")
    }

    private func persistTunnelAddresses(in manager: NETunnelProviderManager) -> Bool {
        guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol else {
            VPNLogger.shared.log("Cannot persist tunnel addresses: invalid protocol configuration")
            return false
        }

        var providerConfiguration = proto.providerConfiguration ?? [:]
        providerConfiguration[TunnelConstants.ifaceIPConfigurationKey] = tunnelIfaceIP
        providerConfiguration[TunnelConstants.peerIPConfigurationKey] = tunnelPeerIP
        proto.providerConfiguration = providerConfiguration
        manager.protocolConfiguration = proto
        return true
    }

    enum TunnelStatus: Equatable {
        case disconnected
        case connecting
        case connected
        case disconnecting
        case error

        var color: Color {
            switch self {
            case .disconnected: return .gray
            case .connecting: return .orange
            case .connected: return .green
            case .disconnecting: return .orange
            case .error: return .red
            }
        }

        var systemImage: String {
            switch self {
            case .disconnected: return "network.slash"
            case .connecting: return "network.badge.shield.half.filled"
            case .connected: return "checkmark.shield.fill"
            case .disconnecting: return "network.badge.shield.half.filled"
            case .error: return "exclamationmark.shield.fill"
            }
        }

        var localizedTitle: LocalizedStringKey {
            switch self {
            case .disconnected:
                return "disconnected"
            case .connecting:
                return "connecting"
            case .connected:
                return "connected"
            case .disconnecting:
                return "disconnecting"
            case .error:
                return "error"
            }
        }
    }

    private init() {
        if isSimulator {
        loadTunnelPreferences()
            VPNLogger.shared.log("Running on Simulator – VPN calls are mocked")
            DispatchQueue.main.async { [weak self] in
                self?.waitingOnSettings = true
            }
        } else {
            setupStatusObserver()
            loadTunnelPreferences()
        }
    }

    // MARK: - Private Methods

    private func loadTunnelPreferences() {
        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, error in
            guard let self = self else { return }

            DispatchQueue.main.async {
                if let error = error {
                    VPNLogger.shared.log("Error loading preferences: \(error.localizedDescription)")
                    self.tunnelStatus = .error
                    self.waitingOnSettings = true
                    return
                }

                self.hasLocalDeviceSupport = true
                self.waitingOnSettings = true

                if let managers = managers, !managers.isEmpty {
                    let stosManagers = managers.filter { manager in
                        guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol else {
                            return false
                        }
                        return proto.providerBundleIdentifier == self.tunnelBundleId
                    }

                    if !stosManagers.isEmpty {
                        if stosManagers.count > 1 {
                            self.cleanupDuplicateManagers(stosManagers)
                        } else if let manager = stosManagers.first {
                            self.vpnManager = manager
                            let currentStatus = manager.connection.status
                            VPNLogger.shared.log("Loaded existing LocalDevVPN tunnel configuration with status: \(currentStatus.rawValue)")
                            self.updateTunnelStatus(from: currentStatus)
                        }
                    } else {
                        VPNLogger.shared.log("No LocalDevVPN tunnel configuration found")
                    }
                } else {
                    VPNLogger.shared.log("No existing tunnel configurations found")
                }
            }
        }
    }

    private func cleanupDuplicateManagers(_ managers: [NETunnelProviderManager]) {
        VPNLogger.shared.log("Found \(managers.count) LocalDevVPN configurations. Cleaning up duplicates...")

        let activeManager = managers.first {
            $0.connection.status == .connected || $0.connection.status == .connecting
        }

        let managerToKeep = activeManager ?? managers.first!

        DispatchQueue.main.async { [weak self] in
            self?.vpnManager = managerToKeep
            self?.updateTunnelStatus(from: managerToKeep.connection.status)
        }

        for manager in managers where manager != managerToKeep {
            manager.removeFromPreferences { error in
                if let error = error {
                    VPNLogger.shared.log("Error removing duplicate VPN: \(error.localizedDescription)")
                } else {
                    VPNLogger.shared.log("Successfully removed duplicate VPN configuration")
                }
            }
        }
    }

    private func setupStatusObserver() {
        vpnObserver = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self else { return }
            guard let connection = notification.object as? NEVPNConnection else { return }

            VPNLogger.shared.log("VPN Status notification received: \(connection.status.rawValue)")

            // Update status immediately if it's our manager
            if let manager = self.vpnManager, connection == manager.connection {
                self.updateTunnelStatus(from: connection.status)
            }

            self.handleVPNStatusChange(notification: notification)
        }
    }

    private func updateTunnelStatus(from connectionStatus: NEVPNStatus) {
        let newStatus: TunnelStatus
        switch connectionStatus {
        case .invalid, .disconnected:
            newStatus = .disconnected
        case .connecting:
            newStatus = .connecting
        case .connected:
            newStatus = .connected
        case .disconnecting:
            newStatus = .disconnecting
        case .reasserting:
            newStatus = .connecting
        @unknown default:
            newStatus = .error
        }

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            if self.tunnelStatus != newStatus {
                VPNLogger.shared.log("LocalDevVPN status updated from \(self.tunnelStatus) to \(newStatus)")
            }
            self.tunnelStatus = newStatus
        }
    }

    private func createLocalDevVPNConfiguration(completion: @escaping (NETunnelProviderManager?) -> Void) {
        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, error in
            guard let self = self else {
                completion(nil)
                return
            }

            if let error = error {
                VPNLogger.shared.log("Error checking existing VPN configurations: \(error.localizedDescription)")
                completion(nil)
                return
            }

            if let managers = managers {
                let stosManagers = managers.filter { manager in
                    guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol else {
                        return false
                    }
                    return proto.providerBundleIdentifier == self.tunnelBundleId
                }

                if let existingManager = stosManagers.first {
                    VPNLogger.shared.log("Found existing LocalDevVPN configuration, using it instead of creating new one")
                    completion(existingManager)
                    return
                }
            }

            let manager = NETunnelProviderManager()
            manager.localizedDescription = "OneTap Local VPN"

            let proto = NETunnelProviderProtocol()
            proto.providerBundleIdentifier = self.tunnelBundleId
            proto.serverAddress = "On-device local network tunnel"
            proto.providerConfiguration = [
                TunnelConstants.ifaceIPConfigurationKey: self.tunnelIfaceIP,
                TunnelConstants.peerIPConfigurationKey: self.tunnelPeerIP,
            ]
            manager.protocolConfiguration = proto

            let onDemandRule = NEOnDemandRuleEvaluateConnection()
            onDemandRule.interfaceTypeMatch = .any
            onDemandRule.connectionRules = [NEEvaluateConnectionRule(
                matchDomains: [self.tunnelIfaceIP, self.tunnelPeerIP],
                andAction: .connectIfNeeded
            )]

            manager.onDemandRules = [onDemandRule]
            manager.isOnDemandEnabled = true
            manager.isEnabled = true

            manager.saveToPreferences { error in
                DispatchQueue.main.async {
                    if let error = error {
                        VPNLogger.shared.log("Error creating LocalDevVPN configuration: \(error.localizedDescription)")
                        completion(nil)
                        return
                    }

                    VPNLogger.shared.log("LocalDevVPN configuration created successfully")
                    completion(manager)
                }
            }
        }
    }

    private func getActiveVPNManager(completion: @escaping (NETunnelProviderManager?) -> Void) {
        NETunnelProviderManager.loadAllFromPreferences { managers, error in
            if let error = error {
                VPNLogger.shared.log("Error loading VPN configurations: \(error.localizedDescription)")
                completion(nil)
                return
            }

            guard let managers = managers else {
                completion(nil)
                return
            }

            let activeManager = managers.first { manager in
                manager.connection.status == .connected || manager.connection.status == .connecting
            }

            completion(activeManager)
        }
    }

    // MARK: - Public Methods

    func toggleVPNConnection() {
        if tunnelStatus == .connected || tunnelStatus == .connecting {
            stopVPN()
        } else {
            startVPN()
        }
    }

    @MainActor
    func isVPNActive() async throws -> Bool {
        if isSimulator {
            return tunnelStatus == .connected || tunnelStatus == .connecting
        }

        let managers = try await NETunnelProviderManager.loadAllFromPreferences()
        let localManagers = managers.filter { manager in
            let proto = manager.protocolConfiguration as? NETunnelProviderProtocol
            return proto?.providerBundleIdentifier == tunnelBundleId
        }
        let manager = localManagers.first { manager in
            let status = manager.connection.status
            return status == .connected || status == .connecting || status == .reasserting
        } ?? localManagers.first

        vpnManager = manager
        guard let manager = manager else {
            tunnelStatus = .disconnected
            return false
        }

        updateTunnelStatus(from: manager.connection.status)
        let status = manager.connection.status
        return status == .connected || status == .connecting || status == .reasserting
    }

    func startVPN(temporaryAddresses: TunnelAddresses? = nil) {
        if isSimulator {
            simulateStartVPN()
            return
        }

        if let manager = vpnManager {
            let currentStatus = manager.connection.status
            VPNLogger.shared.log("Current manager status: \(currentStatus.rawValue)")

            if currentStatus == .connected {
                VPNLogger.shared.log("VPN already connected, updating UI")
                DispatchQueue.main.async { [weak self] in
                    self?.tunnelStatus = .connected
                }
                return
            }

            if currentStatus == .connecting {
                VPNLogger.shared.log("VPN already connecting, updating UI")
                DispatchQueue.main.async { [weak self] in
                    self?.tunnelStatus = .connecting
                }
                return
            }
        }

        getActiveVPNManager { [weak self] activeManager in
            guard let self = self else { return }

            if let activeManager = activeManager,
               (activeManager.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier != self.tunnelBundleId
            {
                VPNLogger.shared.log("Disconnecting existing VPN connection before starting LocalDevVPN")

                self.pendingStartAddresses = temporaryAddresses
                UserDefaults.standard.set(true, forKey: "ShouldStartLocalDevVPNAfterDisconnect")
                activeManager.connection.stopVPNTunnel()
                return
            }

            self.initializeAndStartLocalDevVPN(temporaryAddresses: temporaryAddresses)
        }
    }

    private func initializeAndStartLocalDevVPN(temporaryAddresses: TunnelAddresses?) {
        if let manager = vpnManager {
            manager.loadFromPreferences { [weak self] error in
                guard let self = self else { return }

                if let error = error {
                    VPNLogger.shared.log("Error reloading manager: \(error.localizedDescription)")
                    self.createAndStartVPN(temporaryAddresses: temporaryAddresses)
                    return
                }

                self.startExistingVPN(manager: manager, temporaryAddresses: temporaryAddresses)
            }
        } else {
            createAndStartVPN(temporaryAddresses: temporaryAddresses)
        }
    }

    private func createAndStartVPN(temporaryAddresses: TunnelAddresses?) {
        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, error in
            guard let self = self else { return }

            if let error = error {
                VPNLogger.shared.log("Error reloading VPN configurations: \(error.localizedDescription)")
            }

            if let managers = managers {
                let stosManagers = managers.filter { manager in
                    guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol else {
                        return false
                    }
                    return proto.providerBundleIdentifier == self.tunnelBundleId
                }

                if !stosManagers.isEmpty {
                    DispatchQueue.main.async { [weak self] in
                        self?.vpnManager = stosManagers.first
                    }

                    if stosManagers.count > 1 {
                        self.cleanupDuplicateManagers(stosManagers)
                    }

                    if let manager = stosManagers.first {
                        self.startExistingVPN(manager: manager, temporaryAddresses: temporaryAddresses)
                    }
                    return
                }
            }

            self.createLocalDevVPNConfiguration { [weak self] manager in
                guard let self = self, let manager = manager else { return }
                DispatchQueue.main.async { [weak self] in
                    self?.vpnManager = manager
                }
                self.startExistingVPN(manager: manager, temporaryAddresses: temporaryAddresses)
            }
        }
    }

    private func startExistingVPN(
        manager: NETunnelProviderManager,
        temporaryAddresses: TunnelAddresses?
    ) {
        // First check the actual current status
        let currentStatus = manager.connection.status
        VPNLogger.shared.log("Current VPN status before start attempt: \(currentStatus.rawValue)")

        if currentStatus == .connected {
            VPNLogger.shared.log("LocalDevVPN tunnel is already connected")
            DispatchQueue.main.async { [weak self] in
                self?.tunnelStatus = .connected
            }
            return
        }

        if currentStatus == .connecting {
            VPNLogger.shared.log("LocalDevVPN tunnel is already connecting")
            DispatchQueue.main.async { [weak self] in
                self?.tunnelStatus = .connecting
            }
            return
        }

        manager.isEnabled = true
        manager.saveToPreferences { [weak self] error in
            guard let self = self else { return }

            if let error = error {
                VPNLogger.shared.log("Error saving preferences: \(error.localizedDescription)")
                DispatchQueue.main.async { [weak self] in
                    self?.tunnelStatus = .error
                }
                return
            }

            manager.loadFromPreferences { [weak self] error in
                guard let self = self else { return }

                if let error = error {
                    VPNLogger.shared.log("Error reloading preferences: \(error.localizedDescription)")
                    DispatchQueue.main.async { [weak self] in
                        self?.tunnelStatus = .error
                    }
                    return
                }

                // Check status again after reload
                let statusAfterReload = manager.connection.status
                VPNLogger.shared.log("VPN status after reload: \(statusAfterReload.rawValue)")

                if statusAfterReload == .connected {
                    VPNLogger.shared.log("VPN is already connected after reload")
                    DispatchQueue.main.async { [weak self] in
                        self?.tunnelStatus = .connected
                    }
                    return
                }

                DispatchQueue.main.async { [weak self] in
                    self?.tunnelStatus = .connecting
                }

                let addresses = temporaryAddresses ?? self.configuredAddresses
                let options: [String: NSObject] = [
                    TunnelConstants.ifaceIPConfigurationKey: addresses.interfaceIP as NSObject,
                    TunnelConstants.peerIPConfigurationKey: addresses.peerIP as NSObject,
                ]

                do {
                    try manager.connection.startVPNTunnel(options: options)
                    VPNLogger.shared.log("LocalDevVPN tunnel start initiated")
                } catch {
                    DispatchQueue.main.async { [weak self] in
                        self?.tunnelStatus = .error
                    }
                    VPNLogger.shared.log("Failed to start LocalDevVPN tunnel: \(error.localizedDescription)")
                }
            }
        }
    }

    func stopVPN() {
        pendingStartAddresses = nil
        UserDefaults.standard.removeObject(forKey: "ShouldStartLocalDevVPNAfterDisconnect")

        if isSimulator {
            simulateStopVPN()
            return
        }

        guard let manager = vpnManager else {
            VPNLogger.shared.log("No VPN manager available to stop")
            return
        }

        DispatchQueue.main.async { [weak self] in
            self?.tunnelStatus = .disconnecting
        }

        manager.connection.stopVPNTunnel()
        VPNLogger.shared.log("LocalDevVPN tunnel stop initiated")
    }

    func updateConfigAndRestart(shouldRestart: Bool) {
        if isSimulator { return }
        
        guard let manager = vpnManager else { return }
        
        manager.loadFromPreferences { [weak self] error in
            guard let self = self else { return }
            if let error = error {
                VPNLogger.shared.log("Error loading preferences for update: \(error.localizedDescription)")
                return
            }

            guard self.persistTunnelAddresses(in: manager) else { return }
            
            let onDemandRule = NEOnDemandRuleEvaluateConnection()
            onDemandRule.interfaceTypeMatch = .any
            onDemandRule.connectionRules = [NEEvaluateConnectionRule(
                matchDomains: [self.tunnelIfaceIP, self.tunnelPeerIP],
                andAction: .connectIfNeeded
            )]
            manager.onDemandRules = [onDemandRule]
            manager.isOnDemandEnabled = true
            manager.isEnabled = true
            
            manager.saveToPreferences { [weak self] error in
                guard self != nil else { return }
                if let error = error {
                    VPNLogger.shared.log("Error saving updated preferences: \(error.localizedDescription)")
                    return
                }
                
                VPNLogger.shared.log("LocalDevVPN configuration updated successfully in preferences")
                
                if shouldRestart {
                    VPNLogger.shared.log("Restarting LocalDevVPN tunnel to apply new configuration...")
                    self?.pendingStartAddresses = nil
                    UserDefaults.standard.set(true, forKey: "ShouldStartLocalDevVPNAfterDisconnect")
                    manager.connection.stopVPNTunnel()
                }
            }
        }
    }

    func handleVPNStatusChange(notification: Notification) {
        guard let connection = notification.object as? NEVPNConnection else { return }

        VPNLogger.shared.log("Handling VPN status change: \(connection.status.rawValue)")

        // Always update status if it's our manager's connection
        if let manager = vpnManager, connection == manager.connection {
            VPNLogger.shared.log("Status change is for our LocalDevVPN manager")
            updateTunnelStatus(from: connection.status)
        }

        if connection.status == .disconnected &&
            UserDefaults.standard.bool(forKey: "ShouldStartLocalDevVPNAfterDisconnect")
        {
            UserDefaults.standard.removeObject(forKey: "ShouldStartLocalDevVPNAfterDisconnect")
            let temporaryAddresses = pendingStartAddresses
            pendingStartAddresses = nil

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                self?.initializeAndStartLocalDevVPN(temporaryAddresses: temporaryAddresses)
            }
            return
        }

        // Prevent recursive calls when checking for duplicates
        guard !isProcessingStatusChange else { return }
        isProcessingStatusChange = true

        // Check for duplicates asynchronously without blocking
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else { return }

            NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, _ in
                guard let self = self, let managers = managers, !managers.isEmpty else {
                    DispatchQueue.main.async { [weak self] in
                        self?.isProcessingStatusChange = false
                    }
                    return
                }

                let stosManagers = managers.filter { manager in
                    guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol else {
                        return false
                    }
                    return proto.providerBundleIdentifier == self.tunnelBundleId
                }

                if stosManagers.count > 1 {
                    DispatchQueue.main.async { [weak self] in
                        self?.cleanupDuplicateManagers(stosManagers)
                    }
                }

                DispatchQueue.main.async { [weak self] in
                    self?.isProcessingStatusChange = false
                }
            }
        }
    }

    // MARK: - Cleanup Utilities

    func cleanupAllVPNConfigurations() {
        if isSimulator {
            VPNLogger.shared.log("Simulator cleanup skipped – no real VPN configurations to remove")
            return
        }

        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, error in
            guard let self = self else { return }

            if let error = error {
                VPNLogger.shared.log("Error loading VPN configurations for cleanup: \(error.localizedDescription)")
                return
            }

            guard let managers = managers else { return }

            for manager in managers {
                guard let proto = manager.protocolConfiguration as? NETunnelProviderProtocol,
                      proto.providerBundleIdentifier == self.tunnelBundleId
                else {
                    continue
                }

                if manager.connection.status == .connected || manager.connection.status == .connecting {
                    manager.connection.stopVPNTunnel()
                }

                manager.removeFromPreferences { error in
                    if let error = error {
                        VPNLogger.shared.log("Error removing VPN configuration: \(error.localizedDescription)")
                    } else {
                        VPNLogger.shared.log("Successfully removed VPN configuration")
                    }
                }
            }

            DispatchQueue.main.async { [weak self] in
                self?.vpnManager = nil
                self?.tunnelStatus = .disconnected
            }
        }
    }

    deinit {
        if let observer = vpnObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    private func simulateStartVPN() {
        VPNLogger.shared.log("Simulator: pretend to start VPN")
        DispatchQueue.main.async { [weak self] in
            self?.tunnelStatus = .connecting
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            self?.tunnelStatus = .connected
            VPNLogger.shared.log("Simulator: VPN marked connected")
        }
    }

    private func simulateStopVPN() {
        VPNLogger.shared.log("Simulator: pretend to stop VPN")
        DispatchQueue.main.async { [weak self] in
            self?.tunnelStatus = .disconnecting
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.tunnelStatus = .disconnected
            VPNLogger.shared.log("Simulator: VPN marked disconnected")
        }
    }
}

// MARK: - One-button VPN and iOS 27 pairing UI

struct ContentView: View {
    @StateObject private var tunnelManager = TunnelManager.shared
    @State private var showPairing = false
    @State private var stikDebugMissing = false
    @State private var openStikDebugWhenConnected = false

    private var isOn: Bool {
        tunnelManager.tunnelStatus == .connected || tunnelManager.tunnelStatus == .connecting
    }

    private var isBusy: Bool {
        tunnelManager.tunnelStatus == .connecting || tunnelManager.tunnelStatus == .disconnecting
    }

    private var statusText: String {
        switch tunnelManager.tunnelStatus {
        case .disconnected: return "Off"
        case .connecting: return "Turning On…"
        case .connected: return "On"
        case .disconnecting: return "Turning Off…"
        case .error: return "Try Again"
        }
    }

    private var accent: Color {
        switch tunnelManager.tunnelStatus {
        case .connected: return .green
        case .connecting, .disconnecting: return .orange
        case .error: return .red
        case .disconnected: return .gray
        }
    }

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            VStack(spacing: 24) {
                Text("OneTap Local VPN")
                    .font(.title2.weight(.semibold))

                Button(action: tunnelManager.toggleVPNConnection) {
                    ZStack {
                        Circle()
                            .fill(accent.opacity(0.14))
                            .frame(width: 190, height: 190)
                        Circle()
                            .stroke(accent, lineWidth: 8)
                            .frame(width: 160, height: 160)
                        Image(systemName: "power")
                            .font(.system(size: 64, weight: .medium))
                            .foregroundColor(accent)
                    }
                    .contentShape(Circle())
                }
                .buttonStyle(.plain)
                .disabled(isBusy || !tunnelManager.waitingOnSettings)
                .accessibilityLabel(isOn ? "Turn VPN off" : "Turn VPN on")

                Text(statusText)
                    .font(.headline)
                    .foregroundColor(accent)

                VStack(spacing: 12) {
                    Button {
                        if isOn { tunnelManager.stopVPN() }
                        showPairing = true
                    } label: {
                        Label("Get iOS 27 Pairing File", systemImage: "link.badge.plus")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button(action: openStikDebug) {
                        Label("Open StikDebug", systemImage: "bolt.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .frame(maxWidth: 330)
            }
            .padding(28)
        }
        .sheet(isPresented: $showPairing) {
            IOS27PairingView()
        }
        .onChange(of: tunnelManager.tunnelStatus) { _, status in
            if openStikDebugWhenConnected && status == .connected {
                openStikDebugWhenConnected = false
                launchStikDebug()
            } else if status == .error {
                openStikDebugWhenConnected = false
            }
        }
        .alert("StikDebug Not Found", isPresented: $stikDebugMissing) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Install StikDebug, then try again.")
        }
    }

    private func openStikDebug() {
        if tunnelManager.tunnelStatus == .connected {
            launchStikDebug()
        } else {
            openStikDebugWhenConnected = true
            tunnelManager.startVPN()
        }
    }

    private func launchStikDebug() {
        guard let url = URL(string: "stikdebug://") else { return }
        UIApplication.shared.open(url, options: [:]) { opened in
            if !opened { stikDebugMissing = true }
        }
    }
}

struct IOS27PairingView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = PairingController.shared

    var body: some View {
        NavigationView {
            VStack(spacing: 22) {
                Spacer()
                Image(systemName: phaseIcon)
                    .font(.system(size: 54))
                    .foregroundColor(phaseColor)

                content
                    .frame(maxWidth: 360)
                Spacer()
            }
            .padding(24)
            .navigationTitle("iOS 27 Pairing")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        switch controller.phase {
        case .idle:
            VStack(spacing: 14) {
                Text("Create this device’s pairing file without a computer using iOS 27 wireless pairing.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                Button("Start Pairing") { controller.start() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
            }

        case .waiting:
            VStack(spacing: 14) {
                ProgressView()
                Text("Open Settings › Privacy & Security › Developer Mode, scroll down, tap Pair with OneTap VPN, then enter the PIN shown here.")
                    .multilineTextAlignment(.center)
                Text("Keep this app running while you complete the Settings step.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

        case .showPin(let pin):
            VStack(spacing: 14) {
                Text("Enter this PIN in Settings")
                    .font(.headline)
                Text(pin)
                    .font(.system(size: 46, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .textSelection(.enabled)
                ProgressView("Completing pairing…")
            }

        case .success(let device):
            VStack(spacing: 14) {
                Text("Pairing complete")
                    .font(.title3.bold())
                if !device.name.isEmpty {
                    Text(device.name)
                        .foregroundColor(.secondary)
                }
                ShareLink(item: URL(fileURLWithPath: device.pairingFilePath)) {
                    Label("Export Pairing File", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                Text("Save or share the file, then open StikDebug and import it.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                Button("Open StikDebug") {
                    UIApplication.shared.open(URL(string: "stikdebug://")!)
                }
                .buttonStyle(.bordered)
                Button("Pair Again") { controller.reset() }
            }

        case .failed(let message):
            VStack(spacing: 14) {
                Text("Pairing failed")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .textSelection(.enabled)
                Button("Try Again") { controller.reset() }
                    .buttonStyle(.borderedProminent)
            }
        }
    }

    private var phaseIcon: String {
        switch controller.phase {
        case .success(_): return "checkmark.seal.fill"
        case .failed(_): return "xmark.octagon.fill"
        default: return "iphone.and.arrow.forward"
        }
    }

    private var phaseColor: Color {
        switch controller.phase {
        case .success(_): return .green
        case .failed(_): return .red
        default: return .blue
        }
    }
}
