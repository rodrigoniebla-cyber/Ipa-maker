import BackgroundTasks
import Combine
import Foundation
import UserNotifications

@MainActor
final class PairingController: ObservableObject {
    static let shared = PairingController()
    static let taskIdentifier = (Bundle.main.bundleIdentifier ?? "com.example.OneTapLocalVPN") + ".pairing"

    enum Phase: Equatable {
        case idle
        case waiting
        case showPin(String)
        case success(PairedDevice)
        case failed(String)
    }

    struct PairedDevice: Equatable {
        var name: String
        var model: String
        var udid: String
        var pairingFilePath: String
    }

    @Published var phase: Phase = .idle

    private let localNetwork = LocalNetworkAuthorization()
    private var netService: NetService?
    private var bgTask: BGContinuedProcessingTask?
    private var pairingStarted = false
    private var taskFinished = false

    private init() {}

    nonisolated func registerBackgroundTask() {
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: PairingController.taskIdentifier,
            using: DispatchQueue.main
        ) { task in
            guard let task = task as? BGContinuedProcessingTask else { return }
            MainActor.assumeIsolated {
                PairingController.shared.runPairing(task: task)
            }
        }
    }

    func start() {
        guard !pairingStarted else { return }
        phase = .waiting
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }

        Task {
            guard await localNetwork.request() else {
                phase = .failed("Local Network permission is required. Enable it in Settings › OneTap Local VPN › Local Network, then try again.")
                return
            }
            submitBackgroundTask()
        }
    }

    func reset() {
        guard !pairingStarted else { return }
        phase = .idle
    }

    private func submitBackgroundTask() {
        let request = BGContinuedProcessingTaskRequest(
            identifier: Self.taskIdentifier,
            title: "OneTap Pairing",
            subtitle: "Waiting for this device to connect…"
        )
        request.strategy = .queue

        do {
            try BGTaskScheduler.shared.submit(request)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
                guard let self, !self.pairingStarted else { return }
                self.runPairing(task: nil)
            }
        } catch {
            runPairing(task: nil)
        }
    }

    private func runPairing(task: BGContinuedProcessingTask?) {
        guard !pairingStarted else { return }
        pairingStarted = true
        taskFinished = false
        bgTask = task

        task?.progress.totalUnitCount = 100
        task?.progress.completedUnitCount = 5
        task?.expirationHandler = { [weak self] in
            guard let self else { return }
            self.stopAdvertising()
            self.finishTask(success: false)
            self.pairingStarted = false
            self.phase = .failed("Background time expired. Tap Try Again and complete the Settings step promptly.")
        }

        let outPath = Self.pairingFilePath()
        let contextBits = UInt(bitPattern: Unmanaged.passRetained(self).toOpaque())

        DispatchQueue.global(qos: .userInitiated).async {
            let context = UnsafeMutableRawPointer(bitPattern: contextBits)
            var result = StikPairResult()
            let rc = "0.0.0.0".withCString { bindAddress in
                "OneTap VPN".withCString { hostName in
                    "Mac17,7".withCString { model in
                        outPath.withCString { outputPath in
                            stikpair_run_host(
                                bindAddress,
                                0,
                                hostName,
                                model,
                                outputPath,
                                pairingReadyCallback,
                                pairingPinCallback,
                                context,
                                &result
                            )
                        }
                    }
                }
            }

            let outcome: Phase
            if rc == 0 {
                outcome = .success(PairedDevice(
                    name: pairingCString(result.device_name),
                    model: pairingCString(result.device_model),
                    udid: pairingCString(result.device_udid),
                    pairingFilePath: pairingCString(result.pairing_file_path)
                ))
            } else {
                let message = pairingCString(result.error)
                outcome = .failed(message.isEmpty ? "Pairing failed (code \(rc))." : message)
            }
            stikpair_result_free(&result)
            if let context {
                Unmanaged<PairingController>.fromOpaque(context).release()
            }

            DispatchQueue.main.async {
                self.stopAdvertising()
                self.pairingStarted = false
                self.phase = outcome
                if case .success = outcome {
                    self.bgTask?.progress.completedUnitCount = 100
                    self.postCompletionNotification()
                }
                self.finishTask(success: rc == 0)
            }
        }
    }

    private func finishTask(success: Bool) {
        guard !taskFinished else { return }
        taskFinished = true
        bgTask?.setTaskCompleted(success: success)
        bgTask = nil
    }

    fileprivate func startAdvertising(serviceID: String, port: Int32, txt: [String: Data]) {
        stopAdvertising()
        let service = NetService(
            domain: "",
            type: "_remotepairing-pairable-host._tcp.",
            name: serviceID,
            port: port
        )
        service.setTXTRecord(NetService.data(fromTXTRecord: txt))
        service.publish()
        netService = service
    }

    fileprivate func presentPin(_ pin: String) {
        phase = .showPin(pin)
        bgTask?.progress.completedUnitCount = 50
        bgTask?.updateTitle("OneTap Pairing", subtitle: "Enter code \(pin) on this device")
    }

    private func stopAdvertising() {
        netService?.stop()
        netService = nil
    }

    private func postCompletionNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Pairing complete"
        content.body = "Return to OneTap Local VPN to export the pairing file."
        content.sound = .default
        UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: "onetap.pairing.complete", content: content, trigger: nil)
        )
    }

    private static func pairingFilePath() -> String {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("rp_pairing_file.plist")
            .path
    }
}

private let pairingReadyCallback: StikPairReadyCb = { context, serviceID, port, keys, values, count in
    guard let context, let serviceID else { return }
    let controller = Unmanaged<PairingController>.fromOpaque(context).takeUnretainedValue()
    var txt: [String: Data] = [:]

    if let keys, let values {
        for index in 0..<Int(count) {
            guard let key = keys[index], let value = values[index] else { continue }
            txt[String(cString: key)] = Data(String(cString: value).utf8)
        }
    }

    DispatchQueue.main.async {
        controller.startAdvertising(
            serviceID: String(cString: serviceID),
            port: Int32(port),
            txt: txt
        )
    }
}

private let pairingPinCallback: StikPairPinCb = { pin, context in
    guard let context, let pin else { return }
    let controller = Unmanaged<PairingController>.fromOpaque(context).takeUnretainedValue()
    DispatchQueue.main.async {
        controller.presentPin(String(cString: pin))
    }
}

private func pairingCString(_ pointer: UnsafeMutablePointer<CChar>?) -> String {
    guard let pointer else { return "" }
    return String(cString: pointer)
}
