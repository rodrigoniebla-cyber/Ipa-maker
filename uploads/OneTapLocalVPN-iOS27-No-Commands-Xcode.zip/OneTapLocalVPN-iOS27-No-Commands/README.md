# OneTap Local VPN + iOS 27 Pairing

## Open and build — no Terminal commands

1. Double-click `LocalDevVPN.xcodeproj`.
2. Select the **LocalDevVPN** target, open **Signing & Capabilities**, and choose your Team.
3. Select **TunnelProv** and choose the same Team.
4. Connect your iOS 27 device and press **Run**.

The first Xcode build automatically prepares the Rust pairing library. Nothing needs to be generated manually. The first build needs an internet connection and can take several minutes; later builds reuse Cargo's cache.

## Features

- One-button on-device packet tunnel for SideStore/StikDebug-style networking
- On-device iOS 27 wireless RPPairing file generation
- Pairing PIN instructions and `rp_pairing_file.plist` export
- Opens StikDebug and starts the local VPN first when necessary
- No analytics, ads, remote VPN server, or traffic collection

## Pairing and JIT workflow

1. Tap **Get iOS 27 Pairing File** and **Start Pairing**.
2. Open **Settings › Privacy & Security › Developer Mode**.
3. Scroll down, choose **Pair with OneTap VPN**, and enter the displayed PIN.
4. Return to OneTap and export the pairing file.
5. Open StikDebug and import that file.
6. Select a compatible app in StikDebug to enable JIT.

OneTap provides the local tunnel and pairing file. StikDebug performs the debugger attach that enables JIT. On iOS 27, only target apps updated for the newer JIT method may work.

## Signing requirements

The app contains a `NEPacketTunnelProvider` extension. Apple must allow these entitlements in your provisioning profiles:

- Main app: `allow-vpn` and `packet-tunnel-provider`
- Tunnel extension: `packet-tunnel-provider`

Some free Personal Teams or third-party signing services may reject or remove Network Extension entitlements. In that case the app may install but the VPN cannot start.

Default identifiers—replace `com.example` with your own organization identifier if required:

- App: `com.example.OneTapLocalVPN`
- Extension: `com.example.OneTapLocalVPN.TunnelProv`

## Requirements

- Xcode 27
- iOS/iPadOS 27 or newer
- A physical iPhone or iPad
- Internet access during the first Xcode build
- StikDebug and a compatible, development-signed target app for JIT

## Attribution and license

Based on [SideStore/StosVPN](https://github.com/SideStore/StosVPN), LocalDevVPN, and [StikDebug/StikPair](https://github.com/StikDebug/StikPair). See `LICENSE`, `LICENSE-old`, and `LICENSE-StikPair`.

StikPair code is licensed for non-commercial use. Do not sell or monetize this build without permission from its author.
