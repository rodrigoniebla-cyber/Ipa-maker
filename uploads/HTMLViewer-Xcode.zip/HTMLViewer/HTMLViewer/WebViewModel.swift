import SwiftUI
import WebKit
import Combine

final class WebViewModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {

    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var pageTitle: String = ""
    @Published var currentURLString: String = ""
    @Published var errorMessage: String?

    let webView: WKWebView

    /// Keeps security-scoped access alive for the opened file/folder.
    private var scopedURL: URL?
    private var observers: [NSKeyValueObservation] = []

    override init() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        webView = WKWebView(frame: .zero, configuration: config)
        super.init()

        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        if #available(iOS 16.4, *) {
            webView.isInspectable = true
        }

        observers = [
            webView.observe(\.canGoBack, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async { self?.canGoBack = wv.canGoBack }
            },
            webView.observe(\.canGoForward, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async { self?.canGoForward = wv.canGoForward }
            },
            webView.observe(\.estimatedProgress, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async { self?.progress = wv.estimatedProgress }
            },
            webView.observe(\.isLoading, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async { self?.isLoading = wv.isLoading }
            },
            webView.observe(\.title, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async { self?.pageTitle = wv.title ?? "" }
            },
            webView.observe(\.url, options: .new) { [weak self] wv, _ in
                DispatchQueue.main.async {
                    guard let url = wv.url else { return }
                    self?.currentURLString = url.isFileURL
                        ? url.lastPathComponent
                        : url.absoluteString
                }
            }
        ]
    }

    deinit {
        scopedURL?.stopAccessingSecurityScopedResource()
    }

    // MARK: - Loading

    /// Load a local HTML file. Grants the web view read access to the file's
    /// parent folder so relative CSS / JS / image references resolve.
    func loadLocalFile(_ url: URL) {
        releaseScope()
        let didScope = url.startAccessingSecurityScopedResource()
        if didScope { scopedURL = url }
        errorMessage = nil
        let readAccessURL = url.deletingLastPathComponent()
        webView.loadFileURL(url, allowingReadAccessTo: readAccessURL)
    }

    /// Load a folder: looks for index.html (or the first .html file) inside
    /// and grants read access to the whole folder tree.
    func loadFolder(_ folderURL: URL) {
        releaseScope()
        let didScope = folderURL.startAccessingSecurityScopedResource()
        if didScope { scopedURL = folderURL }
        errorMessage = nil

        let fm = FileManager.default
        let index = folderURL.appendingPathComponent("index.html")
        var target: URL?

        if fm.fileExists(atPath: index.path) {
            target = index
        } else if let items = try? fm.contentsOfDirectory(
            at: folderURL, includingPropertiesForKeys: nil
        ) {
            target = items.first {
                ["html", "htm", "xhtml"].contains($0.pathExtension.lowercased())
            }
        }

        guard let target else {
            errorMessage = "No HTML file found in \"\(folderURL.lastPathComponent)\"."
            return
        }
        webView.loadFileURL(target, allowingReadAccessTo: folderURL)
    }

    /// Load from the address bar: a URL or a search query.
    func loadFromAddressBar(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        errorMessage = nil

        var candidate = trimmed
        if !candidate.contains("://") {
            if candidate.contains(".") && !candidate.contains(" ") {
                candidate = "https://" + candidate
            } else {
                let q = candidate.addingPercentEncoding(
                    withAllowedCharacters: .urlQueryAllowed) ?? candidate
                candidate = "https://duckduckgo.com/?q=\(q)"
            }
        }
        if let url = URL(string: candidate) {
            webView.load(URLRequest(url: url))
        }
    }

    func loadHTMLString(_ html: String) {
        releaseScope()
        errorMessage = nil
        webView.loadHTMLString(html, baseURL: nil)
    }

    private func releaseScope() {
        scopedURL?.stopAccessingSecurityScopedResource()
        scopedURL = nil
    }

    // MARK: - WKNavigationDelegate

    func webView(_ webView: WKWebView,
                 didFail navigation: WKNavigation!,
                 withError error: Error) {
        handle(error)
    }

    func webView(_ webView: WKWebView,
                 didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        handle(error)
    }

    private func handle(_ error: Error) {
        let nsError = error as NSError
        // Ignore "cancelled" (happens on rapid navigation / redirects).
        if nsError.domain == NSURLErrorDomain,
           nsError.code == NSURLErrorCancelled { return }
        if nsError.domain == "WebKitErrorDomain",
           nsError.code == 102 { return }
        errorMessage = nsError.localizedDescription
    }

    // MARK: - WKUIDelegate
    // Open target="_blank" links in the same view.
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}
