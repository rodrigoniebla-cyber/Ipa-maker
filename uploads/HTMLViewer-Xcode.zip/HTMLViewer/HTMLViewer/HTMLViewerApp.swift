import SwiftUI

@main
struct HTMLViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
