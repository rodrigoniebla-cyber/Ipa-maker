import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var model = WebViewModel()

    @State private var addressText = ""
    @State private var showingFileImporter = false
    @State private var showingFolderImporter = false
    @State private var hasContent = false
    @FocusState private var addressFocused: Bool

    private let htmlTypes: [UTType] = {
        var types: [UTType] = [.html]
        if let htm = UTType(filenameExtension: "htm") { types.append(htm) }
        if let xhtml = UTType(filenameExtension: "xhtml") { types.append(xhtml) }
        types.append(.xml)
        types.append(.text)
        return types
    }()

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            progressBar
            Divider()
            ZStack {
                WebView(model: model)
                    .ignoresSafeArea(.container, edges: .bottom)
                if !hasContent {
                    emptyState
                }
            }
        }
        .background(Color(uiColor: .systemBackground))
        .fileImporter(
            isPresented: $showingFileImporter,
            allowedContentTypes: htmlTypes,
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                model.loadLocalFile(url)
                hasContent = true
            }
        }
        .fileImporter(
            isPresented: $showingFolderImporter,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                model.loadFolder(url)
                hasContent = true
            }
        }
        .alert(
            "Couldn't Load Page",
            isPresented: Binding(
                get: { model.errorMessage != nil },
                set: { if !$0 { model.errorMessage = nil } }
            )
        ) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(model.errorMessage ?? "")
        }
        .onChange(of: model.currentURLString) { newValue in
            if !addressFocused { addressText = newValue }
        }
        .onOpenURL { url in
            // Opened from the Files app / another app's share sheet.
            if url.isFileURL {
                model.loadLocalFile(url)
                hasContent = true
            }
        }
    }

    // MARK: - Toolbar

    private var toolbar: some View {
        HStack(spacing: 12) {
            Button {
                model.webView.goBack()
            } label: {
                Image(systemName: "chevron.left")
            }
            .disabled(!model.canGoBack)

            Button {
                model.webView.goForward()
            } label: {
                Image(systemName: "chevron.right")
            }
            .disabled(!model.canGoForward)

            addressBar

            Button {
                if model.isLoading {
                    model.webView.stopLoading()
                } else {
                    model.webView.reload()
                }
            } label: {
                Image(systemName: model.isLoading ? "xmark" : "arrow.clockwise")
            }
            .disabled(!hasContent)

            Menu {
                Button {
                    showingFileImporter = true
                } label: {
                    Label("Open HTML File…", systemImage: "doc.badge.plus")
                }
                Button {
                    showingFolderImporter = true
                } label: {
                    Label("Open Folder…", systemImage: "folder.badge.plus")
                }
                Divider()
                Button {
                    model.loadHTMLString(Self.sampleHTML)
                    hasContent = true
                } label: {
                    Label("Load Sample Page", systemImage: "sparkles")
                }
            } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.title3)
            }
        }
        .font(.body.weight(.medium))
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
    }

    private var addressBar: some View {
        HStack(spacing: 6) {
            Image(systemName: "magnifyingglass")
                .font(.caption)
                .foregroundStyle(.secondary)
            TextField("Search or enter address", text: $addressText)
                .focused($addressFocused)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.webSearch)
                .submitLabel(.go)
                .onSubmit {
                    model.loadFromAddressBar(addressText)
                    hasContent = true
                    addressFocused = false
                }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Color(uiColor: .secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .frame(maxWidth: .infinity)
    }

    private var progressBar: some View {
        GeometryReader { geo in
            Rectangle()
                .fill(Color.accentColor)
                .frame(width: geo.size.width * model.progress)
                .opacity(model.isLoading ? 1 : 0)
                .animation(.easeOut(duration: 0.2), value: model.progress)
        }
        .frame(height: 2)
    }

    // MARK: - Empty state

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "globe")
                .font(.system(size: 56))
                .foregroundStyle(.tint)
            Text("HTML Viewer")
                .font(.title2.bold())
            Text("Open a local HTML file or folder,\nor enter a URL above.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)

            VStack(spacing: 12) {
                Button {
                    showingFileImporter = true
                } label: {
                    Label("Open HTML File", systemImage: "doc.badge.plus")
                        .frame(maxWidth: 260)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    showingFolderImporter = true
                } label: {
                    Label("Open Folder (site with assets)", systemImage: "folder.badge.plus")
                        .frame(maxWidth: 260)
                }
                .buttonStyle(.bordered)
            }
            .padding(.top, 8)
        }
        .padding()
        .background(Color(uiColor: .systemBackground))
    }

    // MARK: - Sample

    static let sampleHTML = """
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body { font-family: -apple-system, sans-serif; margin: 0;
             display: grid; place-items: center; min-height: 100vh;
             background: linear-gradient(160deg,#0f2027,#203a43,#2c5364);
             color: #fff; text-align: center; }
      .card { padding: 2rem 2.5rem; border-radius: 20px;
              background: rgba(255,255,255,.08);
              backdrop-filter: blur(10px); }
      button { margin-top: 1rem; padding: .6rem 1.4rem; font-size: 1rem;
               border: 0; border-radius: 10px; cursor: pointer; }
    </style>
    </head>
    <body>
      <div class="card">
        <h1>It works! 🎉</h1>
        <p>HTML, CSS and JavaScript are all running.</p>
        <button onclick="this.textContent = 'Tapped ' + (++window.n||(window.n=1)) + '×'">
          Tap me
        </button>
      </div>
    </body>
    </html>
    """
}
