# HTML Viewer — ready-to-archive Xcode project

A mini browser for iPhone & iPad that opens and runs local **HTML files**
(with CSS, JavaScript, images, media) using WebKit — plus a normal address bar.

## Folder layout

```
HTMLViewer/
├── HTMLViewer.xcodeproj/          ← open THIS in Xcode
│   └── xcshareddata/xcschemes/    ← shared scheme, Archive pre-configured (Release)
└── HTMLViewer/
    ├── HTMLViewerApp.swift        ← app entry point
    ├── ContentView.swift          ← browser UI + Files-app open handler
    ├── WebView.swift              ← SwiftUI ↔︎ WKWebView bridge
    ├── WebViewModel.swift         ← WebKit engine logic
    ├── Info.plist                 ← registers the app as an HTML document viewer
    └── Assets.xcassets/           ← app icon (1024pt single-size) + accent color
```

## Archive → IPA (3 steps)

1. **Open** `HTMLViewer.xcodeproj` in Xcode 15 or newer.
2. **Sign**: select the *HTMLViewer* target → *Signing & Capabilities* →
   pick your **Team**. If your Apple ID isn't listed, add it under
   Xcode → Settings → Accounts. Optionally change the bundle id
   (`com.example.htmlviewer`) to something under your own domain.
3. **Archive**: select the destination **Any iOS Device (arm64)** in the
   toolbar, then **Product → Archive**. When the Organizer opens:
   **Distribute App** → choose
   - *Debugging* / *Release Testing* (ad-hoc) → exports a signed **.ipa** for
     your registered devices, or
   - *TestFlight & App Store* → uploads to App Store Connect.

That's it — no other configuration is needed. The scheme's Archive action is
already set to the Release configuration.

### Run on your device without an IPA
Plug in your iPhone/iPad, pick it as the destination, press **Run** ▶︎.
(With a free Apple ID the app must be re-signed every 7 days; a paid
developer account removes that limit.)

## App features

- **Open HTML File…** / **Open Folder…** (folder mode grants access to all
  relative assets — CSS, JS, images, fonts)
- Registered as an HTML document viewer: in the Files app you can
  **long-press an .html file → Share → HTML Viewer**
- Back / forward (+ swipe gestures), reload / stop, progress bar
- Address bar: URLs or search (DuckDuckGo)
- iPhone + iPad, all orientations, dark mode, full JavaScript & media support

## Notes

- Deployment target: **iOS 16.0**.
- No third-party dependencies — only SwiftUI + WebKit.
- `WebViewModel` sets the WebKit preference `allowFileAccessFromFileURLs` so
  local pages can fetch sibling files. This uses a KVC key that is fine for
  personal/ad-hoc builds; if you ever submit to the **App Store** and review
  flags it, delete that single line — normal local pages still work because
  file access is granted via `loadFileURL(_:allowingReadAccessTo:)`.
