import SwiftUI
import UIKit

// MARK: - Service Badge
public struct ServiceBadge: View {
    public let service: MusicService
    public var size: CGFloat = 16
    public var showTitle: Bool = true
    
    public init(service: MusicService, size: CGFloat = 16, showTitle: Bool = true) {
        self.service = service
        self.size = size
        self.showTitle = showTitle
    }
    
    public var body: some View {
        HStack(spacing: 6) {
            Image(systemName: service.iconSymbol)
                .font(.system(size: size, weight: .bold))
                .foregroundColor(.white)
            
            if showTitle {
                Text(service.shortName)
                    .font(.system(size: size, weight: .semibold))
                    .foregroundColor(.white)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(service.brandColor)
        .cornerRadius(20)
    }
}

// MARK: - Artwork Image View
public struct ArtworkImageView: View {
    public let urlString: String?
    public let defaultSymbol: String
    public var cornerRadius: CGFloat = 8
    
    public init(urlString: String?, defaultSymbol: String = "music.note", cornerRadius: CGFloat = 8) {
        self.urlString = urlString
        self.defaultSymbol = defaultSymbol
        self.cornerRadius = cornerRadius
    }
    
    public var body: some View {
        Group {
            if let urlString = urlString, let url = URL(string: urlString) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    case .failure:
                        placeholderView
                    case .empty:
                        ProgressView()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(Color(.secondarySystemBackground))
                    @unknown default:
                        placeholderView
                    }
                }
            } else {
                placeholderView
            }
        }
        .cornerRadius(cornerRadius)
        .clipped()
    }
    
    private var placeholderView: some View {
        ZStack {
            LinearGradient(
                colors: [Color.gray.opacity(0.3), Color.gray.opacity(0.15)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Image(systemName: defaultSymbol)
                .font(.system(size: 24))
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Status Badge View
public struct StatusBadgeView: View {
    public let status: TrackMatchStatus
    
    public init(status: TrackMatchStatus) {
        self.status = status
    }
    
    public var body: some View {
        Text(status.rawValue)
            .font(.system(size: 11, weight: .semibold))
            .foregroundColor(.white)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(status.badgeColor)
            .cornerRadius(12)
    }
}

// MARK: - Waveform Visualizer
public struct WaveformVisualizer: View {
    @State private var phase: CGFloat = 0.0
    public var color: Color = .accentColor
    
    public init(color: Color = .accentColor) {
        self.color = color
    }
    
    public var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<6) { index in
                WaveBar(index: index, phase: phase, color: color)
            }
        }
        .frame(height: 30)
        .onAppear {
            withAnimation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true)) {
                phase = 1.0
            }
        }
    }
}

struct WaveBar: View {
    let index: Int
    let phase: CGFloat
    let color: Color
    
    var height: CGFloat {
        let base: [CGFloat] = [10, 24, 18, 28, 14, 20]
        let variation = base[index % base.count] * (phase > 0.5 ? 1.0 : 0.4)
        return max(6, variation)
    }
    
    var body: some View {
        RoundedRectangle(cornerRadius: 3)
            .fill(color)
            .frame(width: 4, height: height)
    }
}

// MARK: - Circular Progress Ring
public struct CircularProgressRing: View {
    public let progress: Double
    public var lineWidth: CGFloat = 10
    public var gradient: LinearGradient
    
    public init(
        progress: Double,
        lineWidth: CGFloat = 10,
        gradient: LinearGradient = LinearGradient(colors: [.green, .red], startPoint: .topLeading, endPoint: .bottomTrailing)
    ) {
        self.progress = progress
        self.lineWidth = lineWidth
        self.gradient = gradient
    }
    
    public var body: some View {
        ZStack {
            Circle()
                .stroke(Color.secondary.opacity(0.2), lineWidth: lineWidth)
            
            Circle()
                .trim(from: 0.0, to: CGFloat(min(progress, 1.0)))
                .stroke(
                    gradient,
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.3), value: progress)
        }
    }
}
