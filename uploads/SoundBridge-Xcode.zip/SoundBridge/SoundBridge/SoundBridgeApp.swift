import SwiftUI

@main
struct SoundBridgeApp: App {
    @StateObject private var spotifyAuth = SpotifyAuthManager.shared
    @StateObject private var appleMusicAuth = AppleMusicAuthManager.shared
    
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .onOpenURL { url in
                    // Handle Spotify OAuth PKCE redirect
                    if url.scheme == "soundbridge" {
                        Task {
                            await spotifyAuth.handleAuthCallback(url: url)
                        }
                    }
                }
        }
    }
}
