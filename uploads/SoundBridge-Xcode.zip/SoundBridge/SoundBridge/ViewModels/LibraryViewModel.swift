import Foundation
import SwiftUI
import Combine

@MainActor
public final class LibraryViewModel: ObservableObject {
    @Published public var selectedService: MusicService = .spotify
    @Published public var spotifyPlaylists: [Playlist] = []
    @Published public var appleMusicPlaylists: [Playlist] = []
    @Published public var isLoading: Bool = false
    @Published public var searchQuery: String = ""
    @Published public var selectedPlaylistForDetail: Playlist?
    @Published public var playlistTracks: [Track] = []
    @Published public var isLoadingTracks: Bool = false
    @Published public var errorMessage: String?
    
    public let spotifyAuth = SpotifyAuthManager.shared
    public let appleMusicAuth = AppleMusicAuthManager.shared
    
    public init() {
        loadAll()
    }
    
    public var currentPlaylists: [Playlist] {
        let list = (selectedService == .spotify) ? spotifyPlaylists : appleMusicPlaylists
        if searchQuery.isEmpty { return list }
        return list.filter {
            $0.name.localizedCaseInsensitiveContains(searchQuery) ||
            ($0.description ?? "").localizedCaseInsensitiveContains(searchQuery)
        }
    }
    
    public func loadAll() {
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                self.spotifyPlaylists = try await SpotifyAPIService.shared.fetchUserPlaylists()
            } catch {
                print("Failed to load Spotify in library: \(error)")
            }
            
            do {
                self.appleMusicPlaylists = try await AppleMusicAPIService.shared.fetchUserPlaylists()
            } catch {
                print("Failed to load Apple Music in library: \(error)")
            }
            
            self.isLoading = false
        }
    }
    
    public func openPlaylistDetail(_ playlist: Playlist) {
        self.selectedPlaylistForDetail = playlist
        self.playlistTracks = []
        self.isLoadingTracks = true
        
        Task {
            do {
                if playlist.service == .spotify {
                    self.playlistTracks = try await SpotifyAPIService.shared.fetchPlaylistTracks(playlistId: playlist.id)
                } else {
                    self.playlistTracks = try await AppleMusicAPIService.shared.fetchPlaylistTracks(playlist: playlist)
                }
            } catch {
                self.errorMessage = "Failed to load tracks: \(error.localizedDescription)"
            }
            self.isLoadingTracks = false
        }
    }
}
