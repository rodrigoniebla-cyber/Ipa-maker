import Foundation
import SwiftUI
import Combine

@MainActor
public final class TransferViewModel: ObservableObject {
    // Services selection
    @Published public var sourceService: MusicService = .spotify
    @Published public var targetService: MusicService = .appleMusic
    
    // Playlists & Selection
    @Published public var sourcePlaylists: [Playlist] = []
    @Published public var selectedPlaylist: Playlist?
    @Published public var customTargetPlaylistName: String = ""
    @Published public var customDescription: String = ""
    @Published public var searchQuery: String = ""
    @Published public var isLoadingPlaylists: Bool = false
    @Published public var errorMessage: String?
    
    // Transfer Options
    @Published public var options: TransferOptions = TransferOptions()
    
    // Sheets & Active Transfer
    @Published public var showActiveTransferSheet: Bool = false
    @Published public var showDirectURLSheet: Bool = false
    @Published public var showConfigSheet: Bool = false
    
    // Managers
    public let spotifyAuth = SpotifyAuthManager.shared
    public let appleMusicAuth = AppleMusicAuthManager.shared
    public let transferEngine = PlaylistTransferEngine.shared
    
    public init() {
        loadPlaylists()
    }
    
    public var filteredPlaylists: [Playlist] {
        if searchQuery.isEmpty {
            return sourcePlaylists
        }
        return sourcePlaylists.filter {
            $0.name.localizedCaseInsensitiveContains(searchQuery) ||
            ($0.description ?? "").localizedCaseInsensitiveContains(searchQuery)
        }
    }
    
    public func swapServices() {
        let temp = sourceService
        sourceService = targetService
        targetService = temp
        selectedPlaylist = nil
        loadPlaylists()
    }
    
    public func loadPlaylists() {
        isLoadingPlaylists = true
        errorMessage = nil
        
        Task {
            do {
                if sourceService == .spotify {
                    let lists = try await SpotifyAPIService.shared.fetchUserPlaylists()
                    self.sourcePlaylists = lists
                } else {
                    let lists = try await AppleMusicAPIService.shared.fetchUserPlaylists()
                    self.sourcePlaylists = lists
                }
                
                if selectedPlaylist == nil {
                    selectedPlaylist = sourcePlaylists.first
                    customTargetPlaylistName = selectedPlaylist?.name ?? ""
                }
            } catch {
                self.errorMessage = "Failed to load \(sourceService.rawValue) playlists: \(error.localizedDescription)"
            }
            self.isLoadingPlaylists = false
        }
    }
    
    public func selectPlaylist(_ playlist: Playlist) {
        self.selectedPlaylist = playlist
        self.customTargetPlaylistName = playlist.name
    }
    
    public func beginTransfer() {
        guard let source = selectedPlaylist else { return }
        
        showActiveTransferSheet = true
        transferEngine.startTransfer(
            sourcePlaylist: source,
            targetService: targetService,
            customTargetName: customTargetPlaylistName.isEmpty ? source.name : customTargetPlaylistName,
            customDescription: customDescription.isEmpty ? nil : customDescription,
            options: options
        )
    }
    
    public func importDirectURL(url: String) {
        // Parse direct URL
        let isSpotify = url.contains("spotify.com")
        let isApple = url.contains("music.apple.com")
        
        let service: MusicService = isSpotify ? .spotify : .appleMusic
        let customPlaylist = Playlist(
            id: "custom_url_\(UUID().uuidString.prefix(6))",
            name: "Imported Playlist",
            description: "Direct URL Import from \(url)",
            artworkURL: nil,
            trackCount: 10,
            ownerName: "Shared Link",
            isPublic: true,
            service: service,
            externalURL: url
        )
        
        self.sourceService = service
        self.targetService = (service == .spotify) ? .appleMusic : .spotify
        self.sourcePlaylists.insert(customPlaylist, at: 0)
        self.selectedPlaylist = customPlaylist
        self.customTargetPlaylistName = "Imported Playlist"
    }
}
