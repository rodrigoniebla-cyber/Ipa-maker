import Foundation
import SwiftUI
import Combine

@MainActor
public final class SettingsViewModel: ObservableObject {
    @Published public var matchWithISRC: Bool {
        didSet { UserDefaults.standard.set(matchWithISRC, forKey: "settings_match_isrc") }
    }
    @Published public var skipDuplicates: Bool {
        didSet { UserDefaults.standard.set(skipDuplicates, forKey: "settings_skip_duplicates") }
    }
    @Published public var rateLimitDelayMs: Double {
        didSet { UserDefaults.standard.set(rateLimitDelayMs, forKey: "settings_rate_limit_delay") }
    }
    @Published public var sensitivity: TransferOptions.MatchingSensitivity {
        didSet { UserDefaults.standard.set(sensitivity.rawValue, forKey: "settings_sensitivity") }
    }
    @Published public var showSuccessToast: Bool = false
    
    public init() {
        self.matchWithISRC = UserDefaults.standard.object(forKey: "settings_match_isrc") as? Bool ?? true
        self.skipDuplicates = UserDefaults.standard.object(forKey: "settings_skip_duplicates") as? Bool ?? true
        self.rateLimitDelayMs = UserDefaults.standard.object(forKey: "settings_rate_limit_delay") as? Double ?? 120.0
        
        let sensRaw = UserDefaults.standard.string(forKey: "settings_sensitivity") ?? TransferOptions.MatchingSensitivity.balanced.rawValue
        self.sensitivity = TransferOptions.MatchingSensitivity(rawValue: sensRaw) ?? .balanced
    }
    
    public func exportSettings() -> TransferOptions {
        var opts = TransferOptions()
        opts.matchWithISRC = matchWithISRC
        opts.skipDuplicates = skipDuplicates
        opts.rateLimitDelayMs = Int(rateLimitDelayMs)
        opts.matchingSensitivity = sensitivity
        return opts
    }
    
    public func resetToDefaults() {
        self.matchWithISRC = true
        self.skipDuplicates = true
        self.rateLimitDelayMs = 120.0
        self.sensitivity = .balanced
    }
}
