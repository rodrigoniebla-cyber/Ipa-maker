import SwiftUI
import UIKit

public struct TransferDetailSheet: View {
    @Environment(\.dismiss) private var dismiss
    public let job: SBTransferJob
    @State private var showShareSheet: Bool = false
    @State private var shareText: String = ""
    
    public init(job: SBTransferJob) {
        self.job = job
    }
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    VStack(spacing: 6) {
                        HStack(spacing: 8) {
                            ServiceBadge(service: job.sourceService, size: 12)
                            Image(systemName: "arrow.right")
                                .foregroundColor(.secondary)
                            ServiceBadge(service: job.targetService, size: 12)
                        }
                        
                        Text(job.targetPlaylistName)
                            .font(.title3)
                            .fontWeight(.bold)
                            .padding(.top, 4)
                        
                        Text("\(job.matchedCount) of \(job.totalCount) songs transferred (\(String(format: "%.1f", job.matchRatePercentage))% match)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text(job.formattedDate)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 10)
                    
                    HStack(spacing: 12) {
                        Button {
                            shareText = TransferHistoryStore.shared.exportAsTextSummary(for: job)
                            showShareSheet = true
                        } label: {
                            HStack {
                                Image(systemName: "doc.text")
                                Text("Export Summary")
                            }
                            .font(.footnote)
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(.secondarySystemGroupedBackground))
                            .cornerRadius(10)
                        }
                        
                        Button {
                            shareText = TransferHistoryStore.shared.exportAsCSV(for: job)
                            showShareSheet = true
                        } label: {
                            HStack {
                                Image(systemName: "tablecells")
                                Text("Export CSV")
                            }
                            .font(.footnote)
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(.secondarySystemGroupedBackground))
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 16)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Track Breakdown")
                            .font(.headline)
                            .padding(.horizontal, 16)
                        
                        VStack(spacing: 8) {
                            ForEach(job.items) { item in
                                HStack(spacing: 12) {
                                    Image(systemName: item.status.isSuccess ? "checkmark.circle.fill" : "xmark.circle.fill")
                                        .foregroundColor(item.status.isSuccess ? .green : .orange)
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(item.sourceTrack.title)
                                            .font(.system(size: 14, weight: .semibold))
                                            .lineLimit(1)
                                        Text(item.sourceTrack.artist)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                            .lineLimit(1)
                                    }
                                    
                                    Spacer()
                                    
                                    StatusBadgeView(status: item.status)
                                }
                                .padding(12)
                                .background(Color(.secondarySystemGroupedBackground))
                                .cornerRadius(10)
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }
                .padding(.vertical, 16)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Transfer Record")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .sheet(isPresented: $showShareSheet) {
                ShareActivityView(activityItems: [shareText])
            }
        }
    }
}

public struct ShareActivityView: UIViewControllerRepresentable {
    public let activityItems: [Any]
    public let applicationActivities: [UIActivity]? = nil
    
    public func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
    }
    
    public func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
