import SwiftUI

public struct MainTabView: View {
    @State private var selectedTab: Int = 0
    @ObservedObject private var spotifyAuth = SpotifyAuthManager.shared
    @ObservedObject private var appleAuth = AppleMusicAuthManager.shared
    
    public init() {}
    
    public var body: some View {
        TabView(selection: $selectedTab) {
            TransferView()
                .tabItem {
                    Label("Transfer", systemImage: "arrow.left.arrow.right")
                }
                .tag(0)
            
            AccountsView()
                .tabItem {
                    Label("Accounts", systemImage: "person.2.circle.fill")
                }
                .tag(1)
            
            LibraryView()
                .tabItem {
                    Label("Library", systemImage: "music.note.list")
                }
                .tag(2)
            
            HistoryView()
                .tabItem {
                    Label("History", systemImage: "clock.arrow.circlepath")
                }
                .tag(3)
            
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape.fill")
                }
                .tag(4)
        }
        .accentColor(Color(red: 29/255, green: 185/255, blue: 84/255))
    }
}
