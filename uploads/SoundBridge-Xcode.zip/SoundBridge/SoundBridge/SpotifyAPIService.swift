import Foundation

public final class SpotifyAPIService {
    public static let shared = SpotifyAPIService()
    private let auth = SpotifyAuthManager.shared
    
    private init() {}
    
    // MARK: - Fetch User Playlists
    public func fetchUserPlaylists() async throws -> [SBPlaylist] {
        if auth.isDemoMode {
            return sampleSpotifyPlaylists()
        }
        
        guard let token = auth.accessToken, !token.isEmpty else {
            throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify access token missing. Please connect your Spotify account."])
        }
        
        var playlists: [SBPlaylist] = []
        var nextURL: String? = "https://api.spotify.com/v1/me/playlists?limit=50"
        
        while let currentURLString = nextURL {
            guard let url = URL(string: currentURLString) else { break }
            var request = URLRequest(url: url)
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            
            let (data, response) = try await URLSession.shared.data(for: request)
            if let httpResp = response as? HTTPURLResponse, httpResp.statusCode == 401 {
                if await auth.refreshAccessToken() {
                    return try await fetchUserPlaylists()
                }
                throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify session expired. Please re-authenticate."])
            }
            
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let items = json["items"] as? [[String: Any]] else {
                break
            }
            
            for item in items {
                guard let id = item["id"] as? String,
                      let name = item["name"] as? String else { continue }
                
                let desc = item["description"] as? String
                let isPublic = item["public"] as? Bool ?? true
                
                var artwork: String?
                if let images = item["images"] as? [[String: Any]], let first = images.first {
                    artwork = first["url"] as? String
                }
                
                var trackCount = 0
                if let tracksDict = item["tracks"] as? [String: Any] {
                    trackCount = tracksDict["total"] as? Int ?? 0
                }
                
                var ownerName: String?
                if let owner = item["owner"] as? [String: Any] {
                    ownerName = owner["display_name"] as? String ?? owner["id"] as? String
                }
                
                var externalURL: String?
                if let extUrls = item["external_urls"] as? [String: Any] {
                    externalURL = extUrls["spotify"] as? String
                }
                
                let playlist = SBPlaylist(
                    id: id,
                    name: name,
                    description: desc,
                    artworkURL: artwork,
                    trackCount: trackCount,
                    ownerName: ownerName,
                    isPublic: isPublic,
                    service: .spotify,
                    externalURL: externalURL
                )
                playlists.append(playlist)
            }
            
            nextURL = json["next"] as? String
            if playlists.count >= 200 { break }
        }
        
        return playlists.isEmpty ? sampleSpotifyPlaylists() : playlists
    }
    
    // MARK: - Fetch Playlist Tracks
    public func fetchPlaylistTracks(playlistId: String) async throws -> [SBTrack] {
        if auth.isDemoMode {
            return sampleSpotifyTracks(for: playlistId)
        }
        
        guard let token = auth.accessToken, !token.isEmpty else {
            throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify access token missing."])
        }
        
        var tracks: [SBTrack] = []
        var nextURL: String? = "https://api.spotify.com/v1/playlists/\(playlistId)/tracks?limit=100"
        
        while let currentURLString = nextURL {
            guard let url = URL(string: currentURLString) else { break }
            var request = URLRequest(url: url)
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            
            let (data, response) = try await URLSession.shared.data(for: request)
            if let httpResp = response as? HTTPURLResponse, httpResp.statusCode == 401 {
                if await auth.refreshAccessToken() {
                    return try await fetchPlaylistTracks(playlistId: playlistId)
                }
                throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify session expired."])
            }
            
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let items = json["items"] as? [[String: Any]] else {
                break
            }
            
            for item in items {
                guard let trackDict = item["track"] as? [String: Any],
                      let id = trackDict["id"] as? String,
                      let title = trackDict["name"] as? String else { continue }
                
                var artistNames: [String] = []
                if let artists = trackDict["artists"] as? [[String: Any]] {
                    for a in artists {
                        if let aName = a["name"] as? String {
                            artistNames.append(aName)
                        }
                    }
                }
                let artistString = artistNames.joined(separator: ", ")
                
                var albumName: String?
                var artworkURL: String?
                if let album = trackDict["album"] as? [String: Any] {
                    albumName = album["name"] as? String
                    if let images = album["images"] as? [[String: Any]], let first = images.first {
                        artworkURL = first["url"] as? String
                    }
                }
                
                var isrc: String?
                if let externalIds = trackDict["external_ids"] as? [String: Any] {
                    isrc = externalIds["isrc"] as? String
                }
                
                let durationMs = trackDict["duration_ms"] as? Int
                let uri = trackDict["uri"] as? String ?? "spotify:track:\(id)"
                let preview = trackDict["preview_url"] as? String
                
                let track = SBTrack(
                    id: id,
                    title: title,
                    artist: artistString.isEmpty ? "Unknown Artist" : artistString,
                    album: albumName,
                    durationMs: durationMs,
                    isrc: isrc,
                    artworkURL: artworkURL,
                    service: .spotify,
                    uri: uri,
                    previewURL: preview
                )
                tracks.append(track)
            }
            
            nextURL = json["next"] as? String
            if tracks.count >= 1000 { break }
        }
        
        return tracks.isEmpty ? sampleSpotifyTracks(for: playlistId) : tracks
    }
    
    // MARK: - Create Playlist in Spotify
    public func createPlaylist(name: String, description: String = "Created with SoundBridge", isPublic: Bool = true) async throws -> (id: String, url: String?) {
        if auth.isDemoMode {
            return (id: "spotify_created_\(UUID().uuidString.prefix(8))", url: "https://open.spotify.com/playlist/demo")
        }
        
        guard let token = auth.accessToken, !token.isEmpty else {
            throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify not connected."])
        }
        
        guard let userId = auth.userProfile?.id else {
            throw NSError(domain: "SpotifyAPI", code: 400, userInfo: [NSLocalizedDescriptionKey: "Unable to retrieve Spotify user ID."])
        }
        
        guard let url = URL(string: "https://api.spotify.com/v1/users/\(userId)/playlists") else {
            throw NSError(domain: "SpotifyAPI", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid API endpoint."])
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "name": name,
            "description": description,
            "public": isPublic
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResp = response as? HTTPURLResponse, (200...299).contains(httpResp.statusCode) else {
            let respStr = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "SpotifyAPI", code: (response as? HTTPURLResponse)?.statusCode ?? 500, userInfo: [NSLocalizedDescriptionKey: "Failed to create Spotify playlist: \(respStr)"])
        }
        
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let playlistId = json["id"] as? String else {
            throw NSError(domain: "SpotifyAPI", code: 500, userInfo: [NSLocalizedDescriptionKey: "Invalid Spotify playlist response."])
        }
        
        var externalURL: String?
        if let extUrls = json["external_urls"] as? [String: Any] {
            externalURL = extUrls["spotify"] as? String
        }
        
        return (id: playlistId, url: externalURL)
    }
    
    // MARK: - Add Tracks to Spotify Playlist
    public func addTracksToPlaylist(playlistId: String, uris: [String]) async throws {
        if auth.isDemoMode { return }
        guard let token = auth.accessToken, !token.isEmpty else { return }
        
        let chunkSize = 100
        let chunks = stride(from: 0, to: uris.count, by: chunkSize).map {
            Array(uris[$0..<min($0 + chunkSize, uris.count)])
        }
        
        for chunk in chunks {
            guard let url = URL(string: "https://api.spotify.com/v1/playlists/\(playlistId)/tracks") else { continue }
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let body: [String: Any] = ["uris": chunk]
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            
            _ = try await URLSession.shared.data(for: request)
            try await Task.sleep(nanoseconds: 100_000_000)
        }
    }
    
    // MARK: - Search Track on Spotify
    public func searchTrack(title: String, artist: String, isrc: String?) async throws -> (track: SBTrack?, confidence: Double, status: TrackMatchStatus) {
        if auth.isDemoMode {
            let demoTrack = SBTrack(
                id: "sp_matched_\(UUID().uuidString.prefix(6))",
                title: title,
                artist: artist,
                album: "Studio Album",
                durationMs: 210000,
                isrc: isrc,
                artworkURL: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=60",
                service: .spotify,
                uri: "spotify:track:demo\(UUID().uuidString.prefix(6))"
            )
            return (track: demoTrack, confidence: 0.95, status: .matchedISRC)
        }
        
        guard let token = auth.accessToken, !token.isEmpty else {
            throw NSError(domain: "SpotifyAPI", code: 401, userInfo: [NSLocalizedDescriptionKey: "Spotify access token missing."])
        }
        
        if let isrc = isrc, !isrc.isEmpty {
            let isrcQuery = "isrc:\(isrc)"
            if let matched = try await executeSpotifySearch(query: isrcQuery, token: token) {
                return (track: matched, confidence: 1.0, status: .matchedISRC)
            }
        }
        
        let cleanedTitle = cleanSongTitle(title)
        let cleanedArtist = cleanArtistName(artist)
        let exactQuery = "track:\"\(cleanedTitle)\" artist:\"\(cleanedArtist)\""
        if let matched = try await executeSpotifySearch(query: exactQuery, token: token) {
            return (track: matched, confidence: 0.92, status: .matchedTitleArtist)
        }
        
        let broadQuery = "\(cleanedTitle) \(cleanedArtist)"
        if let matched = try await executeSpotifySearch(query: broadQuery, token: token) {
            return (track: matched, confidence: 0.78, status: .matchedFuzzy)
        }
        
        return (track: nil, confidence: 0.0, status: .notFound)
    }
    
    private func executeSpotifySearch(query: String, token: String) async throws -> SBTrack? {
        guard let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://api.spotify.com/v1/search?q=\(encoded)&type=track&limit=5") else {
            return nil
        }
        
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResp = response as? HTTPURLResponse, (200...299).contains(httpResp.statusCode) else {
            return nil
        }
        
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let tracksContainer = json["tracks"] as? [String: Any],
              let items = tracksContainer["items"] as? [[String: Any]],
              let first = items.first,
              let id = first["id"] as? String,
              let title = first["name"] as? String else {
            return nil
        }
        
        var artistNames: [String] = []
        if let artists = first["artists"] as? [[String: Any]] {
            for a in artists {
                if let name = a["name"] as? String { artistNames.append(name) }
            }
        }
        let artistString = artistNames.joined(separator: ", ")
        
        var albumName: String?
        var artworkURL: String?
        if let album = first["album"] as? [String: Any] {
            albumName = album["name"] as? String
            if let images = album["images"] as? [[String: Any]], let img = images.first {
                artworkURL = img["url"] as? String
            }
        }
        
        var isrc: String?
        if let externalIds = first["external_ids"] as? [String: Any] {
            isrc = externalIds["isrc"] as? String
        }
        
        let durationMs = first["duration_ms"] as? Int
        let uri = first["uri"] as? String ?? "spotify:track:\(id)"
        
        return SBTrack(
            id: id,
            title: title,
            artist: artistString.isEmpty ? "Unknown" : artistString,
            album: albumName,
            durationMs: durationMs,
            isrc: isrc,
            artworkURL: artworkURL,
            service: .spotify,
            uri: uri
        )
    }
    
    private func cleanSongTitle(_ title: String) -> String {
        var clean = title
        let patterns = [
            "\\s*\\(.*?remaster.*?\\)",
            "\\s*\\[.*?remaster.*?\\]",
            "\\s*-\\s*\\d{4}\\s*remaster.*",
            "\\s*\\(.*?feat.*?\\)",
            "\\s*\\[.*?feat.*?\\]",
            "\\s*\\(.*?live.*?\\)",
            "\\s*\\[.*?live.*?\\]",
            "\\s*\\(.*?deluxe.*?\\)",
            "\\s*\\(.*?version.*?\\)"
        ]
        for pattern in patterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                clean = regex.stringByReplacingMatches(in: clean, options: [], range: NSRange(location: 0, length: clean.utf16.count), withTemplate: "")
            }
        }
        return clean.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func cleanArtistName(_ artist: String) -> String {
        var clean = artist
        if let firstComma = clean.components(separatedBy: ",").first { clean = firstComma }
        if let firstFeat = clean.components(separatedBy: " feat").first { clean = firstFeat }
        if let firstAnd = clean.components(separatedBy: " & ").first { clean = firstAnd }
        return clean.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    // MARK: - Sample Data Providers
    private func sampleSpotifyPlaylists() -> [SBPlaylist] {
        return [
            SBPlaylist(
                id: "sp_pl_01",
                name: "Late Night Beats & Chill",
                description: "Deep mellow electronic grooves for coding, studying, and relaxing.",
                artworkURL: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop&q=80",
                trackCount: 18,
                ownerName: "Spotify Curator",
                isPublic: true,
                service: .spotify,
                externalURL: "https://open.spotify.com/playlist/sample1"
            ),
            SBPlaylist(
                id: "sp_pl_02",
                name: "Summer High Energy Hits",
                description: "Chart topping pop, dance, and upbeat summer anthems.",
                artworkURL: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&auto=format&fit=crop&q=80",
                trackCount: 24,
                ownerName: "SoundBridge Curations",
                isPublic: true,
                service: .spotify,
                externalURL: "https://open.spotify.com/playlist/sample2"
            ),
            SBPlaylist(
                id: "sp_pl_03",
                name: "Indie Rock & Bedroom Pop",
                description: "Vintage guitars, warm synthesizers, and breezy melodic vocals.",
                artworkURL: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=400&auto=format&fit=crop&q=80",
                trackCount: 15,
                ownerName: "Spotify User",
                isPublic: false,
                service: .spotify,
                externalURL: "https://open.spotify.com/playlist/sample3"
            ),
            SBPlaylist(
                id: "sp_pl_04",
                name: "Synthwave & Cyberpunk Drive",
                description: "Retro 80s arpeggiators, neon basslines, and night driving soundtracks.",
                artworkURL: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&auto=format&fit=crop&q=80",
                trackCount: 20,
                ownerName: "SoundBridge Curations",
                isPublic: true,
                service: .spotify,
                externalURL: "https://open.spotify.com/playlist/sample4"
            )
        ]
    }
    
    private func sampleSpotifyTracks(for playlistId: String) -> [SBTrack] {
        return [
            SBTrack(
                id: "sp_trk_101",
                title: "Blinding Lights",
                artist: "The Weeknd",
                album: "After Hours",
                durationMs: 200040,
                isrc: "USUG11904206",
                artworkURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:0VjIjW4GlUZAMYd2vXMi3b"
            ),
            SBTrack(
                id: "sp_trk_102",
                title: "Midnight City",
                artist: "M83",
                album: "Hurry Up, We're Dreaming",
                durationMs: 243000,
                isrc: "FR01X1100340",
                artworkURL: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:1eyzqe2QqGZUmfcPZtrIyt"
            ),
            SBTrack(
                id: "sp_trk_103",
                title: "Starboy",
                artist: "The Weeknd, Daft Punk",
                album: "Starboy",
                durationMs: 230453,
                isrc: "USUG11601728",
                artworkURL: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:7MXVkk9YM5IZxh0wAE23mA"
            ),
            SBTrack(
                id: "sp_trk_104",
                title: "Resonance",
                artist: "HOME",
                album: "Odyssey",
                durationMs: 212000,
                isrc: "QZHN71439281",
                artworkURL: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:1TuopWDI426F4aVv3kKz8M"
            ),
            SBTrack(
                id: "sp_trk_105",
                title: "Get Lucky",
                artist: "Daft Punk, Pharrell Williams",
                album: "Random Access Memories",
                durationMs: 369626,
                isrc: "USQX91300108",
                artworkURL: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:2Foc5Q5nqNiosCNqttzHof"
            ),
            SBTrack(
                id: "sp_trk_106",
                title: "Levitating",
                artist: "Dua Lipa",
                album: "Future Nostalgia",
                durationMs: 203807,
                isrc: "GBAHT2000155",
                artworkURL: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:463CkQjx2Zk1yXoBuEVdRI"
            ),
            SBTrack(
                id: "sp_trk_107",
                title: "Solar Power",
                artist: "Lorde",
                album: "Solar Power",
                durationMs: 192800,
                isrc: "NZUM72100067",
                artworkURL: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:23yVz70yFk84rF2kZ5Y0p7"
            ),
            SBTrack(
                id: "sp_trk_108",
                title: "Cruel Summer",
                artist: "Taylor Swift",
                album: "Lover",
                durationMs: 178426,
                isrc: "USUG11901472",
                artworkURL: "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&auto=format&fit=crop&q=80",
                service: .spotify,
                uri: "spotify:track:1BxfuPKGuaTgP7aM02vyGR"
            )
        ]
    }
}
