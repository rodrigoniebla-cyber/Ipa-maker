import SwiftUI

public struct TransferView: View {
    @StateObject private var viewModel = TransferViewModel()
    @ObservedObject private var spotifyAuth = SpotifyAuthManager.shared
    @ObservedObject private var appleAuth = AppleMusicAuthManager.shared
    @ObservedObject private var transferEngine = PlaylistTransferEngine.shared
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // MARK: - Account Integration Status Banner
                    accountIntegrationBanner
                    
                    // MARK: - Direction Switcher Card
                    directionSwitcherCard
                    
                    // MARK: - Source Playlists Section
                    sourcePlaylistsSection
                    
                    // MARK: - Target Playlist Settings
                    targetSettingsSection
                    
                    // MARK: - Start Transfer Button
                    startTransferButton
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Transfer Playlists")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        viewModel.showDirectURLSheet = true
                    } label: {
                        Label("Import Link", systemImage: "link")
                    }
                }
            }
            .sheet(isPresented: $viewModel.showActiveTransferSheet) {
                ActiveTransferView()
            }
            .sheet(isPresented: $viewModel.showDirectURLSheet) {
                DirectURLEntrySheet { url in
                    viewModel.importDirectURL(url: url)
                }
            }
            .refreshable {
                viewModel.loadPlaylists()
            }
        }
    }
    
    // MARK: - Account Integration Banner
    private var accountIntegrationBanner: some View {
        VStack(spacing: 8) {
            HStack {
                Text("ACCOUNT INTEGRATION")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.secondary)
                Spacer()
            }
            
            HStack(spacing: 12) {
                // Spotify Status
                HStack(spacing: 8) {
                    Circle()
                        .fill(spotifyAuth.isConnected ? Color.green : Color.orange)
                        .frame(width: 10, height: 10)
                    Image(systemName: MusicService.spotify.iconSymbol)
                        .foregroundColor(MusicService.spotify.brandColor)
                    Text(spotifyAuth.isConnected ? (spotifyAuth.userProfile?.displayName ?? "Spotify Connected") : "Spotify Disconnected")
                        .font(.footnote)
                        .fontWeight(.medium)
                        .lineLimit(1)
                    Spacer()
                }
                .padding(10)
                .background(Color(.secondarySystemGroupedBackground))
                .cornerRadius(10)
                
                // Apple Music Status
                HStack(spacing: 8) {
                    Circle()
                        .fill(appleAuth.isAuthorized ? Color.green : Color.orange)
                        .frame(width: 10, height: 10)
                    Image(systemName: MusicService.appleMusic.iconSymbol)
                        .foregroundColor(MusicService.appleMusic.brandColor)
                    Text(appleAuth.isAuthorized ? "Apple Music Active" : "Apple Music Pending")
                        .font(.footnote)
                        .fontWeight(.medium)
                        .lineLimit(1)
                    Spacer()
                }
                .padding(10)
                .background(Color(.secondarySystemGroupedBackground))
                .cornerRadius(10)
            }
        }
    }
    
    // MARK: - Direction Switcher Card
    private var directionSwitcherCard: some View {
        VStack(spacing: 14) {
            HStack {
                // Source Service Card
                VStack(spacing: 6) {
                    Text("SOURCE")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 6) {
                        Image(systemName: viewModel.sourceService.iconSymbol)
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                        Text(viewModel.sourceService.rawValue)
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(viewModel.sourceService.gradient)
                    .cornerRadius(12)
                }
                .frame(maxWidth: .infinity)
                
                // Swap Button
                Button {
                    withAnimation(.spring()) {
                        viewModel.swapServices()
                    }
                } label: {
                    ZStack {
                        Circle()
                            .fill(Color(.secondarySystemBackground))
                            .frame(width: 44, height: 44)
                            .shadow(color: .black.opacity(0.1), radius: 3, x: 0, y: 2)
                        Image(systemName: "arrow.left.arrow.right")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.primary)
                    }
                }
                
                // Target Service Card
                VStack(spacing: 6) {
                    Text("TARGET")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 6) {
                        Image(systemName: viewModel.targetService.iconSymbol)
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                        Text(viewModel.targetService.rawValue)
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(viewModel.targetService.gradient)
                    .cornerRadius(12)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    // MARK: - Source Playlists Section
    private var sourcePlaylistsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Select Source Playlist")
                    .font(.headline)
                Spacer()
                if viewModel.isLoadingPlaylists {
                    ProgressView()
                } else {
                    Text("\(viewModel.filteredPlaylists.count) Playlists")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Search field
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Search playlists...", text: $viewModel.searchQuery)
                if !viewModel.searchQuery.isEmpty {
                    Button {
                        viewModel.searchQuery = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding(10)
            .background(Color(.tertiarySystemGroupedBackground))
            .cornerRadius(10)
            
            // Playlist List
            if viewModel.filteredPlaylists.isEmpty && !viewModel.isLoadingPlaylists {
                VStack(spacing: 8) {
                    Image(systemName: "music.note.list")
                        .font(.system(size: 32))
                        .foregroundColor(.secondary)
                    Text("No playlists found")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 24)
            } else {
                VStack(spacing: 8) {
                    ForEach(viewModel.filteredPlaylists) { playlist in
                        playlistRow(playlist)
                    }
                }
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    private func playlistRow(_ playlist: Playlist) -> some View {
        let isSelected = viewModel.selectedPlaylist?.id == playlist.id
        
        return Button {
            withAnimation(.easeInOut(duration: 0.2)) {
                viewModel.selectPlaylist(playlist)
            }
        } label: {
            HStack(spacing: 12) {
                ArtworkImageView(urlString: playlist.artworkURL, cornerRadius: 8)
                    .frame(width: 52, height: 52)
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(playlist.name)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    
                    Text("\(playlist.trackCount) songs • \(playlist.ownerName ?? playlist.service.rawValue)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                ZStack {
                    Circle()
                        .stroke(isSelected ? viewModel.sourceService.brandColor : Color.secondary.opacity(0.3), lineWidth: 2)
                        .frame(width: 24, height: 24)
                    
                    if isSelected {
                        Circle()
                            .fill(viewModel.sourceService.brandColor)
                            .frame(width: 16, height: 16)
                    }
                }
            }
            .padding(10)
            .background(isSelected ? viewModel.sourceService.brandColor.opacity(0.1) : Color.clear)
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }
    
    // MARK: - Target Settings Section
    private var targetSettingsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Target Playlist Settings")
                .font(.headline)
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Playlist Name on \(viewModel.targetService.rawValue)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                TextField("Playlist Name", text: $viewModel.customTargetPlaylistName)
                    .textFieldStyle(.roundedBorder)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Description (Optional)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                TextField("Created with SoundBridge", text: $viewModel.customDescription)
                    .textFieldStyle(.roundedBorder)
            }
            
            Toggle("Match using ISRC (Highest Accuracy)", isOn: $viewModel.options.matchWithISRC)
                .font(.subheadline)
            
            Toggle("Skip Duplicate Songs", isOn: $viewModel.options.skipDuplicates)
                .font(.subheadline)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    // MARK: - Start Transfer Button
    private var startTransferButton: some View {
        Button {
            viewModel.beginTransfer()
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 18, weight: .bold))
                Text(viewModel.selectedPlaylist != nil
                     ? "Transfer '\(viewModel.selectedPlaylist!.name)'"
                     : "Select a Playlist to Transfer")
                    .font(.system(size: 17, weight: .bold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                viewModel.selectedPlaylist != nil
                ? LinearGradient(colors: [viewModel.sourceService.brandColor, viewModel.targetService.brandColor], startPoint: .leading, endPoint: .trailing)
                : LinearGradient(colors: [Color.gray, Color.gray], startPoint: .leading, endPoint: .trailing)
            )
            .cornerRadius(16)
            .shadow(color: viewModel.selectedPlaylist != nil ? viewModel.sourceService.brandColor.opacity(0.3) : .clear, radius: 8, x: 0, y: 4)
        }
        .disabled(viewModel.selectedPlaylist == nil || transferEngine.isTransferring)
    }
}
