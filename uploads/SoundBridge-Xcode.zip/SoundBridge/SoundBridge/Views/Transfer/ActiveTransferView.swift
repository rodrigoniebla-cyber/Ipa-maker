import SwiftUI

public struct ActiveTransferView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var engine = PlaylistTransferEngine.shared
    @State private var showLogsSheet: Bool = false
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()
                
                if engine.transferCompleted {
                    completionView
                } else {
                    inProgressView
                }
            }
            .navigationTitle(engine.transferCompleted ? "Transfer Summary" : "Transferring...")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if !engine.transferCompleted {
                        Button("Cancel") {
                            engine.cancelTransfer()
                        }
                        .foregroundColor(.red)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if engine.transferCompleted {
                        Button("Done") {
                            dismiss()
                        }
                        .fontWeight(.bold)
                    }
                }
            }
        }
    }
    
    // MARK: - In Progress View
    private var inProgressView: some View {
        VStack(spacing: 24) {
            // Circular Progress + Visualizer
            ZStack {
                CircularProgressRing(
                    progress: engine.currentProgress,
                    lineWidth: 12,
                    gradient: LinearGradient(
                        colors: [engine.activeJob?.sourceService.brandColor ?? .green, engine.activeJob?.targetService.brandColor ?? .red],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 170, height: 170)
                
                VStack(spacing: 4) {
                    WaveformVisualizer(color: engine.activeJob?.sourceService.brandColor ?? .accentColor)
                    
                    Text("\(Int(engine.currentProgress * 100))%")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                    
                    Text("\(engine.currentTrackIndex) of \(engine.totalTracksCount)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding(.top, 16)
            
            // Currently Processing Track Card
            if let currentItem = engine.currentProcessingTrack {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("NOW MATCHING")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(.secondary)
                        Spacer()
                        StatusBadgeView(status: currentItem.status)
                    }
                    
                    HStack(spacing: 12) {
                        ArtworkImageView(urlString: currentItem.sourceTrack.artworkURL, cornerRadius: 8)
                            .frame(width: 50, height: 50)
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text(currentItem.sourceTrack.title)
                                .font(.system(size: 15, weight: .semibold))
                                .lineLimit(1)
                            
                            Text(currentItem.sourceTrack.artist)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                            
                            if let isrc = currentItem.sourceTrack.isrc {
                                Text("ISRC: \(isrc)")
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
                .padding(14)
                .background(Color(.secondarySystemGroupedBackground))
                .cornerRadius(14)
                .padding(.horizontal, 16)
            }
            
            // Live Log Console Box
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("LIVE LOGS")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.secondary)
                    Spacer()
                    Text("\(engine.logs.count) events")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 6) {
                            ForEach(engine.logs) { log in
                                HStack(alignment: .top, spacing: 6) {
                                    Text(log.formattedTime)
                                        .font(.system(size: 10, design: .monospaced))
                                        .foregroundColor(.secondary)
                                    
                                    Text(log.message)
                                        .font(.system(size: 11, design: .monospaced))
                                        .foregroundColor(log.level.color)
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                .id(log.id)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                    }
                    .background(Color.black.opacity(0.85))
                    .cornerRadius(10)
                    .frame(height: 140)
                    .onChange(of: engine.logs.count) { _ in
                        if let last = engine.logs.last {
                            withAnimation {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            
            Spacer()
        }
    }
    
    // MARK: - Completion View
    private var completionView: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header Badge
                VStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 54))
                        .foregroundColor(.green)
                    
                    Text("Transfer Finished!")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("\(engine.activeJob?.sourcePlaylistName ?? "") ➔ \(engine.activeJob?.targetPlaylistName ?? "")")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.top, 10)
                
                // Summary Stats Row
                HStack(spacing: 12) {
                    statBox(
                        title: "Match Rate",
                        value: "\(String(format: "%.0f", engine.activeJob?.matchRatePercentage ?? 0))%",
                        color: .purple
                    )
                    statBox(
                        title: "Transferred",
                        value: "\(engine.activeJob?.matchedCount ?? 0)",
                        color: .green
                    )
                    statBox(
                        title: "Unmatched",
                        value: "\(engine.activeJob?.unmatchedCount ?? 0)",
                        color: .orange
                    )
                }
                .padding(.horizontal, 16)
                
                // Track breakdown list
                VStack(alignment: .leading, spacing: 10) {
                    Text("Track Details (\(engine.activeJob?.items.count ?? 0))")
                        .font(.headline)
                        .padding(.horizontal, 16)
                    
                    VStack(spacing: 8) {
                        ForEach(engine.activeJob?.items ?? []) { item in
                            HStack(spacing: 12) {
                                Image(systemName: item.status.isSuccess ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .foregroundColor(item.status.isSuccess ? .green : .orange)
                                
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.sourceTrack.title)
                                        .font(.system(size: 14, weight: .semibold))
                                        .lineLimit(1)
                                    Text(item.sourceTrack.artist)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .lineLimit(1)
                                }
                                
                                Spacer()
                                
                                StatusBadgeView(status: item.status)
                            }
                            .padding(10)
                            .background(Color(.secondarySystemGroupedBackground))
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 30)
        }
    }
    
    private func statBox(title: String, value: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(color)
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(12)
    }
}
