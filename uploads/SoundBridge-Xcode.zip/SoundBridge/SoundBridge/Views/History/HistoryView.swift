import SwiftUI

public struct HistoryView: View {
    @ObservedObject private var historyStore = TransferHistoryStore.shared
    @State private var selectedJob: TransferJob?
    @State private var showClearConfirmation: Bool = false
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Summary Stats Card
                    if !historyStore.jobs.isEmpty {
                        statsOverviewCard
                    }
                    
                    // History List
                    if historyStore.jobs.isEmpty {
                        emptyStateView
                    } else {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Recent Transfers")
                                .font(.headline)
                                .padding(.horizontal, 16)
                            
                            VStack(spacing: 10) {
                                ForEach(historyStore.jobs) { job in
                                    Button {
                                        selectedJob = job
                                    } label: {
                                        jobRow(job)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                    }
                }
                .padding(.vertical, 12)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("History & Reports")
            .toolbar {
                if !historyStore.jobs.isEmpty {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            showClearConfirmation = true
                        } label: {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            .confirmationDialog("Clear Transfer History?", isPresented: $showClearConfirmation, titleVisibility: .visible) {
                Button("Clear All History", role: .destructive) {
                    historyStore.clearAllHistory()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will remove all saved transfer logs and reports from this device.")
            }
            .sheet(item: $selectedJob) { job in
                TransferDetailSheet(job: job)
            }
        }
    }
    
    private var statsOverviewCard: some View {
        HStack(spacing: 12) {
            statItem(title: "Transfers", value: "\(historyStore.totalTransfersCount)", icon: "arrow.left.arrow.right", color: .blue)
            statItem(title: "Songs Moved", value: "\(historyStore.totalSongsTransferred)", icon: "music.note", color: .green)
            statItem(title: "Avg Match", value: "\(String(format: "%.0f", historyStore.averageMatchRate))%", icon: "checkmark.circle", color: .purple)
        }
        .padding(.horizontal, 16)
    }
    
    private func statItem(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(color)
            
            Text(value)
                .font(.system(size: 20, weight: .bold, design: .rounded))
            
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(12)
    }
    
    private func jobRow(_ job: TransferJob) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: job.sourceService.iconSymbol)
                        .foregroundColor(job.sourceService.brandColor)
                    Image(systemName: "arrow.right")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    Image(systemName: job.targetService.iconSymbol)
                        .foregroundColor(job.targetService.brandColor)
                }
                
                Spacer()
                
                Text(job.formattedDate)
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(job.sourcePlaylistName)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    
                    Text("\(job.matchedCount)/\(job.totalCount) songs matched • \(String(format: "%.0f", job.matchRatePercentage))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Text(job.state.rawValue)
                    .font(.caption2)
                    .fontWeight(.semibold)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(job.state == .completed ? Color.green.opacity(0.15) : Color.orange.opacity(0.15))
                    .foregroundColor(job.state == .completed ? .green : .orange)
                    .cornerRadius(8)
            }
        }
        .padding(14)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(14)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 12) {
            Image(systemName: "clock.arrow.circlepath")
                .font(.system(size: 48))
                .foregroundColor(.secondary)
            
            Text("No Transfers Yet")
                .font(.headline)
            
            Text("Your completed playlist transfers and detailed reports will be archived here.")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .padding(.top, 60)
    }
}
