import SwiftUI

public struct PlaylistDetailSheet: View {
    @Environment(\.dismiss) private var dismiss
    public let playlist: Playlist
    public let tracks: [Track]
    public let isLoading: Bool
    
    @State private var showTransferModal: Bool = false
    
    public init(playlist: Playlist, tracks: [Track], isLoading: Bool) {
        self.playlist = playlist
        self.tracks = tracks
        self.isLoading = isLoading
    }
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Header Artwork & Info
                    HStack(spacing: 16) {
                        ArtworkImageView(urlString: playlist.artworkURL, cornerRadius: 12)
                            .frame(width: 100, height: 100)
                            .shadow(radius: 4)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            ServiceBadge(service: playlist.service, size: 12)
                            
                            Text(playlist.name)
                                .font(.title3)
                                .fontWeight(.bold)
                                .lineLimit(2)
                            
                            Text("\(playlist.trackCount) tracks • By \(playlist.ownerName ?? "Unknown")")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    
                    if let desc = playlist.description, !desc.isEmpty {
                        Text(desc)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 16)
                    }
                    
                    // Transfer This Playlist Button
                    Button {
                        showTransferModal = true
                    } label: {
                        HStack {
                            Image(systemName: "arrow.left.arrow.right")
                            Text("Transfer to \(playlist.service == .spotify ? "Apple Music" : "Spotify")")
                        }
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            playlist.service == .spotify
                            ? MusicService.appleMusic.gradient
                            : MusicService.spotify.gradient
                        )
                        .cornerRadius(12)
                    }
                    .padding(.horizontal, 16)
                    
                    Divider()
                        .padding(.horizontal, 16)
                    
                    // Tracks Section
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Tracklist (\(tracks.count))")
                            .font(.headline)
                            .padding(.horizontal, 16)
                        
                        if isLoading {
                            HStack {
                                Spacer()
                                ProgressView("Loading tracks...")
                                Spacer()
                            }
                            .padding(.vertical, 20)
                        } else if tracks.isEmpty {
                            Text("No tracks found in playlist.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .padding(.horizontal, 16)
                        } else {
                            VStack(spacing: 6) {
                                ForEach(Array(tracks.enumerated()), id: \.element.id) { index, track in
                                    HStack(spacing: 12) {
                                        Text("\(index + 1)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                            .frame(width: 22, alignment: .trailing)
                                        
                                        ArtworkImageView(urlString: track.artworkURL, cornerRadius: 4)
                                            .frame(width: 38, height: 38)
                                        
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(track.title)
                                                .font(.system(size: 14, weight: .medium))
                                                .lineLimit(1)
                                            Text(track.artist)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                                .lineLimit(1)
                                        }
                                        
                                        Spacer()
                                        
                                        Text(track.formattedDuration)
                                            .font(.caption2)
                                            .foregroundColor(.secondary)
                                    }
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 4)
                                }
                            }
                        }
                    }
                }
                .padding(.vertical, 16)
            }
            .navigationTitle("Playlist Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .sheet(isPresented: $showTransferModal) {
                ActiveTransferView()
                    .onAppear {
                        let targetService: MusicService = (playlist.service == .spotify) ? .appleMusic : .spotify
                        PlaylistTransferEngine.shared.startTransfer(
                            sourcePlaylist: playlist,
                            targetService: targetService,
                            customTargetName: playlist.name,
                            customDescription: playlist.description
                        )
                    }
            }
        }
    }
}
