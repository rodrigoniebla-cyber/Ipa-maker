import SwiftUI

public struct LibraryView: View {
    @StateObject private var viewModel = LibraryViewModel()
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Service Segment Picker
                Picker("Service", selection: $viewModel.selectedService) {
                    Text("Spotify").tag(MusicService.spotify)
                    Text("Apple Music").tag(MusicService.appleMusic)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color(.systemGroupedBackground))
                
                // Playlists List
                if viewModel.isLoading {
                    Spacer()
                    ProgressView("Loading Playlists...")
                    Spacer()
                } else if viewModel.currentPlaylists.isEmpty {
                    Spacer()
                    VStack(spacing: 8) {
                        Image(systemName: "music.note.list")
                            .font(.system(size: 44))
                            .foregroundColor(.secondary)
                        Text("No playlists found")
                            .font(.headline)
                        Text("Connect your account in the Accounts tab to view your full library.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 32)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(viewModel.currentPlaylists) { playlist in
                            Button {
                                viewModel.openPlaylistDetail(playlist)
                            } label: {
                                HStack(spacing: 14) {
                                    ArtworkImageView(urlString: playlist.artworkURL, cornerRadius: 8)
                                        .frame(width: 58, height: 58)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(playlist.name)
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                            .lineLimit(1)
                                        
                                        Text("\(playlist.trackCount) songs • \(playlist.ownerName ?? playlist.service.rawValue)")
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                            .lineLimit(1)
                                        
                                        if let desc = playlist.description, !desc.isEmpty {
                                            Text(desc)
                                                .font(.caption2)
                                                .foregroundColor(.secondary)
                                                .lineLimit(1)
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    Image(systemName: "chevron.right")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .searchable(text: $viewModel.searchQuery, prompt: "Search playlists...")
                }
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Library")
            .sheet(item: $viewModel.selectedPlaylistForDetail) { playlist in
                PlaylistDetailSheet(
                    playlist: playlist,
                    tracks: viewModel.playlistTracks,
                    isLoading: viewModel.isLoadingTracks
                )
            }
            .refreshable {
                viewModel.loadAll()
            }
        }
    }
}
