import SwiftUI

public struct DiagnosticsSheet: View {
    @Environment(\.dismiss) private var dismiss
    public let report: [String: String]
    
    public init(report: [String: String]) {
        self.report = report
    }
    
    public var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Diagnostics Results")) {
                    if report.isEmpty {
                        Text("No test data available.")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(report.keys.sorted(), id: \.self) { key in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(key)
                                    .font(.headline)
                                Text(report[key] ?? "")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("Diagnostics")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}
