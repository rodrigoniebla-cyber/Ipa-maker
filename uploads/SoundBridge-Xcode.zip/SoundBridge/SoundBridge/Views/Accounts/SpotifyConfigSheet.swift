import SwiftUI

public struct SpotifyConfigSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var auth = SpotifyAuthManager.shared
    @State private var clientIdInput: String = ""
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Spotify Developer App Settings")) {
                    Text("By default, SoundBridge uses its built-in registered Client ID for PKCE authorization. If you prefer to use your own Spotify Developer Dashboard App, enter your Client ID below.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    TextField("Spotify Client ID", text: $clientIdInput)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    if !clientIdInput.isEmpty {
                        Button("Reset to Default Client ID") {
                            clientIdInput = ""
                        }
                        .foregroundColor(.red)
                        .font(.caption)
                    }
                }
                
                Section(header: Text("Redirect URI Setup")) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("If using your custom Spotify App, add this Redirect URI in your Spotify Developer Dashboard:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Text(SpotifyAuthManager.redirectUri)
                            .font(.system(size: 13, design: .monospaced))
                            .padding(8)
                            .background(Color(.tertiarySystemGroupedBackground))
                            .cornerRadius(6)
                    }
                }
                
                Section(header: Text("Scopes Requested")) {
                    Text(SpotifyAuthManager.scopes.replacingOccurrences(of: " ", with: "\n• "))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Spotify API Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        auth.saveCustomClientId(clientIdInput)
                        dismiss()
                    }
                    .fontWeight(.bold)
                }
            }
            .onAppear {
                clientIdInput = auth.customClientId
            }
        }
    }
}
