import Foundation
import UIKit
import AuthenticationServices
import CryptoKit
import Combine

public final class SpotifyAuthManager: NSObject, ObservableObject, ASWebAuthenticationPresentationContextProviding {
    public static let shared = SpotifyAuthManager()
    
    // Published State
    @Published public var isConnected: Bool = false
    @Published public var isAuthenticating: Bool = false
    @Published public var userProfile: SBSpotifyUserProfile?
    @Published public var lastErrorMessage: String?
    @Published public var customClientId: String = ""
    @Published public var isDemoMode: Bool = false
    
    // Storage Keys
    private let kAccessToken = "spotify_access_token"
    private let kRefreshToken = "spotify_refresh_token"
    private let kTokenExpiration = "spotify_token_expiration"
    private let kCustomClientId = "spotify_custom_client_id"
    private let kIsDemoMode = "spotify_is_demo_mode"
    
    public static let defaultClientId = "0b5df9a4e8c14774843b0d4586f7aa82"
    public static let redirectUri = "soundbridge://spotify-callback"
    public static let scopes = "playlist-read-private playlist-read-collaborative playlist-modify-public playlist-modify-private user-library-read user-library-modify user-read-private user-read-email"
    
    private var codeVerifier: String?
    private var authSession: ASWebAuthenticationSession?
    
    public override init() {
        super.init()
        loadStoredCredentials()
    }
    
    public var activeClientId: String {
        let trimmed = customClientId.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? SpotifyAuthManager.defaultClientId : trimmed
    }
    
    public var accessToken: String? {
        if isDemoMode {
            return "demo_spotify_token"
        }
        return UserDefaults.standard.string(forKey: kAccessToken)
    }
    
    public func loadStoredCredentials() {
        self.customClientId = UserDefaults.standard.string(forKey: kCustomClientId) ?? ""
        self.isDemoMode = UserDefaults.standard.bool(forKey: kIsDemoMode)
        
        if isDemoMode {
            self.isConnected = true
            self.userProfile = SBSpotifyUserProfile(
                id: "spotify_user_demo",
                displayName: "Spotify Demo User",
                email: "user@example.com",
                product: "premium",
                avatarURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=60",
                followersCount: 142,
                country: "US"
            )
            return
        }
        
        if let token = UserDefaults.standard.string(forKey: kAccessToken), !token.isEmpty {
            self.isConnected = true
            Task {
                await fetchCurrentProfile()
            }
        } else {
            self.isConnected = false
            self.userProfile = nil
        }
    }
    
    public func saveCustomClientId(_ clientId: String) {
        self.customClientId = clientId
        UserDefaults.standard.set(clientId, forKey: kCustomClientId)
    }
    
    // MARK: - PKCE OAuth Flow
    @MainActor
    public func startAuthentication() {
        self.isAuthenticating = true
        self.lastErrorMessage = nil
        
        let verifier = generatePKCECodeVerifier()
        self.codeVerifier = verifier
        let challenge = generatePKCECodeChallenge(from: verifier)
        
        var components = URLComponents(string: "https://accounts.spotify.com/authorize")
        components?.queryItems = [
            URLQueryItem(name: "client_id", value: activeClientId),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: SpotifyAuthManager.redirectUri),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "scope", value: SpotifyAuthManager.scopes),
            URLQueryItem(name: "show_dialog", value: "true")
        ]
        
        guard let authURL = components?.url else {
            self.isAuthenticating = false
            self.lastErrorMessage = "Failed to construct authorization URL."
            return
        }
        
        let session = ASWebAuthenticationSession(
            url: authURL,
            callbackURLScheme: "soundbridge"
        ) { [weak self] callbackURL, error in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.isAuthenticating = false
                
                if let error = error {
                    let nsError = error as NSError
                    if nsError.domain == ASWebAuthenticationSessionErrorDomain &&
                        nsError.code == ASWebAuthenticationSessionError.canceledLogin.rawValue {
                        self.lastErrorMessage = "Spotify sign-in was cancelled."
                    } else {
                        self.lastErrorMessage = "Spotify authentication error: \(error.localizedDescription)"
                    }
                    return
                }
                
                guard let callbackURL = callbackURL else {
                    self.lastErrorMessage = "No callback URL received from Spotify."
                    return
                }
                
                await self.handleAuthCallback(url: callbackURL)
            }
        }
        
        session.presentationContextProvider = self
        session.prefersEphemeralWebBrowserSession = false
        self.authSession = session
        session.start()
    }
    
    @MainActor
    public func handleAuthCallback(url: URL) async {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: true),
              let code = components.queryItems?.first(where: { $0.name == "code" })?.value else {
            if let error = url.absoluteString.components(separatedBy: "error=").last {
                self.lastErrorMessage = "Spotify authorization failed: \(error)"
            } else {
                self.lastErrorMessage = "Missing authorization code in callback."
            }
            return
        }
        
        guard let verifier = self.codeVerifier else {
            self.lastErrorMessage = "Code verifier is missing for PKCE exchange."
            return
        }
        
        await exchangeCodeForToken(code: code, codeVerifier: verifier)
    }
    
    private func exchangeCodeForToken(code: String, codeVerifier: String) async {
        guard let url = URL(string: "https://accounts.spotify.com/api/token") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let bodyParams: [String: String] = [
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": SpotifyAuthManager.redirectUri,
            "client_id": activeClientId,
            "code_verifier": codeVerifier
        ]
        
        request.httpBody = bodyParams
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }
            .joined(separator: "&")
            .data(using: .utf8)
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                let errString = String(data: data, encoding: .utf8) ?? "Unknown token exchange response"
                await MainActor.run {
                    self.lastErrorMessage = "Token exchange failed: \(errString)"
                }
                return
            }
            
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
               let accessToken = json["access_token"] as? String {
                let refreshToken = json["refresh_token"] as? String
                let expiresIn = json["expires_in"] as? Int ?? 3600
                let expirationDate = Date().addingTimeInterval(TimeInterval(expiresIn))
                
                await MainActor.run {
                    UserDefaults.standard.set(accessToken, forKey: self.kAccessToken)
                    if let refresh = refreshToken {
                        UserDefaults.standard.set(refresh, forKey: self.kRefreshToken)
                    }
                    UserDefaults.standard.set(expirationDate.timeIntervalSince1970, forKey: self.kTokenExpiration)
                    UserDefaults.standard.set(false, forKey: self.kIsDemoMode)
                    self.isDemoMode = false
                    self.isConnected = true
                }
                
                await fetchCurrentProfile()
            }
        } catch {
            await MainActor.run {
                self.lastErrorMessage = "Network error during token exchange: \(error.localizedDescription)"
            }
        }
    }
    
    public func refreshAccessToken() async -> Bool {
        guard !isDemoMode else { return true }
        guard let refreshToken = UserDefaults.standard.string(forKey: kRefreshToken) else { return false }
        guard let url = URL(string: "https://accounts.spotify.com/api/token") else { return false }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let bodyParams: [String: String] = [
            "grant_type": "refresh_token",
            "refresh_token": refreshToken,
            "client_id": activeClientId
        ]
        
        request.httpBody = bodyParams
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }
            .joined(separator: "&")
            .data(using: .utf8)
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResp = response as? HTTPURLResponse, (200...299).contains(httpResp.statusCode) else { return false }
            
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
               let newAccessToken = json["access_token"] as? String {
                let expiresIn = json["expires_in"] as? Int ?? 3600
                let expirationDate = Date().addingTimeInterval(TimeInterval(expiresIn))
                
                UserDefaults.standard.set(newAccessToken, forKey: kAccessToken)
                UserDefaults.standard.set(expirationDate.timeIntervalSince1970, forKey: kTokenExpiration)
                if let newRefreshToken = json["refresh_token"] as? String {
                    UserDefaults.standard.set(newRefreshToken, forKey: kRefreshToken)
                }
                return true
            }
        } catch {
            return false
        }
        return false
    }
    
    public func fetchCurrentProfile() async {
        if isDemoMode { return }
        guard let token = accessToken, !token.isEmpty else { return }
        guard let url = URL(string: "https://api.spotify.com/v1/me") else { return }
        
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let httpResp = response as? HTTPURLResponse, httpResp.statusCode == 401 {
                if await refreshAccessToken() {
                    await fetchCurrentProfile()
                }
                return
            }
            
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                let id = json["id"] as? String ?? "spotify_user"
                let displayName = json["display_name"] as? String ?? id
                let email = json["email"] as? String
                let product = json["product"] as? String
                let country = json["country"] as? String
                
                var avatar: String?
                if let images = json["images"] as? [[String: Any]], let first = images.first {
                    avatar = first["url"] as? String
                }
                
                var followers: Int?
                if let followersDict = json["followers"] as? [String: Any] {
                    followers = followersDict["total"] as? Int
                }
                
                let profile = SBSpotifyUserProfile(
                    id: id,
                    displayName: displayName,
                    email: email,
                    product: product,
                    avatarURL: avatar,
                    followersCount: followers,
                    country: country
                )
                
                await MainActor.run {
                    self.userProfile = profile
                    self.isConnected = true
                }
            }
        } catch {
            print("Failed to fetch Spotify profile: \(error)")
        }
    }
    
    public func enableDemoMode() {
        self.isDemoMode = true
        UserDefaults.standard.set(true, forKey: kIsDemoMode)
        self.isConnected = true
        self.userProfile = SBSpotifyUserProfile(
            id: "spotify_demo_curator",
            displayName: "Spotify Demo Account",
            email: "demo.user@spotify-integration.io",
            product: "premium",
            avatarURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=60",
            followersCount: 384,
            country: "US"
        )
    }
    
    public func disconnect() {
        UserDefaults.standard.removeObject(forKey: kAccessToken)
        UserDefaults.standard.removeObject(forKey: kRefreshToken)
        UserDefaults.standard.removeObject(forKey: kTokenExpiration)
        UserDefaults.standard.removeObject(forKey: kIsDemoMode)
        self.isConnected = false
        self.isDemoMode = false
        self.userProfile = nil
        self.lastErrorMessage = nil
    }
    
    // MARK: - Presentation Context
    public func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        guard let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
              let window = scene.windows.first(where: { $0.isKeyWindow }) else {
            return ASPresentationAnchor()
        }
        return window
    }
    
    // MARK: - PKCE Utilities
    private func generatePKCECodeVerifier() -> String {
        var buffer = [UInt8](repeating: 0, count: 64)
        _ = SecRandomCopyBytes(kSecRandomDefault, buffer.count, &buffer)
        return Data(buffer).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
            .trimmingCharacters(in: .whitespaces)
    }
    
    private func generatePKCECodeChallenge(from verifier: String) -> String {
        guard let data = verifier.data(using: .utf8) else { return "" }
        let hash = SHA256.hash(data: data)
        return Data(hash).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
            .trimmingCharacters(in: .whitespaces)
    }
}
