import SwiftUI

public struct SettingsView: View {
    @StateObject private var viewModel = SettingsViewModel()
    @State private var showResetAlert: Bool = false
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Matching Engine & Algorithm"), footer: Text("ISRC matching searches for the unique International Standard Recording Code of each track. Balanced sensitivity accounts for remasters, features, and radio edits.")) {
                    Toggle("Prioritize ISRC Identifiers", isOn: $viewModel.matchWithISRC)
                    
                    Picker("Match Sensitivity", selection: $viewModel.sensitivity) {
                        ForEach(TransferOptions.MatchingSensitivity.allCases) { item in
                            Text(item.rawValue).tag(item)
                        }
                    }
                    
                    Toggle("Filter Duplicate Tracks", isOn: $viewModel.skipDuplicates)
                }
                
                Section(header: Text("Transfer Performance"), footer: Text("Delay between track searches prevents Spotify and Apple Music rate limiting on large playlists.")) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("Request Throttle Delay")
                            Spacer()
                            Text("\(Int(viewModel.rateLimitDelayMs)) ms")
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(value: $viewModel.rateLimitDelayMs, in: 50...500, step: 10)
                    }
                }
                
                Section(header: Text("About SoundBridge")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0 (Build 1)")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Music Frameworks")
                        Spacer()
                        Text("MusicKit & Spotify Web API")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Architecture")
                        Spacer()
                        Text("Pure Swift & SwiftUI")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Privacy")
                        Spacer()
                        Text("100% Direct On-Device")
                            .foregroundColor(.secondary)
                    }
                }
                
                Section {
                    Button(role: .destructive) {
                        showResetAlert = true
                    } label: {
                        Text("Reset Settings to Default")
                    }
                }
            }
            .navigationTitle("Settings")
            .alert("Reset Settings?", isPresented: $showResetAlert) {
                Button("Reset", role: .destructive) {
                    viewModel.resetToDefaults()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will restore default matching sensitivity and rate limiting parameters.")
            }
        }
    }
}
