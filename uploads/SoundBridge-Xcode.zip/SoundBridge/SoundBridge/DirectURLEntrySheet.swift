import SwiftUI

public struct DirectURLEntrySheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var urlText: String = ""
    public var onImport: (String) -> Void
    
    public init(onImport: @escaping (String) -> Void) {
        self.onImport = onImport
    }
    
    public var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                VStack(spacing: 8) {
                    Image(systemName: "link.badge.plus")
                        .font(.system(size: 40))
                        .foregroundColor(.accentColor)
                    
                    Text("Import Public Playlist URL")
                        .font(.headline)
                    
                    Text("Paste any public Spotify or Apple Music playlist share link to import tracks.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                }
                .padding(.top, 16)
                
                TextField("https://open.spotify.com/playlist/...", text: $urlText)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                    .padding(.horizontal, 20)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Or Try a Sample Link:")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.secondary)
                    
                    Button {
                        urlText = "https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M"
                    } label: {
                        Text("Spotify: Today's Top Hits")
                            .font(.caption)
                            .foregroundColor(.blue)
                    }
                    
                    Button {
                        urlText = "https://music.apple.com/us/playlist/todays-hits/pl.f4d106fed2bd41149aaacabb233eb5eb"
                    } label: {
                        Text("Apple Music: Today's Hits")
                            .font(.caption)
                            .foregroundColor(.pink)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)
                
                Spacer()
                
                Button {
                    let trimmed = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !trimmed.isEmpty else { return }
                    onImport(trimmed)
                    dismiss()
                } label: {
                    Text("Import Playlist")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.accentColor)
                        .cornerRadius(12)
                }
                .disabled(urlText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .padding(.horizontal, 20)
                .padding(.bottom, 16)
            }
            .navigationTitle("Import via Link")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}
