# SoundBridge — Spotify ⇄ Apple Music Playlist Transfer

SoundBridge is a native iOS application built with SwiftUI, MusicKit, and Spotify Web API (OAuth 2.0 PKCE) that allows seamless bidirectional playlist transfers between Spotify and Apple Music accounts.

## Key Features
- **Account Integration Hub**: Connect your Spotify and Apple Music accounts securely on-device with zero cloud middleman.
- **OAuth 2.0 PKCE Auth**: Direct Spotify sign-in using `ASWebAuthenticationSession` with secure token auto-refresh.
- **Apple Music & MusicKit**: Native access to your personal Apple Music library and catalog.
- **Universal Matching Pipeline**:
  1. ISRC Code Matching (100% exact identifier match)
  2. Normalized Title + Artist Search with punctuation & feature removal
  3. Fuzzy Confidence Scoring
  4. iTunes Universal Search fallback
- **Live Transfer Visualizer**: Animated waveforms, circular progress rings, real-time log stream.
- **Transfer History & Reports**: Export transfer summaries and CSV records directly to the iOS Share Sheet.
- **Direct Link Importer**: Paste any public Spotify or Apple Music link to transfer immediately.
