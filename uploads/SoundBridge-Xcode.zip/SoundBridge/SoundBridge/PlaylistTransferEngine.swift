import Foundation
import SwiftUI
import Combine

public final class PlaylistTransferEngine: ObservableObject {
    public static let shared = PlaylistTransferEngine()
    
    // Published State
    @Published public var activeJob: SBTransferJob?
    @Published public var isTransferring: Bool = false
    @Published public var currentProgress: Double = 0.0
    @Published public var currentTrackIndex: Int = 0
    @Published public var totalTracksCount: Int = 0
    @Published public var currentProcessingTrack: SBTrackTransferItem?
    @Published public var logs: [SBTransferLogEntry] = []
    @Published public var isCancelled: Bool = false
    @Published public var transferCompleted: Bool = false
    
    private let spotifyAPI = SpotifyAPIService.shared
    private let appleMusicAPI = AppleMusicAPIService.shared
    private let historyStore = TransferHistoryStore.shared
    private var transferTask: Task<Void, Never>?
    
    private init() {}
    
    // MARK: - Start Transfer
    @MainActor
    public func startTransfer(
        sourcePlaylist: SBPlaylist,
        targetService: MusicService,
        customTargetName: String? = nil,
        customDescription: String? = nil,
        options: TransferOptions = TransferOptions()
    ) {
        guard !isTransferring else { return }
        
        self.isTransferring = true
        self.isCancelled = false
        self.transferCompleted = false
        self.currentProgress = 0.0
        self.currentTrackIndex = 0
        self.logs.removeAll()
        
        let targetName = (customTargetName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
            ? customTargetName!
            : sourcePlaylist.name
        
        let targetDesc = customDescription ?? "Transferred from \(sourcePlaylist.service.rawValue) to \(targetService.rawValue) via SoundBridge"
        
        let newJob = SBTransferJob(
            sourceService: sourcePlaylist.service,
            targetService: targetService,
            sourcePlaylistName: sourcePlaylist.name,
            sourcePlaylistId: sourcePlaylist.id,
            targetPlaylistName: targetName,
            items: [],
            state: .inProgress
        )
        self.activeJob = newJob
        
        addLog("Initializing transfer: '\(sourcePlaylist.name)' (\(sourcePlaylist.service.rawValue)) ➔ \(targetService.rawValue)", level: .info)
        
        transferTask = Task {
            await executeTransferPipeline(
                sourcePlaylist: sourcePlaylist,
                targetService: targetService,
                targetName: targetName,
                targetDescription: targetDesc,
                options: options
            )
        }
    }
    
    // MARK: - Execution Pipeline
    private func executeTransferPipeline(
        sourcePlaylist: SBPlaylist,
        targetService: MusicService,
        targetName: String,
        targetDescription: String,
        options: TransferOptions
    ) async {
        await MainActor.run {
            self.addLog("Fetching tracks from source playlist '\(sourcePlaylist.name)'...", level: .info)
        }
        
        var sourceTracks: [SBTrack] = []
        do {
            if sourcePlaylist.service == .spotify {
                sourceTracks = try await spotifyAPI.fetchPlaylistTracks(playlistId: sourcePlaylist.id)
            } else {
                sourceTracks = try await appleMusicAPI.fetchPlaylistTracks(playlist: sourcePlaylist)
            }
        } catch {
            await MainActor.run {
                self.addLog("Failed to fetch source playlist tracks: \(error.localizedDescription)", level: .error)
                self.finishTransfer(state: .failed)
            }
            return
        }
        
        if sourceTracks.isEmpty {
            await MainActor.run {
                self.addLog("Source playlist has no tracks to transfer.", level: .warning)
                self.finishTransfer(state: .failed)
            }
            return
        }
        
        if options.skipDuplicates {
            var seen = Set<String>()
            sourceTracks = sourceTracks.filter { trk in
                let key = "\(trk.title.lowercased())_\(trk.artist.lowercased())"
                return seen.insert(key).inserted
            }
        }
        
        let initialItems = sourceTracks.map { SBTrackTransferItem(sourceTrack: $0) }
        await MainActor.run {
            self.totalTracksCount = initialItems.count
            self.activeJob?.items = initialItems
            self.addLog("Found \(initialItems.count) tracks to transfer. Beginning matching phase...", level: .info)
        }
        
        var processedItems: [SBTrackTransferItem] = []
        var matchedTargetTracks: [SBTrack] = []
        
        for (index, item) in initialItems.enumerated() {
            if Task.isCancelled || self.isCancelled {
                await MainActor.run {
                    self.addLog("Transfer cancelled by user.", level: .warning)
                    self.finishTransfer(state: .cancelled)
                }
                return
            }
            
            var currentItem = item
            currentItem.status = .searching
            
            await MainActor.run {
                self.currentTrackIndex = index + 1
                self.currentProgress = Double(index + 1) / Double(initialItems.count)
                self.currentProcessingTrack = currentItem
                self.activeJob?.items[index] = currentItem
            }
            
            let source = item.sourceTrack
            var matchResult: (track: SBTrack?, confidence: Double, status: TrackMatchStatus) = (nil, 0.0, .notFound)
            
            do {
                if targetService == .spotify {
                    matchResult = try await spotifyAPI.searchTrack(
                        title: source.title,
                        artist: source.artist,
                        isrc: options.matchWithISRC ? source.isrc : nil
                    )
                } else {
                    matchResult = try await appleMusicAPI.searchSong(
                        title: source.title,
                        artist: source.artist,
                        isrc: options.matchWithISRC ? source.isrc : nil
                    )
                }
            } catch {
                matchResult = (nil, 0.0, .failed)
            }
            
            if let matchedTrack = matchResult.track, matchResult.confidence >= options.matchingSensitivity.minConfidenceScore {
                currentItem.targetTrack = matchedTrack
                currentItem.status = matchResult.status
                currentItem.matchConfidence = matchResult.confidence
                matchedTargetTracks.append(matchedTrack)
                
                await MainActor.run {
                    self.addLog("[\(matchResult.status.rawValue)] '\(source.title)' by \(source.artist) -> '\(matchedTrack.title)' (\(Int(matchResult.confidence * 100))%)", level: .success)
                }
            } else {
                currentItem.status = .notFound
                currentItem.matchConfidence = 0.0
                await MainActor.run {
                    self.addLog("[NOT FOUND] '\(source.title)' by \(source.artist)", level: .warning)
                }
            }
            
            processedItems.append(currentItem)
            
            await MainActor.run {
                self.activeJob?.items[index] = currentItem
            }
            
            let delayNanos = UInt64(max(options.rateLimitDelayMs, 50)) * 1_000_000
            try? await Task.sleep(nanoseconds: delayNanos)
        }
        
        if matchedTargetTracks.isEmpty {
            await MainActor.run {
                self.addLog("No tracks were successfully matched in \(targetService.rawValue).", level: .error)
                self.finishTransfer(state: .failed)
            }
            return
        }
        
        await MainActor.run {
            self.addLog("Creating target playlist '\(targetName)' on \(targetService.rawValue)...", level: .info)
        }
        
        var createdPlaylistId: String?
        var createdPlaylistURL: String?
        
        do {
            if targetService == .spotify {
                let createRes = try await spotifyAPI.createPlaylist(
                    name: targetName,
                    description: targetDescription,
                    isPublic: options.isPublicPlaylist
                )
                createdPlaylistId = createRes.id
                createdPlaylistURL = createRes.url
                
                let uris = matchedTargetTracks.compactMap { $0.uri }
                await MainActor.run {
                    self.addLog("Adding \(uris.count) tracks to Spotify playlist...", level: .info)
                }
                try await spotifyAPI.addTracksToPlaylist(playlistId: createRes.id, uris: uris)
            } else {
                let createRes = try await appleMusicAPI.createPlaylist(
                    name: targetName,
                    description: targetDescription,
                    songs: matchedTargetTracks
                )
                createdPlaylistId = createRes.id
                createdPlaylistURL = createRes.url
            }
            
            await MainActor.run {
                self.activeJob?.targetPlaylistId = createdPlaylistId
                self.activeJob?.targetPlaylistURL = createdPlaylistURL
                
                for idx in 0..<(self.activeJob?.items.count ?? 0) {
                    if self.activeJob?.items[idx].targetTrack != nil {
                        self.activeJob?.items[idx].status = .added
                    }
                }
                
                let matchRate = Double(matchedTargetTracks.count) / Double(initialItems.count) * 100.0
                self.addLog("Transfer complete! \(matchedTargetTracks.count)/\(initialItems.count) tracks transferred (\(String(format: "%.1f", matchRate))% match rate).", level: .success)
                
                let finalState: TransferJobState = (matchedTargetTracks.count == initialItems.count) ? .completed : .completedWithWarnings
                self.finishTransfer(state: finalState)
            }
        } catch {
            await MainActor.run {
                self.addLog("Error creating target playlist: \(error.localizedDescription)", level: .error)
                self.finishTransfer(state: .failed)
            }
        }
    }
    
    // MARK: - Cancel Transfer
    @MainActor
    public func cancelTransfer() {
        self.isCancelled = true
        self.transferTask?.cancel()
        self.finishTransfer(state: .cancelled)
    }
    
    // MARK: - Finish Transfer & Save
    @MainActor
    private func finishTransfer(state: TransferJobState) {
        self.isTransferring = false
        self.transferCompleted = true
        self.activeJob?.state = state
        
        if let job = self.activeJob {
            self.historyStore.saveJob(job)
        }
    }
    
    // MARK: - Logging Helper
    @MainActor
    public func addLog(_ message: String, level: LogLevel = .info) {
        let entry = SBTransferLogEntry(message: message, level: level)
        self.logs.append(entry)
    }
}
