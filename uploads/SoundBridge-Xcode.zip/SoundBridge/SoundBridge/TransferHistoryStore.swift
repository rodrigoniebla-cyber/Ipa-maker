import Foundation
import SwiftUI
import Combine

public final class TransferHistoryStore: ObservableObject {
    public static let shared = TransferHistoryStore()
    
    @Published public var jobs: [SBTransferJob] = []
    private let kHistoryKey = "soundbridge_transfer_history"
    
    private init() {
        loadHistory()
    }
    
    public func loadHistory() {
        guard let data = UserDefaults.standard.data(forKey: kHistoryKey) else {
            self.jobs = [createSampleHistoryJob()]
            return
        }
        
        do {
            let decoded = try JSONDecoder().decode([SBTransferJob].self, from: data)
            self.jobs = decoded
        } catch {
            print("Failed to decode history: \(error)")
            self.jobs = [createSampleHistoryJob()]
        }
    }
    
    public func saveJob(_ job: SBTransferJob) {
        self.jobs.insert(job, at: 0)
        persistJobs()
    }
    
    public func deleteJob(at offsets: IndexSet) {
        self.jobs.remove(atOffsets: offsets)
        persistJobs()
    }
    
    public func deleteJob(id: UUID) {
        self.jobs.removeAll { $0.id == id }
        persistJobs()
    }
    
    public func clearAllHistory() {
        self.jobs.removeAll()
        persistJobs()
    }
    
    private func persistJobs() {
        do {
            let data = try JSONEncoder().encode(self.jobs)
            UserDefaults.standard.set(data, forKey: kHistoryKey)
        } catch {
            print("Failed to save history: \(error)")
        }
    }
    
    public var totalTransfersCount: Int {
        return jobs.count
    }
    
    public var totalSongsTransferred: Int {
        return jobs.reduce(0) { $0 + $1.matchedCount }
    }
    
    public var averageMatchRate: Double {
        guard !jobs.isEmpty else { return 0.0 }
        let totalRates = jobs.reduce(0.0) { $0 + $1.matchRatePercentage }
        return totalRates / Double(jobs.count)
    }
    
    public func exportAsCSV(for job: SBTransferJob) -> String {
        var csv = "Status,Source Track,Source Artist,Source Album,Target Track,Target Artist,ISRC,Confidence\n"
        for item in job.items {
            let status = item.status.rawValue
            let srcTitle = escapeCSV(item.sourceTrack.title)
            let srcArtist = escapeCSV(item.sourceTrack.artist)
            let srcAlbum = escapeCSV(item.sourceTrack.album ?? "")
            let tgtTitle = escapeCSV(item.targetTrack?.title ?? "N/A")
            let tgtArtist = escapeCSV(item.targetTrack?.artist ?? "N/A")
            let isrc = item.sourceTrack.isrc ?? ""
            let conf = String(format: "%.0f%%", item.matchConfidence * 100)
            
            csv += "\(status),\(srcTitle),\(srcArtist),\(srcAlbum),\(tgtTitle),\(tgtArtist),\(isrc),\(conf)\n"
        }
        return csv
    }
    
    public func exportAsJSON(for job: SBTransferJob) -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        if let data = try? encoder.encode(job), let string = String(data: data, encoding: .utf8) {
            return string
        }
        return "{}"
    }
    
    public func exportAsTextSummary(for job: SBTransferJob) -> String {
        var text = "SoundBridge Playlist Transfer Summary\n"
        text += "====================================\n"
        text += "Date: \(job.formattedDate)\n"
        text += "Source: \(job.sourcePlaylistName) (\(job.sourceService.rawValue))\n"
        text += "Target: \(job.targetPlaylistName) (\(job.targetService.rawValue))\n"
        text += "Status: \(job.state.rawValue)\n"
        text += "Match Rate: \(String(format: "%.1f", job.matchRatePercentage))% (\(job.matchedCount)/\(job.totalCount) songs)\n\n"
        text += "Matched Tracks:\n"
        for item in job.items.filter({ $0.status.isSuccess }) {
            text += "  ✓ \(item.sourceTrack.title) - \(item.sourceTrack.artist)\n"
        }
        let failed = job.items.filter { !$0.status.isSuccess }
        if !failed.isEmpty {
            text += "\nUnmatched Tracks:\n"
            for item in failed {
                text += "  ✗ \(item.sourceTrack.title) - \(item.sourceTrack.artist) (\(item.status.rawValue))\n"
            }
        }
        return text
    }
    
    private func escapeCSV(_ str: String) -> String {
        if str.contains(",") || str.contains("\"") || str.contains("\n") {
            let replaced = str.replacingOccurrences(of: "\"", with: "\"\"")
            return "\"\(replaced)\""
        }
        return str
    }
    
    private func createSampleHistoryJob() -> SBTransferJob {
        let track1 = SBTrack(
            id: "sp_sample_1",
            title: "Blinding Lights",
            artist: "The Weeknd",
            album: "After Hours",
            durationMs: 200000,
            isrc: "USUG11904206",
            service: .spotify
        )
        let track2 = SBTrack(
            id: "sp_sample_2",
            title: "Midnight City",
            artist: "M83",
            album: "Hurry Up, We're Dreaming",
            durationMs: 243000,
            isrc: "FR01X1100340",
            service: .spotify
        )
        let track3 = SBTrack(
            id: "sp_sample_3",
            title: "Resonance",
            artist: "HOME",
            album: "Odyssey",
            durationMs: 212000,
            isrc: "QZHN71439281",
            service: .spotify
        )
        
        let targetTrack1 = SBTrack(
            id: "am_sample_1",
            title: "Blinding Lights",
            artist: "The Weeknd",
            album: "After Hours",
            durationMs: 200000,
            isrc: "USUG11904206",
            service: .appleMusic
        )
        let targetTrack2 = SBTrack(
            id: "am_sample_2",
            title: "Midnight City",
            artist: "M83",
            album: "Hurry Up, We're Dreaming",
            durationMs: 243000,
            isrc: "FR01X1100340",
            service: .appleMusic
        )
        let targetTrack3 = SBTrack(
            id: "am_sample_3",
            title: "Resonance",
            artist: "HOME",
            album: "Odyssey",
            durationMs: 212000,
            isrc: "QZHN71439281",
            service: .appleMusic
        )
        
        let item1 = SBTrackTransferItem(sourceTrack: track1, targetTrack: targetTrack1, status: .added, matchConfidence: 1.0)
        let item2 = SBTrackTransferItem(sourceTrack: track2, targetTrack: targetTrack2, status: .added, matchConfidence: 0.95)
        let item3 = SBTrackTransferItem(sourceTrack: track3, targetTrack: targetTrack3, status: .added, matchConfidence: 1.0)
        
        return SBTransferJob(
            date: Date().addingTimeInterval(-86400 * 2),
            sourceService: .spotify,
            targetService: .appleMusic,
            sourcePlaylistName: "Synthwave Essentials",
            sourcePlaylistId: "sp_demo_syn",
            targetPlaylistName: "Synthwave Essentials",
            targetPlaylistId: "am_demo_syn",
            items: [item1, item2, item3],
            state: .completed
        )
    }
}
