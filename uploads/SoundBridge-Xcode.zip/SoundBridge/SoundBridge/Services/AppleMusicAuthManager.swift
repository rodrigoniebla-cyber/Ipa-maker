import Foundation
import MusicKit
import MediaPlayer
import Combine

public final class AppleMusicAuthManager: ObservableObject {
    public static let shared = AppleMusicAuthManager()
    
    @Published public var isAuthorized: Bool = false
    @Published public var authorizationStatus: MusicAuthorization.Status = .notDetermined
    @Published public var profile: AppleMusicProfile = AppleMusicProfile()
    @Published public var isLoading: Bool = false
    @Published public var errorMessage: String?
    
    private init() {
        checkCurrentAuthorizationStatus()
    }
    
    public func checkCurrentAuthorizationStatus() {
        let status = MusicAuthorization.currentStatus
        self.authorizationStatus = status
        self.isAuthorized = (status == .authorized)
        
        updateProfileStatus(status: status)
        
        if status == .authorized {
            Task {
                await checkSubscriptionDetails()
            }
        }
    }
    
    @MainActor
    public func requestAuthorization() async {
        self.isLoading = true
        self.errorMessage = nil
        
        // 1. Request MusicKit Authorization
        let status = await MusicAuthorization.request()
        self.authorizationStatus = status
        self.isAuthorized = (status == .authorized)
        
        // 2. Also request MPMediaLibrary for local library fallback
        if status == .authorized {
            MPMediaLibrary.requestAuthorization { _ in }
            await checkSubscriptionDetails()
        } else {
            self.errorMessage = "Apple Music permission: \(descriptionFor(status: status))"
        }
        
        updateProfileStatus(status: status)
        self.isLoading = false
    }
    
    private func updateProfileStatus(status: MusicAuthorization.Status) {
        self.profile.isAuthorized = (status == .authorized)
        self.profile.statusDescription = descriptionFor(status: status)
    }
    
    private func checkSubscriptionDetails() async {
        do {
            let subscription = try await MusicSubscription.current
            await MainActor.run {
                self.profile.canPlayCatalog = subscription.canPlayCatalogContent
                self.profile.hasCloudLibrary = subscription.hasCloudLibraryEnabled
            }
        } catch {
            print("Unable to fetch Apple Music subscription info: \(error)")
        }
    }
    
    private func descriptionFor(status: MusicAuthorization.Status) -> String {
        switch status {
        case .authorized: return "Authorized"
        case .denied: return "Access Denied"
        case .restricted: return "Restricted"
        case .notDetermined: return "Not Determined"
        @unknown default: return "Unknown"
        }
    }
}
