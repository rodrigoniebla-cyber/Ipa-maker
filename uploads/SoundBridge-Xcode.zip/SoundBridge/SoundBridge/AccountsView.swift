import SwiftUI
import UIKit

public struct AccountsView: View {
    @StateObject private var viewModel = AccountsViewModel()
    @ObservedObject private var spotifyAuth = SpotifyAuthManager.shared
    @ObservedObject private var appleAuth = AppleMusicAuthManager.shared
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    spotifyCard
                    appleMusicCard
                    diagnosticsCard
                    securityNote
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Accounts")
            .sheet(isPresented: $viewModel.showSpotifySettingsSheet) {
                SpotifyConfigSheet()
            }
            .sheet(isPresented: $viewModel.showDiagnosticsSheet) {
                DiagnosticsSheet(report: viewModel.diagnosticReport)
            }
        }
    }
    
    private var spotifyCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                ServiceBadge(service: .spotify, size: 14)
                Spacer()
                Text(spotifyAuth.isConnected ? "CONNECTED" : "NOT CONNECTED")
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundColor(spotifyAuth.isConnected ? .green : .secondary)
            }
            
            if spotifyAuth.isConnected {
                HStack(spacing: 14) {
                    ArtworkImageView(urlString: spotifyAuth.userProfile?.avatarURL, defaultSymbol: "person.circle.fill", cornerRadius: 28)
                        .frame(width: 56, height: 56)
                    
                    VStack(alignment: .leading, spacing: 3) {
                        Text(spotifyAuth.userProfile?.displayName ?? "Spotify User")
                            .font(.headline)
                        
                        if let email = spotifyAuth.userProfile?.email {
                            Text(email)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        HStack(spacing: 6) {
                            if let prod = spotifyAuth.userProfile?.product {
                                Text(prod.uppercased())
                                    .font(.system(size: 9, weight: .bold))
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.green.opacity(0.2))
                                    .foregroundColor(.green)
                                    .cornerRadius(4)
                            }
                            
                            if let followers = spotifyAuth.userProfile?.followersCount {
                                Text("\(followers) Followers")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
                
                HStack(spacing: 10) {
                    Button {
                        viewModel.showSpotifySettingsSheet = true
                    } label: {
                        HStack {
                            Image(systemName: "gearshape")
                            Text("API Config")
                        }
                        .font(.footnote)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(Color(.tertiarySystemGroupedBackground))
                        .cornerRadius(8)
                    }
                    
                    Button {
                        viewModel.disconnectSpotify()
                    } label: {
                        HStack {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                            Text("Disconnect")
                        }
                        .font(.footnote)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                    }
                }
            } else {
                Text("Connect your Spotify account to import your playlists and create new ones.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                VStack(spacing: 8) {
                    Button {
                        viewModel.connectSpotify()
                    } label: {
                        HStack {
                            Image(systemName: "person.badge.key.fill")
                            Text("Connect Spotify Account")
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(MusicService.spotify.brandColor)
                        .cornerRadius(10)
                    }
                    
                    HStack(spacing: 12) {
                        Button {
                            spotifyAuth.enableDemoMode()
                        } label: {
                            Text("Use Demo Account")
                                .font(.caption)
                                .foregroundColor(.blue)
                        }
                        
                        Spacer()
                        
                        Button {
                            viewModel.showSpotifySettingsSheet = true
                        } label: {
                            Text("Custom Client ID")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            
            if let error = spotifyAuth.lastErrorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    private var appleMusicCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                ServiceBadge(service: .appleMusic, size: 14)
                Spacer()
                Text(appleAuth.isAuthorized ? "AUTHORIZED" : "NOT AUTHORIZED")
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundColor(appleAuth.isAuthorized ? .green : .secondary)
            }
            
            if appleAuth.isAuthorized {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 10) {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.pink)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Apple Music Library Ready")
                                .font(.headline)
                            Text("Direct MusicKit integration is authorized.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        featureRow(title: "MusicKit Catalog Access", active: true)
                        featureRow(title: "Personal Library Access", active: true)
                        featureRow(title: "Cloud Sync Enabled", active: appleAuth.profile.hasCloudLibrary)
                    }
                    .padding(.top, 4)
                }
            } else {
                Text("Authorize Apple Music to allow SoundBridge to access your playlists and add transferred tracks directly to your library.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Button {
                    viewModel.connectAppleMusic()
                } label: {
                    HStack {
                        Image(systemName: "music.note")
                        Text("Authorize Apple Music Access")
                            .fontWeight(.semibold)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(MusicService.appleMusic.brandColor)
                    .cornerRadius(10)
                }
            }
            
            if let error = appleAuth.errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    private func featureRow(title: String, active: Bool) -> some View {
        HStack(spacing: 6) {
            Image(systemName: active ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 12))
                .foregroundColor(active ? .green : .secondary)
            Text(title)
                .font(.caption)
                .foregroundColor(.primary)
        }
    }
    
    private var diagnosticsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Connection & Sync Health")
                .font(.headline)
            
            Text("Test latency, token validity, and Apple Music library readiness.")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Button {
                viewModel.runDiagnostics()
            } label: {
                HStack {
                    if viewModel.isTestingConnection {
                        ProgressView()
                            .padding(.trailing, 4)
                    } else {
                        Image(systemName: "stethoscope")
                    }
                    Text(viewModel.isTestingConnection ? "Running Health Check..." : "Run Integration Diagnostics")
                }
                .font(.footnote)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(Color(.tertiarySystemGroupedBackground))
                .cornerRadius(10)
            }
            .disabled(viewModel.isTestingConnection)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
    }
    
    private var securityNote: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 20))
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("100% On-Device Integration")
                    .font(.caption)
                    .fontWeight(.bold)
                Text("SoundBridge communicates directly with Spotify and Apple Music APIs using PKCE OAuth and native MusicKit. Your credentials and tokens are stored solely on your device.")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(14)
        .background(Color(.secondarySystemGroupedBackground).opacity(0.6))
        .cornerRadius(12)
    }
}
