import Foundation
import SwiftUI

// MARK: - Music Service Enum
public enum MusicService: String, CaseIterable, Identifiable, Codable {
    case spotify = "Spotify"
    case appleMusic = "Apple Music"
    
    public var id: String { rawValue }
    
    public var shortName: String {
        switch self {
        case .spotify: return "Spotify"
        case .appleMusic: return "Apple Music"
        }
    }
    
    public var iconSymbol: String {
        switch self {
        case .spotify: return "waveform.path.badge.plus"
        case .appleMusic: return "music.note"
        }
    }
    
    public var brandColor: Color {
        switch self {
        case .spotify:
            return Color(red: 29/255, green: 185/255, blue: 84/255) // #1DB954 Spotify Green
        case .appleMusic:
            return Color(red: 250/255, green: 36/255, blue: 60/255) // #FA243C Apple Music Red
        }
    }
    
    public var gradient: LinearGradient {
        switch self {
        case .spotify:
            return LinearGradient(
                colors: [Color(red: 29/255, green: 185/255, blue: 84/255), Color(red: 16/255, green: 120/255, blue: 54/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .appleMusic:
            return LinearGradient(
                colors: [Color(red: 250/255, green: 36/255, blue: 60/255), Color(red: 210/255, green: 10/255, blue: 70/255)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
}

// MARK: - Playlist Model
public struct Playlist: Identifiable, Hashable, Codable {
    public let id: String
    public var name: String
    public var description: String?
    public var artworkURL: String?
    public var trackCount: Int
    public var ownerName: String?
    public var isPublic: Bool
    public var service: MusicService
    public var externalURL: String?
    
    public init(
        id: String,
        name: String,
        description: String? = nil,
        artworkURL: String? = nil,
        trackCount: Int = 0,
        ownerName: String? = nil,
        isPublic: Bool = true,
        service: MusicService,
        externalURL: String? = nil
    ) {
        self.id = id
        self.name = name
        self.description = description
        self.artworkURL = artworkURL
        self.trackCount = trackCount
        self.ownerName = ownerName
        self.isPublic = isPublic
        self.service = service
        self.externalURL = externalURL
    }
}

// MARK: - Track Model
public struct Track: Identifiable, Hashable, Codable {
    public let id: String
    public var title: String
    public var artist: String
    public var album: String?
    public var durationMs: Int?
    public var isrc: String?
    public var artworkURL: String?
    public var service: MusicService
    public var uri: String?
    public var previewURL: String?
    
    public init(
        id: String,
        title: String,
        artist: String,
        album: String? = nil,
        durationMs: Int? = nil,
        isrc: String? = nil,
        artworkURL: String? = nil,
        service: MusicService,
        uri: String? = nil,
        previewURL: String? = nil
    ) {
        self.id = id
        self.title = title
        self.artist = artist
        self.album = album
        self.durationMs = durationMs
        self.isrc = isrc
        self.artworkURL = artworkURL
        self.service = service
        self.uri = uri
        self.previewURL = previewURL
    }
    
    public var formattedDuration: String {
        guard let ms = durationMs else { return "--:--" }
        let totalSeconds = ms / 1000
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

// MARK: - Track Match Status
public enum TrackMatchStatus: String, Codable {
    case pending = "Pending"
    case searching = "Searching..."
    case matchedISRC = "Matched (ISRC)"
    case matchedTitleArtist = "Matched (Exact)"
    case matchedFuzzy = "Matched (Fuzzy)"
    case added = "Added to Playlist"
    case notFound = "Not Found"
    case failed = "Failed"
    
    public var isSuccess: Bool {
        switch self {
        case .matchedISRC, .matchedTitleArtist, .matchedFuzzy, .added:
            return true
        default:
            return false
        }
    }
    
    public var badgeColor: Color {
        switch self {
        case .pending, .searching:
            return .gray
        case .matchedISRC:
            return .purple
        case .matchedTitleArtist:
            return .green
        case .matchedFuzzy:
            return .blue
        case .added:
            return .mint
        case .notFound:
            return .orange
        case .failed:
            return .red
        }
    }
}

// MARK: - Track Transfer Item
public struct TrackTransferItem: Identifiable, Codable {
    public let id: UUID
    public let sourceTrack: Track
    public var targetTrack: Track?
    public var status: TrackMatchStatus
    public var matchConfidence: Double
    public var errorMessage: String?
    
    public init(
        id: UUID = UUID(),
        sourceTrack: Track,
        targetTrack: Track? = nil,
        status: TrackMatchStatus = .pending,
        matchConfidence: Double = 0.0,
        errorMessage: String? = nil
    ) {
        self.id = id
        self.sourceTrack = sourceTrack
        self.targetTrack = targetTrack
        self.status = status
        self.matchConfidence = matchConfidence
        self.errorMessage = errorMessage
    }
}

// MARK: - Transfer Job State
public enum TransferJobState: String, Codable {
    case queued = "Queued"
    case inProgress = "In Progress"
    case completed = "Completed"
    case completedWithWarnings = "Completed (Partial)"
    case failed = "Failed"
    case cancelled = "Cancelled"
}

// MARK: - Transfer Job
public struct TransferJob: Identifiable, Codable {
    public let id: UUID
    public let date: Date
    public let sourceService: MusicService
    public let targetService: MusicService
    public let sourcePlaylistName: String
    public let sourcePlaylistId: String
    public let targetPlaylistName: String
    public var targetPlaylistId: String?
    public var targetPlaylistURL: String?
    public var items: [TrackTransferItem]
    public var state: TransferJobState
    
    public init(
        id: UUID = UUID(),
        date: Date = Date(),
        sourceService: MusicService,
        targetService: MusicService,
        sourcePlaylistName: String,
        sourcePlaylistId: String,
        targetPlaylistName: String,
        targetPlaylistId: String? = nil,
        targetPlaylistURL: String? = nil,
        items: [TrackTransferItem] = [],
        state: TransferJobState = .queued
    ) {
        self.id = id
        self.date = date
        self.sourceService = sourceService
        self.targetService = targetService
        self.sourcePlaylistName = sourcePlaylistName
        self.sourcePlaylistId = sourcePlaylistId
        self.targetPlaylistName = targetPlaylistName
        self.targetPlaylistId = targetPlaylistId
        self.targetPlaylistURL = targetPlaylistURL
        self.items = items
        self.state = state
    }
    
    public var totalCount: Int { items.count }
    public var matchedCount: Int { items.filter { $0.status.isSuccess }.count }
    public var unmatchedCount: Int { items.filter { !$0.status.isSuccess && $0.status != .pending && $0.status != .searching }.count }
    
    public var matchRatePercentage: Double {
        guard totalCount > 0 else { return 0.0 }
        return (Double(matchedCount) / Double(totalCount)) * 100.0
    }
    
    public var formattedDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// MARK: - User Profiles
public struct SpotifyUserProfile: Codable {
    public let id: String
    public let displayName: String
    public let email: String?
    public let product: String?
    public let avatarURL: String?
    public let followersCount: Int?
    public let country: String?
    
    public init(
        id: String,
        displayName: String,
        email: String? = nil,
        product: String? = nil,
        avatarURL: String? = nil,
        followersCount: Int? = nil,
        country: String? = nil
    ) {
        self.id = id
        self.displayName = displayName
        self.email = email
        self.product = product
        self.avatarURL = avatarURL
        self.followersCount = followersCount
        self.country = country
    }
}

public struct AppleMusicProfile: Codable {
    public var isAuthorized: Bool
    public var statusDescription: String
    public var hasCloudLibrary: Bool
    public var canPlayCatalog: Bool
    public var storefrontCountryCode: String?
    
    public init(
        isAuthorized: Bool = false,
        statusDescription: String = "Not Authorized",
        hasCloudLibrary: Bool = false,
        canPlayCatalog: Bool = false,
        storefrontCountryCode: String? = nil
    ) {
        self.isAuthorized = isAuthorized
        self.statusDescription = statusDescription
        self.hasCloudLibrary = hasCloudLibrary
        self.canPlayCatalog = canPlayCatalog
        self.storefrontCountryCode = storefrontCountryCode
    }
}

// MARK: - Transfer Log Entry
public enum LogLevel: String, Codable {
    case info = "INFO"
    case success = "SUCCESS"
    case warning = "WARNING"
    case error = "ERROR"
    
    public var color: Color {
        switch self {
        case .info: return .blue
        case .success: return .green
        case .warning: return .orange
        case .error: return .red
        }
    }
}

public struct TransferLogEntry: Identifiable, Codable {
    public let id: UUID
    public let timestamp: Date
    public let message: String
    public let level: LogLevel
    
    public init(id: UUID = UUID(), timestamp: Date = Date(), message: String, level: LogLevel = .info) {
        self.id = id
        self.timestamp = timestamp
        self.message = message
        self.level = level
    }
    
    public var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: timestamp)
    }
}

// MARK: - Transfer Options
public struct TransferOptions: Codable {
    public var matchWithISRC: Bool = true
    public var skipDuplicates: Bool = true
    public var isPublicPlaylist: Bool = true
    public var rateLimitDelayMs: Int = 120
    public var matchingSensitivity: MatchingSensitivity = .balanced
    
    public enum MatchingSensitivity: String, CaseIterable, Identifiable, Codable {
        case strict = "Strict (High Confidence)"
        case balanced = "Balanced (Recommended)"
        case relaxed = "Relaxed (Broader Match)"
        
        public var id: String { rawValue }
        
        public var minConfidenceScore: Double {
            switch self {
            case .strict: return 0.85
            case .balanced: return 0.65
            case .relaxed: return 0.45
            }
        }
    }
}
